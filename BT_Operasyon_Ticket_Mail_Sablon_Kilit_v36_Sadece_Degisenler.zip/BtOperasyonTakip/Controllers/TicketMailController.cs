﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Net.Mail;
using System.Text.Json;

namespace BtOperasyonTakip.Controllers;

[Authorize(Roles = "Operasyon,Admin")]
public sealed class TicketMailController : Controller
{
    private readonly AppDbContext _db;
    private readonly IConfiguration _config;
    private readonly IWebHostEnvironment _environment;
    private readonly ILogger<TicketMailController> _logger;
    private static readonly SemaphoreSlim SendLock = new(1, 1);
    private readonly string _folder;
    private readonly string _attachments;
    private readonly string _settingsFile;
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true, WriteIndented = true };
    private static readonly string[] AcceptedExtensions = [".pdf", ".docx", ".xlsx", ".txt"];

    public TicketMailController(AppDbContext db, IConfiguration config, IWebHostEnvironment environment, ILogger<TicketMailController> logger)
    {
        _db = db;
        _config = config;
        _environment = environment;
        _logger = logger;
        _folder = Path.Combine(environment.ContentRootPath, "App_Data", "TicketMail");
        _attachments = Path.Combine(_folder, "Attachments");
        _settingsFile = Path.Combine(_folder, "template.json");
        Directory.CreateDirectory(_attachments);
    }

    public sealed class MailTemplate
    {
        public string DeliveryMode { get; set; } = "Manual"; // Admin: Manual or Smtp
        public string SupportCc { get; set; } = ""; // Admin-defined mandatory CC; config used as fallback
        public string Subject { get; set; } = "{FirmaAdi} - Sanal POS Entegrasyon Dokümanları";
        public string Body { get; set; } = "Merhaba {YetkiliAdi},\n\nUyum onayınız sonrasında entegrasyon dokümanlarını ekte iletiyoruz.\nTicket: {TicketNo}\n\nİyi çalışmalar,\nSanal POS Entegrasyon Ekibi";
        public List<MailAttachment> Attachments { get; set; } = [];
    }
    public sealed class MailAttachment
    {
        public string Name { get; set; } = "";
        public string SavedName { get; set; } = "";
    }
    public sealed class SendRequest
    {
        public int Id { get; set; }
        public string? Mode { get; set; }
        public string? Subject { get; set; }
        public string? Body { get; set; }
        public string? Confirmation { get; set; }
    }

    // Keep template read/write operations serialized within this application process.
    // Retrying additionally covers short-lived file locks from antivirus, backup software,
    // or another running application instance. Do not silently reset an existing template.
    private static readonly object TemplateFileLock = new();
    private const int TemplateFileAttempts = 8;

    private MailTemplate ReadTemplate()
    {
        lock (TemplateFileLock)
        {
            if (!System.IO.File.Exists(_settingsFile)) return new MailTemplate();
            for (var attempt = 1; attempt <= TemplateFileAttempts; attempt++)
            {
                try
                {
                    using var stream = new FileStream(_settingsFile, FileMode.Open, FileAccess.Read,
                        FileShare.ReadWrite | FileShare.Delete);
                    using var reader = new StreamReader(stream);
                    var json = reader.ReadToEnd();
                    return JsonSerializer.Deserialize<MailTemplate>(json, JsonOptions)
                        ?? throw new JsonException("E-posta şablonu boş JSON içeriği döndürdü.");
                }
                catch (IOException ex) when (attempt < TemplateFileAttempts)
                {
                    _logger.LogWarning(ex, "Ticket e-posta şablonu geçici olarak kilitli. Deneme {Attempt}/{Max}", attempt, TemplateFileAttempts);
                    Thread.Sleep(75 * attempt);
                }
                catch (JsonException ex) when (attempt < TemplateFileAttempts)
                {
                    _logger.LogWarning(ex, "Ticket e-posta şablonu yazılırken okuma denemesi {Attempt}/{Max}", attempt, TemplateFileAttempts);
                    Thread.Sleep(75 * attempt);
                }
            }
            throw new IOException("E-posta şablonu tekrar denemelere rağmen okunamadı.");
        }
    }

    private void SaveTemplate(MailTemplate t)
    {
        lock (TemplateFileLock)
        {
            Directory.CreateDirectory(_folder);
            // A unique temporary filename prevents parallel requests from sharing .tmp.
            var tmp = _settingsFile + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                System.IO.File.WriteAllText(tmp, JsonSerializer.Serialize(t, JsonOptions));
                for (var attempt = 1; attempt <= TemplateFileAttempts; attempt++)
                {
                    try
                    {
                        System.IO.File.Move(tmp, _settingsFile, true);
                        return;
                    }
                    catch (IOException ex) when (attempt < TemplateFileAttempts)
                    {
                        _logger.LogWarning(ex, "Ticket e-posta şablonu kaydedilirken dosya kilitli. Deneme {Attempt}/{Max}", attempt, TemplateFileAttempts);
                        Thread.Sleep(75 * attempt);
                    }
                }
            }
            finally
            {
                try { if (System.IO.File.Exists(tmp)) System.IO.File.Delete(tmp); }
                catch (IOException ex) { _logger.LogWarning(ex, "Geçici mail şablon dosyası silinemedi: {File}", tmp); }
            }
        }
    }
    private static string Render(string value, Ticket ticket) => value
        .Replace("{FirmaAdi}", ticket.FirmaAdi ?? "", StringComparison.Ordinal)
        .Replace("{YetkiliAdi}", ((ticket.YazilimciAdi ?? "") + " " + (ticket.YazilimciSoyadi ?? "")).Trim(), StringComparison.Ordinal)
        .Replace("{TicketNo}", ticket.Id.ToString(), StringComparison.Ordinal)
        .Replace("{Tarih}", DateTime.Now.ToString("dd.MM.yyyy"), StringComparison.Ordinal);

    private bool CanSend(Ticket t) => t.Durum == "Operasyon 2 Onay Bekleniyor" && t.UyumOnayTarihi.HasValue &&
        (User.IsInRole("Admin") || t.AtananOperasyonUserId == GetUserId());
    private int GetUserId() => int.TryParse(User.FindFirst("UserId")?.Value, out int id) ? id : 0;

    private string Cc => (ReadTemplate().SupportCc is { Length: > 0 } configured ? configured : _config["TicketMail:SupportCc"] ?? "").Trim();
    private string From => (_config["TicketMail:From"] ?? "").Trim();
    private bool Configured => !string.IsNullOrWhiteSpace(_config["TicketMail:SmtpHost"]) &&
        !string.IsNullOrWhiteSpace(From) && !string.IsNullOrWhiteSpace(Cc);
    private static bool ValidEmail(string address)
    {
        try { var a = new MailAddress(address); return a.Address.Equals(address, StringComparison.OrdinalIgnoreCase); }
        catch { return false; }
    }

    [HttpGet]
    public IActionResult Preview(int id)
    {
        var t = _db.Tickets.AsNoTracking().FirstOrDefault(t => t.Id == id);
        if (t == null) return NotFound(new { success = false, message = "Ticket bulunamadı." });
        if (!CanSend(t)) return StatusCode(403, new { success = false, message = "Uyum onayı veya atama yetkisi uygun değil." });
        var template = ReadTemplate();
        return Json(new { success = true, to = t.Mail, cc = Cc, subject = Render(template.Subject, t), body = Render(template.Body, t), attachments = template.Attachments.Select(a => new { name = a.Name, url = Url.Action(nameof(DownloadDocument), "TicketMail", new { id = t.Id, savedName = a.SavedName }) }).ToArray(), mode = template.DeliveryMode == "Smtp" ? "Smtp" : "Manual", smtpReady = Configured });
    }

    [HttpGet]
    public IActionResult DownloadDocument(int id, string savedName)
    {
        var ticket = _db.Tickets.AsNoTracking().FirstOrDefault(t => t.Id == id);
        if (ticket == null) return NotFound();
        if (!CanSend(ticket)) return Forbid();
        var a = ReadTemplate().Attachments.FirstOrDefault(a => a.SavedName == savedName);
        if (a == null || string.IsNullOrWhiteSpace(a.SavedName) || Path.GetFileName(a.SavedName) != a.SavedName) return NotFound();
        var file = Path.Combine(_attachments, a.SavedName);
        if (!System.IO.File.Exists(file)) return NotFound();
        return PhysicalFile(file, "application/octet-stream", a.Name);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Send([FromBody] SendRequest request)
    {
        if (request == null || request.Id <= 0) return BadRequest(new { success = false, message = "Geçersiz ticket." });
        await SendLock.WaitAsync();
        try
        {
            var t = await _db.Tickets.FirstOrDefaultAsync(t => t.Id == request.Id);
            if (t == null) return NotFound(new { success = false, message = "Ticket bulunamadı." });
            if (!CanSend(t)) return StatusCode(403, new { success = false, message = "Bu ticket için gönderim yetkisi veya Uyum onayı yok." });
            if (t.MailGonderildiMi == true) return BadRequest(new { success = false, message = "Mail zaten gönderilmiş." });
            var template = ReadTemplate();
            var mode = request.Mode?.Trim();
            if (mode != "Manual" && mode != "Smtp")
                return BadRequest(new { success = false, message = "Lütfen gönderim yöntemini seçin." });
            if (mode == "Smtp" && template.DeliveryMode != "Smtp")
                return BadRequest(new { success = false, message = "SMTP modu Admin tarafından etkinleştirilmedi." });
            if (!ValidEmail(t.Mail) || !ValidEmail(Cc))
                return BadRequest(new { success = false, message = "Müşteri To veya zorunlu Sanal POS Destek CC adresi geçersiz. Admin ayarlarını kontrol edin." });
            var subject = (request.Subject ?? "").Trim();
            var body = (request.Body ?? "").Trim();
            if (subject.Length is < 1 or > 300 || body.Length is < 1 or > 12000)
                return BadRequest(new { success = false, message = "Mail konu/metni boş veya fazla uzun." });
            // The preview is editable per-ticket, but the persisted admin template remains unchanged.
            if (mode == "Manual")
            {
                if (request.Confirmation != "ManuallySent")
                    return BadRequest(new { success = false, message = "Outlook üzerinden To ve zorunlu CC ile gerçekten gönderdiğinizi onaylayın." });
            }
            else
            {
                if (!Configured || !ValidEmail(From))
                    return BadRequest(new { success = false, message = "SMTP host/gönderici/CC yapılandırması eksik veya geçersiz." });
                if (template.Attachments.Count == 0)
                    return BadRequest(new { success = false, message = "SMTP için Admin henüz entegrasyon dokümanı eklememiş." });
                using var mail = new MailMessage { From = new MailAddress(From), Subject = subject, Body = body, IsBodyHtml = false };
                mail.To.Add(new MailAddress(t.Mail));
                mail.CC.Add(new MailAddress(Cc));
                foreach (var a in template.Attachments)
                {
                    if (string.IsNullOrWhiteSpace(a.SavedName) || Path.GetFileName(a.SavedName) != a.SavedName)
                        return BadRequest(new { success = false, message = "Geçersiz ek kaydı." });
                    var file = Path.Combine(_attachments, a.SavedName);
                    if (!System.IO.File.Exists(file)) return BadRequest(new { success = false, message = $"Doküman bulunamadı: {a.Name}" });
                    mail.Attachments.Add(new Attachment(file) { Name = a.Name });
                }
                int port = int.TryParse(_config["TicketMail:SmtpPort"], out var configuredPort) ? configuredPort : 587;
                if (port < 1 || port > 65535) return BadRequest(new { success = false, message = "SMTP portu geçersiz." });
                using var smtp = new SmtpClient(_config["TicketMail:SmtpHost"], port) { EnableSsl = true, DeliveryMethod = SmtpDeliveryMethod.Network, Timeout = 30000, UseDefaultCredentials = false };
                var username = _config["TicketMail:Username"];
                if (!string.IsNullOrWhiteSpace(username)) smtp.Credentials = new NetworkCredential(username, _config["TicketMail:Password"] ?? "");
                // SMTP acceptance is required BEFORE updating the workflow.
                await smtp.SendMailAsync(mail);
            }
            t.MailGonderildiMi = true;
            var methodLabel = mode == "Manual" ? "Manuel gönderildi (kullanıcı beyanı)" : "SMTP kabul edildi";
            t.MailNotu = $"{methodLabel}; To={t.Mail}; CC={Cc}; Konu={subject}; Kullanıcı={User.Identity?.Name}";
            if (t.MailNotu.Length > 250) t.MailNotu = t.MailNotu[..250];
            t.Operasyon2OnayTarihi = DateTime.UtcNow;
            t.Durum = "Entegrasyon Bekleniyor";
            var jiraId = $"TICKET-{t.Id}";
            var task = await _db.JiraTasks.FirstOrDefaultAsync(x => x.JiraId == jiraId);
            if (task == null)
                _db.JiraTasks.Add(new JiraTask { JiraId = jiraId, TalepKonusu = $"Entegrasyon: {t.FirmaAdi}", TalepTuru = "Entegrasyon", TalepAcan = t.AtananOperasyonKullaniciAdi ?? User.Identity?.Name ?? "Sistem", Durum = "Beklemede", TakipEden = t.AtananOperasyonKullaniciAdi });
            else
            {
                task.TalepTuru = "Entegrasyon";
                task.Durum = "Beklemede";
                if (string.IsNullOrWhiteSpace(task.TalepKonusu)) task.TalepKonusu = $"Entegrasyon: {t.FirmaAdi}";
                if (string.IsNullOrWhiteSpace(task.TalepAcan)) task.TalepAcan = t.AtananOperasyonKullaniciAdi ?? "Sistem";
            }
            await _db.SaveChangesAsync();
            _logger.LogInformation("Ticket {TicketId}: mail status confirmed via {Mode}; operator={User}; To={To}; CC={Cc}; attachments={Count}", t.Id, mode, User.Identity?.Name, t.Mail, Cc, template.Attachments.Count);
            return Json(new { success = true, message = mode == "Manual" ? "Manuel gönderim beyanı kaydedildi. İş Entegrasyon Bekleniyor aşamasına geçirildi." : "E-posta SMTP sunucusu tarafından kabul edildi. İş Entegrasyon Bekleniyor aşamasına geçirildi." });
        }
        catch (SmtpException ex)
        {
            _logger.LogError(ex, "SMTP gönderimi başarısız");
            return StatusCode(502, new { success = false, message = "SMTP sunucusu gönderimi kabul etmedi. Sunucu günlüklerini kontrol edin." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ticket doküman gönderimi / kayıt hatası. SMTP kabulünden sonra DB başarısız olduysa tekrar gönderimden önce sunucu loglarını kontrol edin.");
            return StatusCode(500, new { success = false, message = "Gönderim veya kayıt sırasında hata oluştu. Tekrar denemeden önce sunucu loglarından gönderim durumunu doğrulayın." });
        }
        finally { SendLock.Release(); }
    }

    [HttpGet]
    [Authorize(Roles = "Admin")]
    public IActionResult Admin()
    {
        ViewBag.SupportCc = Cc;
        ViewBag.FromAddress = From;
        ViewBag.SmtpConfigured = Configured;
        return View(ReadTemplate());
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public IActionResult SaveTemplateForm(string subject, string body, string deliveryMode, string supportCc)
    {
        if (string.IsNullOrWhiteSpace(subject) || subject.Length > 300 || string.IsNullOrWhiteSpace(body) || body.Length > 12000)
        { TempData["MailError"] = "Konu/metin boş olamaz veya çok uzun."; return RedirectToAction(nameof(Admin)); }
        if (deliveryMode != "Manual" && deliveryMode != "Smtp")
        { TempData["MailError"] = "Geçersiz gönderim yöntemi."; return RedirectToAction(nameof(Admin)); }
        if (!ValidEmail((supportCc ?? "").Trim()))
        { TempData["MailError"] = "Zorunlu Sanal POS Destek CC için geçerli e-posta girin."; return RedirectToAction(nameof(Admin)); }
        lock (TemplateFileLock)
        {
            var t = ReadTemplate();
            t.Subject = subject.Trim(); t.Body = body.Trim();
            t.DeliveryMode = deliveryMode;
            t.SupportCc = supportCc.Trim();
            SaveTemplate(t);
        }
        TempData["MailInfo"] = "Şablon kaydedildi.";
        return RedirectToAction(nameof(Admin));
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(12_000_000)]
    public async Task<IActionResult> UploadDocument(IFormFile file)
    {
        if (file == null || file.Length == 0 || file.Length > 10_000_000 || !AcceptedExtensions.Contains(Path.GetExtension(file.FileName).ToLowerInvariant()))
        { TempData["MailError"] = "Yalnızca PDF, DOCX, XLSX veya TXT, en fazla 10 MB."; return RedirectToAction(nameof(Admin)); }
        var saved = Guid.NewGuid().ToString("N") + Path.GetExtension(file.FileName).ToLowerInvariant();
        var originalName = Path.GetFileName(file.FileName);
        if (originalName.Length > 160) originalName = originalName[^160..];
        await using (var output = System.IO.File.Create(Path.Combine(_attachments, saved))) await file.CopyToAsync(output);
        lock (TemplateFileLock)
        {
            var t = ReadTemplate();
            t.Attachments.Add(new MailAttachment { Name = originalName, SavedName = saved });
            SaveTemplate(t);
        }
        TempData["MailInfo"] = "Doküman eklendi.";
        return RedirectToAction(nameof(Admin));
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public IActionResult RemoveDocument(string savedName)
    {
        lock (TemplateFileLock)
        {
            var t = ReadTemplate();
            var a = t.Attachments.FirstOrDefault(x => x.SavedName == savedName);
            if (a != null)
            {
                t.Attachments.Remove(a);
                SaveTemplate(t);
                if (Path.GetFileName(a.SavedName) == a.SavedName)
                    System.IO.File.Delete(Path.Combine(_attachments, a.SavedName));
            }
        }
        return RedirectToAction(nameof(Admin));
    }
}
