﻿namespace BtOperasyonTakip.Security;

public static class AppRoles
{
    public const string Admin = "Admin";
    public const string Operasyon = "Operasyon";
    public const string OperasyonSuperAdmin = "OperasyonSuperAdmin";
    public const string Saha = "Saha";
    public const string SahaSuperAdmin = "SahaSuperAdmin";
    public const string Uyum = "Uyum";
    public const string KurumsalSaha = "KurumsalSaha";
    public const string VposKullanici = "VPOS";
}