(() => { const shade=document.getElementById('hubBackdrop');let active=null;let previous=null;function close(){if(!active)return;active.classList.remove('is-open');active.setAttribute('aria-hidden','true');shade.hidden=true;document.body.style.overflow='';active=null;if(previous)previous.focus();}document.querySelectorAll('[data-drawer]').forEach(button=>button.addEventListener('click',()=>{const panel=document.getElementById(button.dataset.drawer);if(!panel)return;previous=button;active=panel;panel.classList.add('is-open');panel.setAttribute('aria-hidden','false');shade.hidden=false;document.body.style.overflow='hidden';panel.querySelector('.hub-close')?.focus();}));document.querySelectorAll('.hub-close').forEach(b=>b.addEventListener('click',close));shade?.addEventListener('click',close);document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});const openOnLoad=document.getElementById('hubOpenAfterSave')?.dataset.id;if(openOnLoad){document.querySelector('[data-drawer="detail-'+openOnLoad+'"]')?.click();}
})();

// Jira-style board/list toggle. All entries share the same detail drawers.
document.querySelectorAll('[data-view]').forEach(btn => btn.addEventListener('click', () => {
  const list = btn.dataset.view === 'list';
  document.querySelector('.hub-kanban').hidden = list;
  document.querySelector('.hub-list-view').hidden = !list;
  document.querySelectorAll('.hub-view-btn').forEach(b=>b.classList.toggle('is-active',b.dataset.view===btn.dataset.view));
}));

// Filter and group ALL cards without deleting them or changing server-side access.
(() => {
 const board=document.querySelector('.hub-kanban'), groupSelect=document.getElementById('hubGroupBy');
 if(!board)return;
 const columns=Array.from(board.querySelectorAll('.hub-column'));
 const liveSearch=document.getElementById('hubLiveSearch');
 let textQuery='';
 const lists=columns.map(c=>c.querySelector('.hub-card-list'));
 const source=lists.map(list=>Array.from(list.querySelectorAll('.hub-task')));
 const quickButtons=Array.from(document.querySelectorAll('[data-quick]'));
 const current=quickButtons.find(b=>b.dataset.quick==='mine')?.dataset.currentUser?.trim().toLocaleLowerCase('tr-TR')||'';
 let quick='all';
 const normalize=s=>(s||'').trim().toLocaleLowerCase('tr-TR');
 function matches(node){
  if(textQuery && !normalize(node.dataset.search).includes(textQuery))return false;
  if(quick==='all')return true;
  if(quick==='mine')return Boolean(current)&&normalize(node.dataset.assignee)===current;
  return node.dataset.module===quick;
 }
 function rebuild(){
  const group=groupSelect?.value||'none';
  lists.forEach((list,i)=>{
   list.replaceChildren();
   const visible=source[i].filter(matches);
   const counter=columns[i].querySelector('.hub-col-head>span');
   if(counter)counter.textContent=String(visible.length);
   const empty=()=>{const div=document.createElement('div');div.className='hub-empty';div.textContent='Bu filtrede iş bulunmuyor.';list.append(div)};
   if(!visible.length){empty();return;}
   if(group==='none'){visible.slice(0,6).forEach(card=>list.append(card));const extra=columns[i].querySelector('.hub-more-button');if(extra){extra.hidden=visible.length<=6;extra.textContent=`${visible.length-6} iş daha · Listede aç`; }return;}
   const buckets=new Map();
   visible.forEach(card=>{
    const key=group==='module' ? ({OPERASYON:'PF',VPOS:'VPOS',MOBIL:'Cüzdan'}[card.dataset.module]||'Diğer') : (card.dataset.assignee?.trim()||'Atanmamış');
    if(!buckets.has(key))buckets.set(key,[]);buckets.get(key).push(card);
   });
   let remaining=6;
   for(const [key,cards] of [...buckets].sort((a,b)=>a[0].localeCompare(b[0],'tr'))){
    if(remaining<=0)break;const shown=cards.slice(0,remaining);remaining-=shown.length;
    const lane=document.createElement('section');lane.className='hub-swimlane';
    const head=document.createElement('button');head.type='button';head.className='hub-swimlane-head';head.setAttribute('aria-expanded','true');
    const name=document.createElement('span');name.textContent=key;const n=document.createElement('span');n.className='hub-swimlane-count';n.textContent=String(cards.length);head.append(name,n);
    const content=document.createElement('div');content.className='hub-swimlane-items';shown.forEach(card=>content.append(card));
    head.addEventListener('click',()=>{lane.classList.toggle('is-collapsed');head.setAttribute('aria-expanded',String(!lane.classList.contains('is-collapsed')))});
    lane.append(head,content);list.append(lane);
   }
   const extra=columns[i].querySelector('.hub-more-button');if(extra){extra.hidden=visible.length<=6;extra.textContent=`${Math.max(visible.length-6,0)} iş daha · Listede aç`;}
  });
  document.querySelectorAll('.hub-list-view tbody tr').forEach(row=>{row.dataset.quickHidden=matches(row)?'0':'1';});
  document.dispatchEvent(new Event('hub:filter-changed'));
 }
 quickButtons.forEach(button=>button.addEventListener('click',()=>{
  quick=button.dataset.quick;quickButtons.forEach(b=>b.classList.toggle('is-active',b===button));rebuild();
 }));
 groupSelect?.addEventListener('change',rebuild);
 liveSearch?.addEventListener('input',()=>{textQuery=normalize(liveSearch.value);rebuild();});
 document.getElementById('hubCompact')?.addEventListener('change',e=>board.classList.toggle('is-compact',e.target.checked));
 rebuild();
})();
// Liste görünümünde tüm yetkili kayıtları göster; yalnızca arama ve hızlı filtre uygula.
(() => {
 const panel=document.querySelector('.hub-list-view');if(!panel)return;
 const rows=Array.from(panel.querySelectorAll('tbody tr'));
 function render(){rows.forEach(row=>row.hidden=row.dataset.quickHidden==='1');}
 document.addEventListener('hub:filter-changed',render);render();
})();
