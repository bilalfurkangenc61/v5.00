﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Linq;

namespace BtOperasyonTakip.Pages.Admin
{
    [Authorize(Roles = "Admin")]
    public class UserManagementModel : PageModel
    {
        private readonly AppDbContext _context;
        public List<User> Users { get; set; } = new();

        public UserManagementModel(AppDbContext context)
        {
            _context = context;
        }

        public void OnGet()
        {
            LoadUsers();
        }

        public IActionResult OnPostMakeSahaSuperAdmin(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
            {
                TempData["Error"] = "Kullanıcı bulunamadı.";
                return RedirectToPage();
            }

            if (!IsSahaFamilyRole(user.Role))
            {
                TempData["Error"] = "Sadece saha kullanıcıları Saha Süper Admin yapılabilir.";
                return RedirectToPage();
            }

            user.Role = AppRoles.SahaSuperAdmin;
            _context.SaveChanges();

            TempData["Success"] = $"{GetUserDisplayName(user)} is now a Field Super Admin.";
            return RedirectToPage();
        }

        public IActionResult OnPostRevokeSahaSuperAdmin(int id)
        {
            var user = _context.Users.Find(id);
            if (user == null)
            {
                TempData["Error"] = "Kullanıcı bulunamadı.";
                return RedirectToPage();
            }

            if (!IsSahaSuperAdminRole(user.Role))
            {
                TempData["Error"] = "Bu kullanıcı zaten Saha Süper Admin değil.";
                return RedirectToPage();
            }

            user.Role = AppRoles.Saha;
            _context.SaveChanges();

            TempData["Success"] = $"{GetUserDisplayName(user)} was changed to a standard Field user.";
            return RedirectToPage();
        }

        public IActionResult OnPostDelete(int id)
        {
            var user = _context.Users.Find(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
                TempData["Success"] = "Kullanıcı başarıyla silindi.";
            }
            else
            {
                TempData["Error"] = "Kullanıcı bulunamadı.";
            }
            return RedirectToPage();
        }

        private void LoadUsers()
        {
            Users = _context.Users
                .OrderBy(u => u.Role)
                .ThenBy(u => u.FullName ?? u.UserName)
                .ToList();
        }

        public static bool IsSahaFamilyRole(string? role)
        {
            role = (role ?? string.Empty).Trim();

            return string.Equals(role, AppRoles.Saha, System.StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, AppRoles.KurumsalSaha, System.StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Kurumsal Saha", System.StringComparison.OrdinalIgnoreCase) ||
                   IsSahaSuperAdminRole(role);
        }

        public static bool IsSahaSuperAdminRole(string? role)
        {
            role = (role ?? string.Empty).Trim();

            return string.Equals(role, AppRoles.SahaSuperAdmin, System.StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Saha Süper Admin", System.StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Saha Super Admin", System.StringComparison.OrdinalIgnoreCase);
        }

        public static string GetRoleDisplayName(string? role)
        {
            role = (role ?? string.Empty).Trim();

            return role switch
            {
                AppRoles.Admin => "Admin",
                AppRoles.Operasyon => "Operations",
                AppRoles.Saha => "Field",
                AppRoles.SahaSuperAdmin => "Field Super Admin",
                AppRoles.KurumsalSaha => "Corporate Field",
                AppRoles.Uyum => "Uyum",
                AppRoles.VposKullanici => "VPOS User",
                "Kurumsal Saha" => "Kurumsal Saha",
                _ when !string.IsNullOrWhiteSpace(role) => role,
                _ => "Saha"
            };
        }

        public static string GetUserDisplayName(User user)
        {
            return !string.IsNullOrWhiteSpace(user.FullName)
                ? user.FullName!
                : user.UserName;
        }
    }
}
