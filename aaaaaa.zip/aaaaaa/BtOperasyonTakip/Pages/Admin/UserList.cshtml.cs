﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BtOperasyonTakip.Pages.Admin
{
    [Authorize(Roles = AppRoles.Admin)]
    public class UserListModel : PageModel
    {
        private readonly AppDbContext _context;

        public List<User> Users { get; set; } = new();

        public UserListModel(AppDbContext context)
        {
            _context = context;
        }

        public void OnGet()
        {
            LoadUsers();
        }

        public IActionResult OnPostMakeSahaSuperAdmin(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                TempData["Error"] = "Kullanıcı bulunamadı.";
                return RedirectToPage("/Admin/UserList");
            }

            if (!IsSahaFamilyRole(user.Role))
            {
                TempData["Error"] = "Sadece saha kullanıcıları Saha Süper Admin yapılabilir.";
                return RedirectToPage("/Admin/UserList");
            }

            user.Role = AppRoles.SahaSuperAdmin;
            _context.Entry(user).Property(x => x.Role).IsModified = true;
            _context.SaveChanges();

            TempData["Success"] = $"{GetUserDisplayName(user)} is now a Field Super Admin.";
            return RedirectToPage("/Admin/UserList");
        }

        public IActionResult OnPostRevokeSahaSuperAdmin(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                TempData["Error"] = "Kullanıcı bulunamadı.";
                return RedirectToPage("/Admin/UserList");
            }

            if (!IsSahaSuperAdminRole(user.Role))
            {
                TempData["Error"] = "Bu kullanıcı zaten Saha Süper Admin değil.";
                return RedirectToPage("/Admin/UserList");
            }

            user.Role = AppRoles.Saha;
            _context.Entry(user).Property(x => x.Role).IsModified = true;
            _context.SaveChanges();

            TempData["Success"] = $"{GetUserDisplayName(user)} was changed to a standard Field user.";
            return RedirectToPage("/Admin/UserList");
        }

        public IActionResult OnPostMakeOperasyonSuperAdmin(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                TempData["Error"] = "Kullanıcı bulunamadı.";
                return RedirectToPage("/Admin/UserList");
            }

            if (!IsOperasyonFamilyRole(user.Role))
            {
                TempData["Error"] = "Sadece operasyon kullanıcıları Operasyon Süper Admin yapılabilir.";
                return RedirectToPage("/Admin/UserList");
            }

            user.Role = AppRoles.OperasyonSuperAdmin;
            _context.Entry(user).Property(x => x.Role).IsModified = true;
            _context.SaveChanges();

            TempData["Success"] = $"{GetUserDisplayName(user)} is now an Operations Super Admin.";
            return RedirectToPage("/Admin/UserList");
        }

        public IActionResult OnPostRevokeOperasyonSuperAdmin(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                TempData["Error"] = "Kullanıcı bulunamadı.";
                return RedirectToPage("/Admin/UserList");
            }

            if (!IsOperasyonSuperAdminRole(user.Role))
            {
                TempData["Error"] = "Bu kullanıcı zaten Operasyon Süper Admin değil.";
                return RedirectToPage("/Admin/UserList");
            }

            user.Role = AppRoles.Operasyon;
            _context.Entry(user).Property(x => x.Role).IsModified = true;
            _context.SaveChanges();

            TempData["Success"] = $"{GetUserDisplayName(user)} was changed to a standard Operations user.";
            return RedirectToPage("/Admin/UserList");
        }

        public IActionResult OnPostDelete(int id)
        {
            var user = _context.Users.FirstOrDefault(u => u.Id == id);
            if (user == null)
            {
                TempData["Error"] = "Kullanıcı bulunamadı.";
                return RedirectToPage("/Admin/UserList");
            }

            _context.Users.Remove(user);
            _context.SaveChanges();

            TempData["Success"] = "Kullanıcı başarıyla silindi.";
            return RedirectToPage("/Admin/UserList");
        }

        private void LoadUsers()
        {
            Users = _context.Users
                .AsNoTracking()
                .OrderBy(u => u.Role)
                .ThenBy(u => u.FullName ?? u.UserName)
                .ToList();
        }

        public static bool IsSahaFamilyRole(string? role)
        {
            role = NormalizeRole(role);

            return string.Equals(role, AppRoles.Saha, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, AppRoles.KurumsalSaha, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Kurumsal Saha", StringComparison.OrdinalIgnoreCase) ||
                   IsSahaSuperAdminRole(role);
        }

        public static bool IsSahaSuperAdminRole(string? role)
        {
            role = NormalizeRole(role);

            return string.Equals(role, AppRoles.SahaSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Saha Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Saha Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        public static bool IsOperasyonFamilyRole(string? role)
        {
            role = NormalizeRole(role);

            return string.Equals(role, AppRoles.Operasyon, StringComparison.OrdinalIgnoreCase) ||
                   IsOperasyonSuperAdminRole(role);
        }

        public static bool IsOperasyonSuperAdminRole(string? role)
        {
            role = NormalizeRole(role);

            return string.Equals(role, AppRoles.OperasyonSuperAdmin, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Operasyon Süper Admin", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(role, "Operasyon Super Admin", StringComparison.OrdinalIgnoreCase);
        }

        public static string GetRoleDisplayName(string? role)
        {
            role = NormalizeRole(role);

            return role switch
            {
                AppRoles.Admin => "Admin",
                AppRoles.Operasyon => "Operations",
                AppRoles.OperasyonSuperAdmin => "Operations Super Admin",
                AppRoles.Saha => "Field",
                AppRoles.SahaSuperAdmin => "Field Super Admin",
                AppRoles.KurumsalSaha => "Corporate Field",
                AppRoles.Uyum => "Uyum",
                AppRoles.VposKullanici => "VPOS User",
                "Kurumsal Saha" => "Kurumsal Saha",
                "Saha Süper Admin" => "Saha Süper Admin",
                "Saha Super Admin" => "Saha Süper Admin",
                "Operasyon Süper Admin" => "Operasyon Süper Admin",
                "Operasyon Super Admin" => "Operasyon Süper Admin",
                _ when !string.IsNullOrWhiteSpace(role) => role,
                _ => "Saha"
            };
        }

        public static string GetUserDisplayName(User user)
        {
            if (!string.IsNullOrWhiteSpace(user.FullName))
            {
                return user.FullName!;
            }

            return !string.IsNullOrWhiteSpace(user.UserName) ? user.UserName : "-";
        }

        private static string NormalizeRole(string? role)
        {
            return (role ?? string.Empty).Trim();
        }
    }
}
