using BtOperasyonTakip.Data;
using BtOperasyonTakip.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using System.Globalization;

var builder = WebApplication.CreateBuilder(args);

// ============================================================
// DATABASE
// ============================================================

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")));

// ============================================================
// MVC / RAZOR
// ============================================================

builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();

// ============================================================
// LOCALIZATION
// ============================================================

builder.Services.AddLocalization(options =>
    options.ResourcesPath = "Resources");

// ============================================================
// BACKGROUND SERVICE
// ============================================================

builder.Services.AddHostedService<MonthlyArchiveService>();

// ============================================================
// DATA PROTECTION
// Grafana kişisel giriş bilgileri şifreli saklanır.
// Anahtarlar kalıcıdır; uygulama restartında bilgiler çözülmeye devam eder.
// ============================================================

var dataProtectionKeyPath = Path.Combine(
    builder.Environment.ContentRootPath,
    "App_Data",
    "DataProtectionKeys");

Directory.CreateDirectory(dataProtectionKeyPath);

builder.Services
    .AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(dataProtectionKeyPath))
    .SetApplicationName("BtOperasyonTakip");

// ============================================================
// VPOS GRAFANA / ELASTIC
// ============================================================

builder.Services.Configure<VposGrafanaDashboardOptions>(
    builder.Configuration.GetSection("VposGrafanaDashboard"));

builder.Services.AddScoped<
    IVposMonitoringCredentialStore,
    VposMonitoringCredentialStore>();

builder.Services
    .AddHttpClient<IVposGrafanaDashboardGateway, VposGrafanaDashboardGateway>(client =>
    {
        client.Timeout = TimeSpan.FromSeconds(45);
    })
    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
    {
        AllowAutoRedirect = false
    });

// ============================================================
// SESSION
// ============================================================

builder.Services.AddDistributedMemoryCache();
builder.Services.AddMemoryCache();

builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(12);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

// ============================================================
// AUTHENTICATION
// ============================================================

builder.Services
    .AddAuthentication(
        CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Auth/Login";
        options.LogoutPath = "/Auth/Logout";
        options.AccessDeniedPath = "/Auth/Login";
        options.ExpireTimeSpan = TimeSpan.FromDays(7);
        options.SlidingExpiration = true;
    });

builder.Services.AddAuthorization();

var app = builder.Build();

// ============================================================
// MIGRATION BİLEREK YOK
// ============================================================
// Database.Migrate() YOK.
// Gerçek mevcut DB doğrudan kullanılıyor.
// ============================================================

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

// ============================================================
// LOCALIZATION
// ============================================================

var supportedCultures = new[]
{
    new CultureInfo("tr-TR"),
    new CultureInfo("en-US")
};

var localizationOptions = new RequestLocalizationOptions
{
    DefaultRequestCulture = new RequestCulture("tr-TR"),
    SupportedCultures = supportedCultures,
    SupportedUICultures = supportedCultures
};

localizationOptions.RequestCultureProviders.Insert(
    0,
    new QueryStringRequestCultureProvider
    {
        QueryStringKey = "lang",
        UIQueryStringKey = "lang"
    });

app.UseRequestLocalization(localizationOptions);

// ============================================================
// PIPELINE
// ============================================================

app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();

// ============================================================
// ROUTES
// ============================================================

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Auth}/{action=Login}/{id?}");

app.MapRazorPages();
app.Run();
