﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BtOperasyonTakip.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class IssueController : ControllerBase
    {
        private readonly AppDbContext _context;

        public IssueController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("report")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult<Issue>> ReportIssue([FromBody] CreateIssueDto dto)
        {
            var title = (dto.Title ?? string.Empty).Trim();
            var description = (dto.Description ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(title) || title.Length > 200)
                return BadRequest("Başlık zorunludur ve 200 karakteri aşamaz.");
            if (description.Length > 4000)
                return BadRequest("Açıklama 4000 karakteri aşamaz.");

            var issue = new Issue
            {
                Title = title,
                Description = description,
                Reporter = User.Identity?.Name ?? "Sistem",
                Status = IssueStatus.Bekleme,
                CreatedAt = DateTime.UtcNow
            };

            _context.Issues.Add(issue);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetIssue), new { id = issue.Id }, issue);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Issue>> GetIssue(int id)
        {
            var issue = await _context.Issues.FindAsync(id);
            if (issue == null)
                return NotFound();
            return issue;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Issue>>> GetAllIssues()
        {
            return await _context.Issues.OrderByDescending(i => i.CreatedAt).ToListAsync();
        }
    }

    public class CreateIssueDto
    {
        public string Title { get; set; } = "";
        public string? Description { get; set; }
        public string? Reporter { get; set; }
    }
}