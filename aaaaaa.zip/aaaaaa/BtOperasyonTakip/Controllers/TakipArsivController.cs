﻿using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Globalization;

namespace BtOperasyonTakip.Controllers
{
    [Authorize]
    public class TakipArsivController : Controller
    {
        private readonly AppDbContext _context;

        public TakipArsivController(AppDbContext context)
        {
            _context = context;
        }

        private static string TranslateExportValue(string? value, bool isEn)
        {
            if (!isEn || string.IsNullOrWhiteSpace(value))
                return value ?? string.Empty;

            return value.Trim() switch
            {
                "Detaylar" => "Details",
                "İş Takip" => "Work Tracking",
                "Beklemede" => "Pending",
                "Aktif" => "Active",
                "Pasif" => "Inactive",
                "Tamamlandı" => "Completed",
                "Döküman İletildi" => "Document Sent",
                "Dokuman İletildi" => "Document Sent",
                "Satışa Bilgi Verildi" => "Sales Informed",
                "Entegrasyon Tamamlandı" => "Integration Completed",
                "Canlıda Entegrasyon Tamamlandı" => "Live Integration Completed",
                "Entegrasyon Tamamlanmadı" => "Integration Not Completed",
                "Uyum Onayında" => "Compliance Approval",
                "Arşiv" => "Archive",
                "Geliştirme" => "Development",
                "Eğitim" => "Training",
                "Entegrasyon" => "Integration",
                "Hata Çözüm" => "Issue Resolution",
                _ => value
            };
        }

        private static string NormalizeDurum(string? durum)
        {
            return (durum ?? string.Empty).Trim();
        }

        private static bool DurumEquals(string? left, string? right)
        {
            return string.Equals(
                NormalizeDurum(left),
                NormalizeDurum(right),
                StringComparison.OrdinalIgnoreCase);
        }

        private static string GetArsivdeGosterilecekDurum(JiraTask task, Dictionary<int, string> musteriDurumById)
        {
            var taskDurum = NormalizeDurum(task.Durum);

            
            
            if (DurumEquals(taskDurum, "Arşiv") &&
                task.MusteriID.HasValue &&
                task.MusteriID.Value > 0 &&
                musteriDurumById.TryGetValue(task.MusteriID.Value, out var musteriDurum) &&
                !string.IsNullOrWhiteSpace(musteriDurum))
            {
                return NormalizeDurum(musteriDurum);
            }

            return taskDurum;
        }

        private static List<string> DistinctDurumlarPreserveOrder(IEnumerable<string?> values)
        {
            var result = new List<string>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var value in values)
            {
                var durum = NormalizeDurum(value);

                if (string.IsNullOrWhiteSpace(durum))
                    continue;

                if (seen.Add(durum))
                    result.Add(durum);
            }

            return result;
        }

        private List<string> GetTumDurumSecenekleri()
        {
            
            
            var parametreDurumlari = _context.Parametreler
                .AsNoTracking()
                .Where(p => p.Tur != null && p.Tur != string.Empty && p.ParAdi != null && p.ParAdi != string.Empty)
                .OrderBy(p => p.Id)
                .Select(p => new { p.Tur, p.ParAdi })
                .ToList()
                .Where(p => DurumEquals(p.Tur, "Durum"))
                .Select(p => p.ParAdi);

            
            var taskDurumlari = _context.JiraTasks
                .AsNoTracking()
                .Where(x => x.Durum != null && x.Durum != string.Empty)
                .Select(x => x.Durum)
                .ToList();

            var musteriDurumlari = _context.Musteriler
                .AsNoTracking()
                .Where(x => x.Durum != null && x.Durum != string.Empty)
                .Select(x => x.Durum)
                .ToList();

            var sabitDurumlar = new[]
            {
                "Beklemede",
                "Aktif",
                "Döküman İletildi",
                "Satışa Bilgi Verildi",
                "Entegrasyon Tamamlandı",
                "Entegrasyon Tamamlanmadı",
                "Uyum Onayında"
            };

            return DistinctDurumlarPreserveOrder(
                parametreDurumlari
                    .Concat(sabitDurumlar)
                    .Concat(taskDurumlari)
                    .Concat(musteriDurumlari));
        }

        private static bool ContainsInsensitive(string? source, string value)
        {
            return !string.IsNullOrWhiteSpace(source) &&
                   source.Contains(value, StringComparison.OrdinalIgnoreCase);
        }

        private static bool MatchesArsivSearch(JiraTask task, string q)
        {
            q = (q ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(q))
                return true;

            return ContainsInsensitive(task.MusteriAdi, q) ||
                   ContainsInsensitive(task.JiraId, q) ||
                   ContainsInsensitive(task.TalepKonusu, q) ||
                   ContainsInsensitive(task.TalepTuru, q) ||
                   ContainsInsensitive(task.TalepAcan, q) ||
                   ContainsInsensitive(task.TakipEden, q) ||
                   ContainsInsensitive(task.Durum, q);
        }

        [HttpGet]
        public IActionResult Index(string? q, string? ay, string? durum, string? lang)
        {
            
            if (!string.IsNullOrWhiteSpace(lang))
            {
                try
                {
                    var culture = lang.StartsWith("en", StringComparison.OrdinalIgnoreCase) ? new CultureInfo("en-US") : new CultureInfo("tr-TR");
                    CultureInfo.CurrentCulture = culture;
                    CultureInfo.CurrentUICulture = culture;
                }
                catch
                {
                    
                }
            }
            q = (q ?? string.Empty).Trim();
            var selectedDurum = NormalizeDurum(durum);
            var durumList = GetTumDurumSecenekleri();

            ViewBag.DurumList = durumList;
            ViewBag.SelectedDurum = selectedDurum;

            var months = _context.JiraTasks
                .AsNoTracking()
                .Select(x => x.OlusturmaTarihi)
                .ToList()
                .Select(dt => new DateTime(dt.Year, dt.Month, 1))
                .Distinct()
                .OrderByDescending(x => x)
                .ToList();

            ViewBag.AvailableAylar = months;

            DateTime? filterMonthStart = null;
            DateTime? filterNextMonthStart = null;

            if (!string.IsNullOrWhiteSpace(ay) &&
                DateTime.TryParseExact(
                    ay.Trim(),
                    "yyyy-MM",
                    CultureInfo.InvariantCulture,
                    DateTimeStyles.None,
                    out var parsed))
            {
                filterMonthStart = new DateTime(parsed.Year, parsed.Month, 1);
                filterNextMonthStart = filterMonthStart.Value.AddMonths(1);
                ViewBag.SelectedAy = filterMonthStart.Value.ToString("yyyy-MM");
            }
            else
            {
                ViewBag.SelectedAy = string.Empty;
            }

            var query = _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .AsQueryable();

            var now = DateTime.Now;
            var currentMonthStart = new DateTime(now.Year, now.Month, 1);

            if (filterMonthStart.HasValue && filterNextMonthStart.HasValue)
            {
                var start = filterMonthStart.Value;
                var end = filterNextMonthStart.Value;

                query = query.Where(x =>
                    x.OlusturmaTarihi >= start &&
                    x.OlusturmaTarihi < end);
            }

            if (!string.IsNullOrWhiteSpace(q))
            {
                var qq = q.ToLowerInvariant();

                query = query.Where(t =>
                    (t.MusteriAdi ?? string.Empty).ToLower().Contains(qq) ||
                    (t.JiraId ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepKonusu ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepTuru ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TalepAcan ?? string.Empty).ToLower().Contains(qq) ||
                    (t.TakipEden ?? string.Empty).ToLower().Contains(qq) ||
                    (t.Durum ?? string.Empty).ToLower().Contains(qq));
            }

            var musteriLookup = _context.Musteriler
                .AsNoTracking()
                .ToDictionary(m => m.MusteriID, m => m.Firma);

            var musteriDurumById = _context.Musteriler
                .AsNoTracking()
                .ToDictionary(x => x.MusteriID, x => NormalizeDurum(x.Durum));

            var all = query.ToList();

            foreach (var task in all)
            {
                task.Durum = GetArsivdeGosterilecekDurum(task, musteriDurumById);
            }

            if (!string.IsNullOrWhiteSpace(selectedDurum))
            {
                all = all
                    .Where(t => DurumEquals(t.Durum, selectedDurum))
                    .ToList();
            }

            var yorumLookup = _context.JiraYorumlar
                .AsNoTracking()
                .Where(y => y.YorumMetni == "Arşivlendi")
                .GroupBy(y => y.JiraTaskId)
                .ToDictionary(g => g.Key, g => g.Max(y => y.Tarih));

            var tasks = all
                .OrderByDescending(t => yorumLookup.TryGetValue(t.Id, out var dt)
                    ? dt
                    : t.OlusturmaTarihi)
                .ToList();

            IQueryable<Detay> detayQuery = _context.Detaylar.AsNoTracking();

            if (filterMonthStart.HasValue && filterNextMonthStart.HasValue)
            {
                var s = filterMonthStart.Value;
                var e = filterNextMonthStart.Value;

                detayQuery = detayQuery.Where(d => d.Tarih >= s && d.Tarih < e);
            }
            else
            {
                detayQuery = detayQuery.Where(d =>
                    d.Tarih < currentMonthStart ||
                    d.Tarih >= currentMonthStart);
            }

            var detaylar = detayQuery
                .OrderByDescending(d => d.Tarih)
                .ToList()
                .Where(d =>
                    !string.IsNullOrWhiteSpace(d.Kekleyen) &&
                    !string.Equals(d.Kekleyen.Trim(), "Sistem", StringComparison.OrdinalIgnoreCase))
                .Where(d =>
                    !string.Equals(
                        (d.Gorusulen ?? string.Empty).Trim(),
                        "İş Takip Yorumu",
                        StringComparison.OrdinalIgnoreCase))
                .ToList();

            var legacyTasks = detaylar.Select(d => new JiraTask
            {
                Id = -d.DetayID,
                MusteriID = d.MusteriID,
                MusteriAdi = musteriLookup.TryGetValue(d.MusteriID, out var ma)
                    ? ma
                    : string.Empty,
                JiraId = string.Empty,
                TalepKonusu = string.IsNullOrWhiteSpace(d.Gorusulen)
                    ? "Detay"
                    : d.Gorusulen.Trim(),
                TalepTuru = "Detay",
                TalepAcan = string.IsNullOrWhiteSpace(d.Kekleyen)
                    ? "-"
                    : d.Kekleyen.Trim(),
                Durum = musteriDurumById.TryGetValue(d.MusteriID, out var md)
                    ? md
                    : "Aktif",
                TakipEden = d.Kekleyen,
                OlusturmaTarihi = d.Tarih,
                Yorumlar = new List<JiraYorum>()
            }).ToList();

            if (!string.IsNullOrWhiteSpace(selectedDurum))
            {
                legacyTasks = legacyTasks
                    .Where(t => DurumEquals(t.Durum, selectedDurum))
                    .ToList();
            }

            if (!string.IsNullOrWhiteSpace(q))
            {
                legacyTasks = legacyTasks
                    .Where(t => MatchesArsivSearch(t, q))
                    .ToList();
            }

            tasks = tasks
                .Concat(legacyTasks)
                .OrderByDescending(t => yorumLookup.TryGetValue(t.Id, out var dt)
                    ? dt
                    : t.OlusturmaTarihi)
                .ToList();

            var archiveDateByTask = tasks.ToDictionary(
                t => t.Id,
                t => yorumLookup.TryGetValue(t.Id, out var dt) ? (DateTime?)dt : null);

            ViewBag.ArchiveDateByTask = archiveDateByTask;

            var operasyonKullaniciList = _context.Users
                .AsNoTracking()
                .Where(u => u.Role == AppRoles.Operasyon)
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct()
                .OrderBy(x => x)
                .ToList();

            var latestDetailByMusteri = _context.Detaylar
                .AsNoTracking()
                .OrderByDescending(d => d.Tarih)
                .ThenByDescending(d => d.DetayID)
                .ToList()
                .GroupBy(d => d.MusteriID)
                .ToDictionary(g => g.Key, g => g.First());

            var taskLatestDetaylar = tasks.ToDictionary(
                t => t.Id,
                t => t.MusteriID.HasValue &&
                     t.MusteriID.Value > 0 &&
                     latestDetailByMusteri.TryGetValue(t.MusteriID.Value, out var det)
                    ? det
                    : null);

            var taskMusteriDurumlari = tasks.ToDictionary(
                t => t.Id,
                t => t.MusteriID.HasValue &&
                     t.MusteriID.Value > 0 &&
                     musteriDurumById.TryGetValue(t.MusteriID.Value, out var d)
                    ? d
                    : string.Empty);

            ViewBag.KullaniciSecenekleri = operasyonKullaniciList;
            ViewBag.TaskLatestDetaylar = taskLatestDetaylar;
            ViewBag.TaskMusteriDurumlari = taskMusteriDurumlari;

            ViewBag.Title = "Archive - Other Work";
            ViewBag.Q = q;
            ViewBag.Lang = string.IsNullOrWhiteSpace(lang) ? "en" : lang;

            return View("~/Views/Takip/Arsiv.cshtml", tasks);
        }

        [HttpGet]
        public async Task<IActionResult> DetailCard(int id, string? lang)
        {
            if (!string.IsNullOrWhiteSpace(lang))
            {
                try
                {
                    var culture = lang.StartsWith("en", StringComparison.OrdinalIgnoreCase) ? new CultureInfo("en-US") : new CultureInfo("tr-TR");
                    CultureInfo.CurrentCulture = culture;
                    CultureInfo.CurrentUICulture = culture;
                }
                catch { }
            }
            int? musteriId = null;
            string musteriAdi = string.Empty;

            
            
            if (id < 0)
            {
                var detayId = Math.Abs(id);

                var detay = await _context.Detaylar
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.DetayID == detayId);

                if (detay == null)
                    return NotFound("Detail record was not found.");

                musteriId = detay.MusteriID;
            }
            else
            {
                var task = await _context.JiraTasks
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.Id == id);

                if (task == null)
                    return NotFound("Work tracking record was not found.");

                musteriId = task.MusteriID;
            }

            if (!musteriId.HasValue || musteriId.Value <= 0)
                return NotFound("Customer information was not found.");

            var musteri = await _context.Musteriler
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.MusteriID == musteriId.Value);

            if (musteri != null)
                musteriAdi = musteri.Firma ?? string.Empty;

            var detaylar = await _context.Detaylar
                .AsNoTracking()
                .Where(x => x.MusteriID == musteriId.Value)
                .OrderByDescending(x => x.Tarih)
                .ThenByDescending(x => x.DetayID)
                .ToListAsync();

            var operasyonKullaniciList = await _context.Users
                .AsNoTracking()
                .Where(u => u.Role == BtOperasyonTakip.Security.AppRoles.Operasyon)
                .Select(x => string.IsNullOrWhiteSpace(x.FullName) ? x.UserName : x.FullName!)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();

            ViewBag.MusteriID = musteriId.Value;
            ViewBag.MusteriAdi = musteriAdi;
            ViewBag.KullaniciSecenekleri = operasyonKullaniciList;

            return PartialView("~/Views/Takip/_DetailCard.cshtml", detaylar);
        }
        [HttpGet]
        public IActionResult ExportExcel(string? q, string? ay, string? durum, string? lang)
        {
            if (!string.IsNullOrWhiteSpace(lang))
            {
                try
                {
                    var culture = lang.StartsWith("en", StringComparison.OrdinalIgnoreCase)
                        ? new CultureInfo("en-US")
                        : new CultureInfo("tr-TR");

                    CultureInfo.CurrentCulture = culture;
                    CultureInfo.CurrentUICulture = culture;
                }
                catch
                {
                    
                }
            }

            
            
            
            
            var taskList = _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .OrderByDescending(x => x.OlusturmaTarihi)
                .ToList();

            var yorumLookup = _context.JiraYorumlar
                .AsNoTracking()
                .GroupBy(y => y.JiraTaskId)
                .ToDictionary(g => g.Key, g => g.OrderBy(y => y.Tarih).ToList());

            var archiveDateLookup = _context.JiraYorumlar
                .AsNoTracking()
                .Where(y => y.YorumMetni == "Arşivlendi")
                .GroupBy(y => y.JiraTaskId)
                .ToDictionary(g => g.Key, g => g.Max(y => y.Tarih));

            var musteriLookup = _context.Musteriler
                .AsNoTracking()
                .ToDictionary(m => m.MusteriID, m => m.Firma);

            var musteriDurumById = _context.Musteriler
                .AsNoTracking()
                .ToDictionary(x => x.MusteriID, x => NormalizeDurum(x.Durum));

            var rows = taskList.Select(x => new TakipArsivExcelRow
            {
                Kaynak = string.Equals(x.TalepTuru, "Detay", StringComparison.OrdinalIgnoreCase)
                    ? "Detay"
                    : "Takip",
                MusteriAdi = x.MusteriAdi,
                JiraId = x.JiraId,
                TalepKonusu = x.TalepKonusu,
                TalepTuru = x.TalepTuru,
                TalepAcan = x.TalepAcan,
                TakipEden = x.TakipEden,
                Durum = GetArsivdeGosterilecekDurum(x, musteriDurumById),
                OlusturmaTarihi = x.OlusturmaTarihi,
                ArchiveDate = archiveDateLookup.TryGetValue(x.Id, out var ad) ? (DateTime?)ad : null,
                Yorumlar = yorumLookup.TryGetValue(x.Id, out var y)
                    ? string.Join("\n\n", y.Select(c =>
                        $"{c.Tarih:dd.MM.yyyy HH:mm} - {((c.Ekleyen ?? string.Empty).Trim())}\n{(c.YorumMetni ?? string.Empty)}"))
                    : string.Empty
            }).ToList();

            var detaylar = _context.Detaylar
                .AsNoTracking()
                .OrderByDescending(d => d.Tarih)
                .ToList()
                .Where(d =>
                    !string.IsNullOrWhiteSpace(d.Kekleyen) &&
                    !string.Equals(d.Kekleyen.Trim(), "Sistem", StringComparison.OrdinalIgnoreCase))
                .Where(d =>
                    !string.Equals(
                        (d.Gorusulen ?? string.Empty).Trim(),
                        "İş Takip Yorumu",
                        StringComparison.OrdinalIgnoreCase))
                .ToList();

            rows.AddRange(detaylar.Select(d => new TakipArsivExcelRow
            {
                Kaynak = "Detay",
                MusteriAdi = musteriLookup.TryGetValue(d.MusteriID, out var musteriAdi)
                    ? musteriAdi
                    : string.Empty,
                JiraId = string.Empty,
                TalepKonusu = string.IsNullOrWhiteSpace(d.Gorusulen)
                    ? "Detay"
                    : d.Gorusulen.Trim(),
                TalepTuru = "Detay",
                TalepAcan = string.IsNullOrWhiteSpace(d.Kekleyen)
                    ? "-"
                    : d.Kekleyen.Trim(),
                TakipEden = d.Kekleyen,
                Durum = musteriDurumById.TryGetValue(d.MusteriID, out var musteriDurum)
                    ? musteriDurum
                    : string.Empty,
                OlusturmaTarihi = d.Tarih,
                ArchiveDate = null,
                Yorumlar = string.IsNullOrWhiteSpace(d.Aciklama)
                    ? string.Empty
                    : $"{d.Tarih:dd.MM.yyyy HH:mm} - {((d.Kekleyen ?? string.Empty).Trim())}\n{d.Aciklama}"
            }));

            rows = rows
                .OrderByDescending(x => x.ArchiveDate ?? x.OlusturmaTarihi)
                .ThenByDescending(x => x.OlusturmaTarihi)
                .ToList();

            bool isEn = string.IsNullOrWhiteSpace(lang) || lang.StartsWith("en", StringComparison.OrdinalIgnoreCase);

            var headers = isEn
                ? new[] { "Source", "Customer", "Jira No", "Request Subject", "Request Type", "Requested By", "Assigned To", "Status", "Created Date", "Completion/Archive Date", "Comments" }
                : new[] { "Kaynak", "Müşteri", "Jira No", "Talep Konusu", "Talep Türü", "Talep Açan", "Takip Eden", "Durum", "Oluşturma Tarihi", "Tamamlanma/Arşiv Tarihi", "Yorumlar" };

            using var ms = new MemoryStream();

            using (var document = SpreadsheetDocument.Create(ms, SpreadsheetDocumentType.Workbook, true))
            {
                var workbookPart = document.AddWorkbookPart();
                workbookPart.Workbook = new Workbook();

                var stylesPart = workbookPart.AddNewPart<WorkbookStylesPart>();

                var numberingFormats = new NumberingFormats();
                uint dateFormatId = 164;

                numberingFormats.Append(new NumberingFormat
                {
                    NumberFormatId = dateFormatId,
                    FormatCode = StringValue.FromString("dd.MM.yyyy HH:mm")
                });

                var fonts = new Fonts(
                    new Font(),
                    new Font(new Bold())
                );

                var fills = new Fills(
                    new Fill(new PatternFill { PatternType = PatternValues.None }),
                    new Fill(new PatternFill { PatternType = PatternValues.Gray125 }),
                    new Fill(new PatternFill(
                        new ForegroundColor { Rgb = HexBinaryValue.FromString("FFDCE6F1") })
                    {
                        PatternType = PatternValues.Solid
                    })
                );

                var borders = new Borders(new Border());
                var cellStyleFormats = new CellStyleFormats(new CellFormat());

                var cellFormats = new CellFormats(
                    new CellFormat(),
                    new CellFormat
                    {
                        FontId = 1U,
                        FillId = 2U,
                        ApplyFont = true,
                        ApplyFill = true
                    },
                    new CellFormat
                    {
                        NumberFormatId = dateFormatId,
                        ApplyNumberFormat = true
                    },
                    new CellFormat
                    {
                        Alignment = new Alignment { WrapText = true },
                        ApplyAlignment = true
                    }
                );

                var stylesheet = new Stylesheet();
                stylesheet.Append(numberingFormats);
                stylesheet.Append(fonts);
                stylesheet.Append(fills);
                stylesheet.Append(borders);
                stylesheet.Append(cellStyleFormats);
                stylesheet.Append(cellFormats);

                stylesPart.Stylesheet = stylesheet;
                stylesPart.Stylesheet.Save();

                var sheets = workbookPart.Workbook.AppendChild(new Sheets());
                var sheetPart = workbookPart.AddNewPart<WorksheetPart>();

                var columns = new Columns(
                    new Column { Min = 1, Max = 1, Width = 10, CustomWidth = true },
                    new Column { Min = 2, Max = 2, Width = 28, CustomWidth = true },
                    new Column { Min = 3, Max = 3, Width = 12, CustomWidth = true },
                    new Column { Min = 4, Max = 4, Width = 36, CustomWidth = true },
                    new Column { Min = 5, Max = 5, Width = 16, CustomWidth = true },
                    new Column { Min = 6, Max = 6, Width = 16, CustomWidth = true },
                    new Column { Min = 7, Max = 7, Width = 20, CustomWidth = true },
                    new Column { Min = 8, Max = 8, Width = 28, CustomWidth = true },
                    new Column { Min = 9, Max = 9, Width = 20, CustomWidth = true },
                    new Column { Min = 10, Max = 10, Width = 20, CustomWidth = true },
                    new Column { Min = 11, Max = 11, Width = 70, CustomWidth = true }
                );

                var sheetData = new SheetData();

                var worksheet = new Worksheet();
                worksheet.Append(columns);
                worksheet.Append(sheetData);

                var headerRow = new Row();

                foreach (var h in headers)
                {
                    headerRow.Append(new Cell
                    {
                        DataType = CellValues.InlineString,
                        InlineString = new InlineString(new Text(h)),
                        StyleIndex = 1U
                    });
                }

                sheetData.Append(headerRow);

                foreach (var r in rows)
                {
                    var row = new Row();

                    void AddText(string? value, uint style = 0U)
                    {
                        row.Append(new Cell
                        {
                            DataType = CellValues.InlineString,
                            InlineString = new InlineString(new Text(value ?? string.Empty)
                            {
                                Space = SpaceProcessingModeValues.Preserve
                            }),
                            StyleIndex = style
                        });
                    }

                    void AddDate(DateTime? date)
                    {
                        if (date.HasValue)
                        {
                            row.Append(new Cell
                            {
                                CellValue = new CellValue(date.Value.ToOADate().ToString(CultureInfo.InvariantCulture)),
                                StyleIndex = 2U
                            });
                        }
                        else
                        {
                            row.Append(new Cell
                            {
                                DataType = CellValues.InlineString,
                                InlineString = new InlineString(new Text(string.Empty))
                            });
                        }
                    }

                    AddText(TranslateExportValue(r.Kaynak, isEn));
                    AddText(r.MusteriAdi);
                    AddText(r.JiraId);
                    AddText(r.TalepKonusu);
                    AddText(TranslateExportValue(r.TalepTuru, isEn));
                    AddText(r.TalepAcan);
                    AddText(r.TakipEden);
                    AddText(TranslateExportValue(r.Durum, isEn));
                    AddDate(r.OlusturmaTarihi);
                    AddDate(r.ArchiveDate);
                    AddText(r.Yorumlar, 3U);

                    sheetData.Append(row);
                }

                var lastRowIndex = (uint)Math.Max(rows.Count + 1, 1);
                var filterRange = $"A1:K{lastRowIndex}";

                var sheetViews = new SheetViews(
                    new SheetView
                    {
                        WorkbookViewId = 0U,
                        Pane = new Pane
                        {
                            VerticalSplit = 1D,
                            TopLeftCell = "A2",
                            ActivePane = PaneValues.BottomLeft,
                            State = PaneStateValues.Frozen
                        }
                    });

                worksheet.InsertAt(sheetViews, 0);
                worksheet.Append(new AutoFilter { Reference = filterRange });

                if (rows.Any())
                {
                    var tableDefinitionPart = sheetPart.AddNewPart<TableDefinitionPart>();
                    tableDefinitionPart.Table = new Table
                    {
                        Id = 1U,
                        Name = "ArsivTablo",
                        DisplayName = "ArsivTablo",
                        Reference = filterRange,
                        TotalsRowShown = false
                    };

                    tableDefinitionPart.Table.AppendChild(new AutoFilter { Reference = filterRange });
                    tableDefinitionPart.Table.AppendChild(new TableColumns(
                        new TableColumn { Id = 1U, Name = headers[0] },
                        new TableColumn { Id = 2U, Name = headers[1] },
                        new TableColumn { Id = 3U, Name = headers[2] },
                        new TableColumn { Id = 4U, Name = headers[3] },
                        new TableColumn { Id = 5U, Name = headers[4] },
                        new TableColumn { Id = 6U, Name = headers[5] },
                        new TableColumn { Id = 7U, Name = headers[6] },
                        new TableColumn { Id = 8U, Name = headers[7] },
                        new TableColumn { Id = 9U, Name = headers[8] },
                        new TableColumn { Id = 10U, Name = headers[9] },
                        new TableColumn { Id = 11U, Name = headers[10] }
                    )
                    { Count = 11U });

                    tableDefinitionPart.Table.AppendChild(new TableStyleInfo
                    {
                        Name = "TableStyleMedium2",
                        ShowFirstColumn = false,
                        ShowLastColumn = false,
                        ShowRowStripes = true,
                        ShowColumnStripes = false
                    });

                    tableDefinitionPart.Table.Save();

                    var tableParts = new TableParts { Count = 1U };
                    tableParts.Append(new TablePart { Id = sheetPart.GetIdOfPart(tableDefinitionPart) });
                    worksheet.Append(tableParts);
                }

                sheetPart.Worksheet = worksheet;
                sheetPart.Worksheet.Save();

                sheets.Append(new Sheet
                {
                    Id = workbookPart.GetIdOfPart(sheetPart),
                    SheetId = 1,
                    Name = isEn ? "Archive" : "Arsiv"
                });

                workbookPart.Workbook.Save();
            }

            ms.Position = 0;

            var fileName = isEn
                ? $"Archive_AllMonths_{DateTime.Now:yyyyMMdd_HHmm}.xlsx"
                : $"Arsiv_TumAylar_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";

            return File(
                ms.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }
        private sealed class TakipArsivExcelRow
        {
            public string? Kaynak { get; set; }
            public string? MusteriAdi { get; set; }
            public string? JiraId { get; set; }
            public string? TalepKonusu { get; set; }
            public string? TalepTuru { get; set; }
            public string? TalepAcan { get; set; }
            public string? TakipEden { get; set; }
            public string? Durum { get; set; }
            public DateTime OlusturmaTarihi { get; set; }
            public DateTime? ArchiveDate { get; set; }
            public string? Yorumlar { get; set; }
        }

    }
}