﻿using Microsoft.AspNetCore.Mvc;

namespace BtOperasyonTakip.Controllers
{
    public class WelcomeController : Controller
    {
        public IActionResult Index()
        {
            ViewData["Title"] = "Welcome Page";
            return View();
        }
    }
}
