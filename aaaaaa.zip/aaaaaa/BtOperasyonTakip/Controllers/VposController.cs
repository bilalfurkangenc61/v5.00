using BtOperasyonTakip.Data;
using BtOperasyonTakip.Dtos;
using BtOperasyonTakip.Models;
using BtOperasyonTakip.Security;
using BtOperasyonTakip.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System.Globalization;
using System.Text;

namespace BtOperasyonTakip.Controllers
{
    [Authorize(Roles = AppRoles.VposKullanici + "," + AppRoles.Operasyon + "," + AppRoles.OperasyonSuperAdmin + ",Operasyon Süper Admin,Operasyon Super Admin," + AppRoles.Admin)]
    public class VposController : Controller
    {
        private const string OperasyonCustomerParamType = "UrunMusteri:OPERASYON";
        private const string VposCustomerParamType = "UrunMusteri:VPOS";
        private const string MobilCustomerParamType = "UrunMusteri:MOBIL";
        private const string ProductConfiguredParamType = "UrunMusteri:YAPILANDIRILDI";
        private const string MusteriVknParamType = "MusteriEk:VKN";
        private const string MusteriHariciIdParamType = "MusteriEk:HARICI_ID";
        private const string VposTaskPrefix = "[VPOS] ";
        private const string VposErrorParamType = "UrunHata:VPOS";
        private readonly AppDbContext _context;
        private readonly IVposGrafanaDashboardGateway _dashboardGateway;
        private readonly IVposMonitoringCredentialStore _credentialStore;
        private readonly IMemoryCache _cache;

        public VposController(
            AppDbContext context,
            IVposGrafanaDashboardGateway dashboardGateway,
            IVposMonitoringCredentialStore credentialStore,
            IMemoryCache cache)
        {
            _context = context;
            _dashboardGateway = dashboardGateway;
            _credentialStore = credentialStore;
            _cache = cache;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return RedirectToAction(nameof(AnaSayfa));
        }


        // ============================================================
        // VPOS CANLI MONITORING - MEVCUT VPOS ALANININ İÇİNDE
        // DB entity/model değişikliği yok. Veriler Grafana dashboard
        // sorguları üzerinden alınır; Elastic/Kibana linki dashboard
        // data-link tanımından okunur.
        // ============================================================

        [HttpGet]
        public async Task<IActionResult> AnaSayfa(string aralik = "30m", bool yenile = false, CancellationToken cancellationToken = default)
        {
            // Bu işaret çalıştırılan Controller sürümünü Razor görünümünden ayırır.
            ViewData["GrafanaControllerRevision"] = "VPOS-L3-v16";
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();

            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            var vm = new VposOverviewVm
            {
                CredentialsSaved = credential != null,
                Username = credential?.Username,
                DashboardUrl = credential?.DashboardUrl
            };

            if (credential == null)
            {
                vm.Message = "Grafana dashboard bağlantısı için bilgilerinizi bir kez kaydedin.";
                return View(vm);
            }

            // Ana ekranın firma grafiği işlem panellerinden, hata grafiği hata panellerinden
            // ayrı ayrı beslenir. Böylece hata satırları firma işlem sayısına karışmaz.
            aralik = NormalizeRange(aralik);
            vm.SelectedRange = aralik;
            var now = DateTime.Now;
            var firstMonth = new DateTime(now.Year, now.Month, 1).AddMonths(-5);
            var from = now - RangeDuration(aralik);
            var filter = new VposMonitoringFilter { From = from, To = now, PageSize = 250 };

            // Read the existing Grafana panels; no new API credentials or direct Elastic connection.
            // Cache only successful reads. Two concurrent dashboard reads prevent a burst of requests.
            using var gate = new SemaphoreSlim(2);
            async Task<VposMonitoringResult> Fetch(string purpose)
            {
                var key = $"vpos:overview:{purpose}:{userId}:{aralik}";
                if (!yenile && _cache.TryGetValue(key, out VposMonitoringResult? cached) && cached != null)
                    return cached;
                await gate.WaitAsync(cancellationToken);
                try
                {
                    var loaded = await _dashboardGateway.QueryAsync(credential, filter, purpose, cancellationToken);
                    if (loaded.Success) _cache.Set(key, loaded, TimeSpan.FromSeconds(45));
                    return loaded;
                }
                finally { gate.Release(); }
            }

            var transactionsTask = Fetch("transactions");
            // Always query the dedicated API call bar panel instead of hoping it
            // survives the generic transaction panel limit.
            var apiCallsTask = Fetch("api-calls");
            var errorsTask = Fetch("errors");
            var summaryTask = Fetch("summary");
            // Ortalama süre ve yüzdelik paneller kaldırıldı; gereksiz Grafana çağrısı yapılmaz.
            var alarmsTask = Fetch("alarms");
            var timeoutsTask = Fetch("timeouts");
            var importantTask = Fetch("important-errors");
            // Compare with the preceding equal-duration window. Reuse existing
            // Grafana session and dashboard panel queries (no direct Elasticsearch).
            var previousKey = $"vpos:previous:errors:{userId}:{aralik}";
            async Task<VposMonitoringResult> PreviousErrorsAsync()
            {
                if (!yenile && _cache.TryGetValue(previousKey, out VposMonitoringResult? cached) && cached != null)
                    return cached;
                await gate.WaitAsync(cancellationToken);
                try
                {
                    var previousFilter = new VposMonitoringFilter
                    {
                        From = from - RangeDuration(aralik), To = from, PageSize = 250
                    };
                    var value = await _dashboardGateway.QueryAsync(credential, previousFilter, "errors", cancellationToken);
                    if (value.Success) _cache.Set(previousKey, value, TimeSpan.FromSeconds(45));
                    return value;
                }
                finally { gate.Release(); }
            }
            var previousErrorsTask = PreviousErrorsAsync();
            await Task.WhenAll(transactionsTask, apiCallsTask, errorsTask, summaryTask, alarmsTask,
                timeoutsTask, importantTask, previousErrorsTask);
            var transactions = await transactionsTask;
            var apiCalls = await apiCallsTask;
            var errors = await errorsTask;
            var summary = await summaryTask;
            var alarms = await alarmsTask;
            var timeouts = await timeoutsTask;
            var important = await importantTask;
            var previousErrors = await previousErrorsTask;

            vm.Connected = transactions.Success || errors.Success || summary.Success;
            vm.Message = vm.Connected
                ? $"Grafana verileri güncellendi. İşlem: {transactions.Message} Hatalar: {errors.Message}"
                : $"Grafana panel sorguları başarısız. İşlem: {transactions.Message} Hatalar: {errors.Message}";
            vm.DashboardTitle = transactions.DashboardTitle ?? errors.DashboardTitle ?? summary.DashboardTitle;
            vm.RetrievedAt = new[] { transactions.RetrievedAt, errors.RetrievedAt, summary.RetrievedAt }.Max();

            vm.TotalApiCalls = StatValue(summary, "Toplam API", "Total API");
            vm.SuccessfulApiCalls = StatValue(summary, "Başarılı API", "Basarili API", "Successful API");
            vm.FailedApiCalls = StatValue(summary, "Başarısız API", "Basarisiz API", "Failed API");
            vm.ActiveIncidents = StatValue(summary, "Aktif Incident", "Active Incident");
            vm.ActiveAlerts = StatValue(summary, "Aktif Alert", "Active Alert");
            vm.HttpErrorRatePercent = StatDouble(summary, "HTTP Error Rate");

            vm.TotalCompanyCount = transactions.Companies.Count;
            var currentMonthStart = new DateTime(now.Year, now.Month, 1);
            vm.ThisMonthActiveCompanyCount = transactions.Rows
                .Where(x => x.Timestamp.HasValue && x.Timestamp.Value >= currentMonthStart)
                .Select(x => x.Customer)
                .Where(x => !string.IsNullOrWhiteSpace(x) && x != "-")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count();
            vm.TotalRowCount = transactions.Rows.Sum(x => Math.Max(0L, x.Count));
            vm.TotalErrorCount = errors.Rows.Sum(x => Math.Max(0L, x.Count));
            var merchantPanelRows = transactions.Rows.Where(x =>
                x.PanelTitle.Contains("Top 15 İşyeri", StringComparison.OrdinalIgnoreCase) ||
                x.PanelTitle.Contains("Top 15 Isyeri", StringComparison.OrdinalIgnoreCase) ||
                x.PanelTitle.Contains("Top Merchant", StringComparison.OrdinalIgnoreCase)).ToList();
            vm.TopCompanies = merchantPanelRows.Count > 0
                ? merchantPanelRows.Where(x => x.Customer != "-" && !string.IsNullOrWhiteSpace(x.Customer))
                    .GroupBy(x => x.Customer, StringComparer.OrdinalIgnoreCase)
                    .Select(g => new VposCountItem { Key = g.Key, Count = g.Sum(x => Math.Max(0L, x.Count)) })
                    .OrderByDescending(x => x.Count).Take(5).ToList()
                : transactions.Companies.OrderByDescending(x => x.Count).Take(5).ToList();
            var apiRows = apiCalls.Success ? apiCalls.Rows : new List<VposMonitoringRow>();
            // Dedicated SPI/API bar chart panels may contain endpoint names without GET/POST prefixes.
            // Count only rows from the dedicated panel, never error rows as API calls.
            vm.TopEndpoints = apiRows
                .Where(x => x.Count > 0 && !string.IsNullOrWhiteSpace(x.ApiEndpoint) && x.ApiEndpoint != "-")
                .GroupBy(x => x.ApiEndpoint.Trim(), StringComparer.OrdinalIgnoreCase)
                .Select(g => new VposCountItem { Key = g.Key, Count = g.Sum(x => Math.Max(0L, x.Count)) })
                .OrderByDescending(x => x.Count).Take(15).ToList();
            vm.ApiCallsStatus = vm.TopEndpoints.Count > 0 ? null :
                apiCalls.Success ? "SPI/API paneli yanıt verdi ancak API adı ve çağrı adedi çözümlenemedi: " + apiCalls.Message
                    : "Grafana API çağrı paneli sorgusu başarısız: " + apiCalls.Message;

            // Prefer Grafana's actual live-error table. Aggregated code/count bars
            // are not individual log events and should not masquerade as live logs.
            var livePanelRows = errors.Rows.Where(x =>
                x.PanelTitle.Contains("Canlı Hata", StringComparison.OrdinalIgnoreCase) ||
                x.PanelTitle.Contains("Canli Hata", StringComparison.OrdinalIgnoreCase) ||
                x.PanelTitle.Contains("Live Error", StringComparison.OrdinalIgnoreCase)).ToList();
            var liveCandidates = livePanelRows.Concat(errors.Rows.Where(x => x.Timestamp.HasValue && !x.IsAggregate))
                .Concat(important.Success ? important.Rows.Where(x => !x.IsAggregate) : Enumerable.Empty<VposMonitoringRow>());
            vm.LiveErrors = liveCandidates
                .Where(x => !x.IsAggregate && (x.Timestamp.HasValue || x.TraceId != "-") &&
                    (ValidErrorCode(x.NormalizedCode) || x.HasRawLogMessage))
                .GroupBy(x => string.Join("|", x.TraceId, x.NormalizedCode, x.Timestamp?.ToString("O") ?? "", x.Message), StringComparer.OrdinalIgnoreCase)
                .Select(g => g.First())
                .OrderByDescending(x => x.Timestamp ?? DateTime.MinValue).Take(60).ToList();
            // Count each normalized error code independently. Distinct Grafana
            // panels may repeat the same aggregate; do not double-count it.
            var allCodes = PreferredCodeCounts(errors.Rows.Concat(important.Success
                ? important.Rows.Where(r => !r.IsAggregate) : Enumerable.Empty<VposMonitoringRow>()));
            vm.TopErrors = allCodes.Take(5).ToList();
            // All codes remain visible in a dedicated explanation table, not just the top five.
            ViewData["AllErrorCodes"] = allCodes;

            // Grafana's important-errors log table carries real individual events
            // (Code 96, Trace ID, merchant_id, RRN, API, duration). Never treat a
            // pie's aggregated code/count as a transaction event.
            vm.ImportantErrorLogs = important.Success
                ? important.Rows.Where(r => !r.IsAggregate &&
                    (r.Timestamp.HasValue || r.TraceId != "-" || r.Rrn != "-"))
                    .OrderByDescending(r => r.Timestamp ?? DateTime.MinValue).Take(100).ToList()
                : new List<VposMonitoringRow>();
            var rawErrorEvents = vm.ImportantErrorLogs.Concat(vm.LiveErrors)
                .Where(r => !r.IsAggregate && r.TraceId != "-" && ValidErrorCode(r.NormalizedCode))
                .GroupBy(r => string.Join("|", r.TraceId, r.NormalizedCode,
                    r.Timestamp?.ToString("O") ?? "", r.Customer), StringComparer.OrdinalIgnoreCase)
                .Select(g => g.First()).ToList();
            vm.ErrorTraceGroups = vm.TopErrors.Select(e => new VposErrorTraceGroup
            {
                Code = e.Key,
                SummaryCount = e.Count,
                Traces = rawErrorEvents.Where(r => string.Equals(r.NormalizedCode, e.Key, StringComparison.OrdinalIgnoreCase))
                    .OrderByDescending(r => r.Timestamp).Take(12).ToList()
            }).ToList();
            vm.Code96Logs = vm.ImportantErrorLogs
                .Where(r => r.NormalizedCode == "96").Take(40).ToList();
            // A count from a dedicated summary may be incomplete. No synthetic zero.
            var code96Summary = errors.Errors.FirstOrDefault(x =>
                VposErrorCatalog.NormalizeIso(x.Key) == "96");
            vm.Code96SummaryCount = code96Summary?.Count;
            vm.ImportantErrorStatus = important.Success
                ? (vm.ImportantErrorLogs.Count == 0
                    ? "Önemli Hatalar Kibana Log paneli tekil işlem kaydı döndürmedi; Grafana panelini ve sorgu yetkisini kontrol edin."
                    : $"Önemli Hatalar panelinden {vm.ImportantErrorLogs.Count} tekil kayıt alındı. Panelin satır sınırı geçerlidir.")
                : "Önemli Hatalar paneli sorgulanamadı: " + important.Message;
            // Separate bank and merchant drill-downs: never infer a bank/firm from
            // a generic code or fabricate missing merchant labels.
            vm.MerchantErrorBreakdown = Breakdown(errors.Rows, x => x.Customer);
            vm.LiveMessageCount = vm.LiveErrors.Count(x => x.HasRawLogMessage && x.Message != "-");
            vm.LiveMerchantCount = vm.LiveErrors.Count(x => x.Customer != "-");
            vm.ErrorDetailStatus = vm.LiveErrors.Count == 0
                ? "Grafana canlı hata paneli işlem düzeyinde kayıt döndürmedi. Özet hata adetleri işlem detayına eşit değildir."
                : vm.LiveMerchantCount == 0
                    ? "Canlı loglarda firma alanı bulunamadı; dashboard üzerinde merchant bilgisinin sorgulanması gerekiyor."
                    : null;

            // VS01/VS05 are queried independently from the displayed Top 5.
            // An absent code in limited Grafana panels is *unknown*, not zero.
            if (timeouts.Success)
            {
                vm.Vs01Count = TimeoutCount(timeouts.Rows, "VS01");
                vm.Vs05Count = TimeoutCount(timeouts.Rows, "VS05");
                vm.TimeoutStatus = vm.Vs01Count.HasValue || vm.Vs05Count.HasValue
                    ? "Grafana timeout/hata panellerinden alınan kayıtlar. Kaynak panel limitleri geçerlidir."
                    : "VS01/VS05 bu dashboard panellerinin sonucunda bulunamadı. Bu, sıfır timeout olduğu anlamına gelmez.";
            }
            else vm.TimeoutStatus = "Timeout sorgusu başarısız: " + timeouts.Message;

            if (errors.Success && previousErrors.Success)
            {
                var currentTotal = PreferredErrorTotal(errors.Rows);
                var previousTotal = PreferredErrorTotal(previousErrors.Rows);
                if (currentTotal.HasValue && previousTotal.HasValue)
                {
                    vm.CurrentErrorCount = currentTotal;
                    vm.PreviousErrorCount = previousTotal;
                    vm.ErrorChangePercent = previousTotal > 0
                        ? 100d * (currentTotal.Value - previousTotal.Value) / previousTotal.Value
                        : null;
                    vm.ErrorComparisonStatus = previousTotal == 0
                        ? "Önceki dönemde hata kaydı yok; yüzde artış hesaplanamaz."
                        : "Seçilen aralık, hemen önceki eşit süreli aralıkla karşılaştırıldı.";
                }
                else vm.ErrorComparisonStatus = "Karşılaştırılabilir hata toplulaştırması bulunamadı.";
            }
            else vm.ErrorComparisonStatus = "Önceki dönem Grafana sorgusu okunamadı; karşılaştırma yapılamadı.";

            vm.Sources = errors.Sources.Take(10).ToList();

            // Bank and VPOS error distribution panels deliberately omitted
            // from the operations homepage per the monitoring layout request.
            vm.SystemAlarms = ReadAlarms(alarms);
            vm.SystemAlarmsStatus = alarms.Success
                ? (vm.SystemAlarms.Count == 0
                    ? "Canlı Sistem Alarmları detay paneli okunabildi fakat Host/Problem sütunları bulunamadı. " + alarms.Message
                    : "Zabbix/sistem alarm panellerinde Trace ID yoksa bu olaylar işlem loglarına otomatik bağlanamaz.")
                : "Canlı Sistem Alarmları sorgusu başarısız: " + alarms.Message;

            var months = Enumerable.Range(0, 6).Select(i => firstMonth.AddMonths(i)).ToList();
            vm.Months = months.Select(x => x.ToString("MMM yy", CultureInfo.GetCultureInfo("tr-TR"))).ToList();
            foreach (var company in vm.TopCompanies)
            {
                var series = new VposCompanyMonthlySeries { Company = company.Key };
                foreach (var month in months)
                {
                    var next = month.AddMonths(1);
                    series.Values.Add(transactions.Rows
                        .Where(x => x.Timestamp.HasValue &&
                                    x.Timestamp.Value >= month && x.Timestamp.Value < next &&
                                    string.Equals(x.Customer, company.Key, StringComparison.OrdinalIgnoreCase))
                        .Sum(x => Math.Max(0L, x.Count)));
                }
                vm.TopCompanyMonthlySeries.Add(series);
            }

            return View(vm);
        }

        private static bool IsApiEndpoint(string? value) =>
            !string.IsNullOrWhiteSpace(value) &&
            new[] { "GET ", "POST ", "PUT ", "PATCH ", "DELETE ", "OPTIONS ", "HEAD ", "/api/" }
                .Any(prefix => value.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));

        private static bool ValidErrorCode(string? code)
        {
            if (string.IsNullOrWhiteSpace(code)) return false;
            var normalized = VposErrorCatalog.NormalizeIso(code);
            return System.Text.RegularExpressions.Regex.IsMatch(normalized, @"^(?:\d{2,3}|VB\d{2}|VS\d{2})$",
                System.Text.RegularExpressions.RegexOptions.IgnoreCase);
        }

        private static List<VposCountItem> PreferredCodeCounts(IEnumerable<VposMonitoringRow> rows)
        {
            var valid = rows.Where(x => ValidErrorCode(x.NormalizedCode)).ToList();
            return valid.GroupBy(x => VposErrorCatalog.NormalizeIso(x.NormalizedCode), StringComparer.OrdinalIgnoreCase)
                .Select(group =>
                {
                    var aggregatePanels = group.Where(x => x.IsAggregate)
                        .GroupBy(x => x.PanelTitle, StringComparer.OrdinalIgnoreCase)
                        .Select(panel => panel.Sum(x => Math.Max(0L, x.Count))).ToList();
                    var value = aggregatePanels.Count > 0 ? aggregatePanels.Max() : group.LongCount();
                    return new VposCountItem { Key = group.Key, Count = value };
                }).Where(x => x.Count > 0).OrderByDescending(x => x.Count).ThenBy(x => x.Key).ToList();
        }

        private static List<VposCountItem> Breakdown(
            IEnumerable<VposMonitoringRow> rows, Func<VposMonitoringRow, string> valueSelector) =>
            rows.Where(x => x.RawCode != "-" && valueSelector(x) != "-" &&
                            !string.IsNullOrWhiteSpace(valueSelector(x)))
                .GroupBy(valueSelector, StringComparer.OrdinalIgnoreCase)
                .Select(g => new VposCountItem { Key = g.Key, Count = g.Sum(x => Math.Max(0L, x.Count)) })
                .OrderByDescending(x => x.Count).Take(10).ToList();

        private static long? TimeoutCount(IEnumerable<VposMonitoringRow> rows, string code)
        {
            var matching = rows.Where(r =>
                string.Equals(r.NormalizedCode, code, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(r.RawCode.Trim('*'), code, StringComparison.OrdinalIgnoreCase)).ToList();
            if (matching.Count == 0) return null;
            // A dashboard may include both detail and aggregate panels. Prefer
            // code aggregate, never sum duplicates across those panel types.
            var aggregate = matching.Where(r => r.IsAggregate).ToList();
            if (aggregate.Count > 0)
                return aggregate.GroupBy(r => r.PanelTitle)
                    .Select(g => g.Sum(r => Math.Max(0L, r.Count))).Max();
            return matching.LongCount();
        }

        private static long? PreferredErrorTotal(IEnumerable<VposMonitoringRow> rows)
        {
            var aggregates = rows.Where(r => r.IsAggregate && r.RawCode != "-").ToList();
            if (aggregates.Count > 0)
                return aggregates.GroupBy(r => r.PanelTitle)
                    .Select(g => g.Sum(x => Math.Max(0L, x.Count))).DefaultIfEmpty(0).Max();
            var events = rows.Where(r => !r.IsAggregate && r.RawCode != "-").ToList();
            return events.Count > 0 ? events.LongCount() : null;
        }

        private static double? TryDurationMs(VposMonitoringRow row)
        {
            var keysMs = new[] { "durationMs", "elapsedMs", "responseTimeMs", "duration_ms", "elapsed_ms", "latency_ms", "response_time_ms" };
            var keysSeconds = new[] { "durationSeconds", "elapsedSeconds", "responseTimeSeconds", "duration_seconds" };
            foreach (var key in keysMs.Concat(keysSeconds))
            {
                var value = row.Fields.FirstOrDefault(f =>
                    f.Key.Equals(key, StringComparison.OrdinalIgnoreCase) ||
                    f.Key.EndsWith("." + key, StringComparison.OrdinalIgnoreCase)).Value;
                if (double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var ms))
                {
                    if (keysSeconds.Contains(key)) ms *= 1000;
                    if (double.IsFinite(ms) && ms >= 0 && ms < 1800000) return ms;
                }
            }
            return null;
        }

        private static double Percentile(IReadOnlyList<double> sorted, double p)
        {
            var index = (sorted.Count - 1) * p;
            var low = (int)Math.Floor(index);
            var high = (int)Math.Ceiling(index);
            return sorted[low] + (sorted[high] - sorted[low]) * (index - low);
        }

        private static long? StatValue(VposMonitoringResult data, params string[] titles)
        {
            var value = StatDouble(data, titles);
            return value.HasValue ? (long?)Math.Round(value.Value) : null;
        }

        private static double? StatDouble(VposMonitoringResult data, params string[] titles)
        {
            if (!data.Success) return null;
            var rows = data.Rows.Where(x => titles.Any(t => x.PanelTitle.Contains(t, StringComparison.OrdinalIgnoreCase)))
                .OrderByDescending(x => x.Timestamp ?? DateTime.MinValue);
            foreach (var row in rows)
            {
                var numeric = MetricNumber(row.Fields);
                if (numeric.HasValue) return numeric;
            }
            return null;
        }

        private static double? MetricNumber(IReadOnlyDictionary<string, string> fields)
        {
            // Grafana frame fields are typically "Time" + "Value". Never turn missing
            // data or an actual zero into a fake count of one.
            var named = fields.Where(x =>
                x.Key.Equals("Value", StringComparison.OrdinalIgnoreCase) ||
                x.Key.Equals("Last", StringComparison.OrdinalIgnoreCase) ||
                x.Key.Equals("Mean", StringComparison.OrdinalIgnoreCase) ||
                x.Key.Equals("Avg", StringComparison.OrdinalIgnoreCase) ||
                x.Key.Equals("Count", StringComparison.OrdinalIgnoreCase)).ToList();
            foreach (var candidate in named.Concat(fields.Where(x =>
                !x.Key.Contains("time", StringComparison.OrdinalIgnoreCase) &&
                !x.Key.Contains("timestamp", StringComparison.OrdinalIgnoreCase) &&
                !x.Key.Contains("date", StringComparison.OrdinalIgnoreCase) &&
                !x.Key.Contains("code", StringComparison.OrdinalIgnoreCase) &&
                !x.Key.Equals("id", StringComparison.OrdinalIgnoreCase) &&
                !x.Key.EndsWith("_id", StringComparison.OrdinalIgnoreCase) &&
                !x.Key.EndsWith("Id", StringComparison.Ordinal))))
            {
                if (double.TryParse(candidate.Value, NumberStyles.Float,
                    CultureInfo.InvariantCulture, out var number) && double.IsFinite(number)) return number;
            }
            return null;
        }

        private static List<VposCountItem> GroupErrorPanel(IEnumerable<VposMonitoringRow> rows, params string[] names) =>
            rows.Where(r => names.Any(t => r.PanelTitle.Contains(t, StringComparison.OrdinalIgnoreCase)) &&
                            !string.IsNullOrWhiteSpace(r.RawCode) && r.RawCode != "-")
                .GroupBy(r => r.RawCode, StringComparer.OrdinalIgnoreCase)
                .Select(g => new VposCountItem { Key = g.Key, Count = g.Sum(x => Math.Max(0L, x.Count)) })
                .OrderByDescending(x => x.Count).Take(8).ToList();

        private static List<VposResponseTimePoint> ResponseSeries(VposMonitoringResult data)
        {
            if (!data.Success) return new();
            var points = data.Rows.Where(x => x.Timestamp.HasValue)
                .Select(x => new { Time = x.Timestamp!.Value, Value = MetricNumber(x.Fields) })
                .Where(x => x.Value.HasValue && x.Value.Value >= 0)
                .GroupBy(x => x.Time)
                .Select(x => new VposResponseTimePoint { At = x.Key, Value = x.Average(v => v.Value!.Value) })
                .OrderBy(x => x.At).ToList();
            if (points.Count <= 100) return points;
            return Enumerable.Range(0, 100)
                .Select(i => points[(int)Math.Round(i * (points.Count - 1) / 99d)])
                .ToList();
        }

        private static List<VposSystemAlarm> ReadAlarms(VposMonitoringResult data)
        {
            if (!data.Success) return new();
            return data.Rows.Select(x => new VposSystemAlarm
            {
                Host = AlarmField(x.Fields, "Host", "Host Name", "host.name", "hostname"),
                HostGroups = AlarmField(x.Fields, "Host Groups", "Host Group", "host_groups", "Group"),
                Severity = AlarmField(x.Fields, "Severity", "Priority", "Level"),
                Problem = AlarmField(x.Fields, "Problem", "Problem Name", "Event Name", "Alert Message", "Trigger", "Description"),
                GrafanaUrl = x.GrafanaUrl,
                EventId = AlarmField(x.Fields, "eventid", "event_id", "Incident ID", "alertId"),
                OccurredAt = x.Timestamp?.ToString("dd.MM.yyyy HH:mm:ss"),
                TraceId = x.TraceId != "-" ? x.TraceId : AlarmField(x.Fields, "trace_id", "Trace ID", "traceId")
            })
            .Where(x => x.Problem != "-" || x.Host != "-")
            .Take(100).ToList();
        }

        private static string AlarmField(IReadOnlyDictionary<string, string> fields, params string[] keys)
        {
            foreach (var key in keys)
            {
                var value = fields.FirstOrDefault(x => x.Key.Equals(key, StringComparison.OrdinalIgnoreCase)).Value;
                if (!string.IsNullOrWhiteSpace(value)) return value;
            }
            foreach (var key in keys)
            {
                var value = fields.FirstOrDefault(x => x.Key.Contains(key, StringComparison.OrdinalIgnoreCase)).Value;
                if (!string.IsNullOrWhiteSpace(value)) return value;
            }
            return "-";
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GrafanaBaglan(
            string dashboardUrl,
            string? grafanaUsername,
            string? grafanaPassword,
            string? elasticUrl,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();

            dashboardUrl = (dashboardUrl ?? string.Empty).Trim();
            grafanaUsername = (grafanaUsername ?? string.Empty).Trim();
            grafanaPassword ??= string.Empty;
            elasticUrl = string.IsNullOrWhiteSpace(elasticUrl) ? string.Empty : elasticUrl.Trim();

            if (string.IsNullOrWhiteSpace(dashboardUrl))
            {
                TempData["GrafanaError"] = "Dashboard URL zorunludur.";
                return RedirectToAction(nameof(AnaSayfa));
            }

            if (string.IsNullOrWhiteSpace(grafanaUsername) != string.IsNullOrWhiteSpace(grafanaPassword))
            {
                TempData["GrafanaError"] = "Kullanıcı adı ve şifreyi birlikte girin veya ikisini de boş bırakın.";
                return RedirectToAction(nameof(AnaSayfa));
            }

            var credential = new VposMonitoringCredential
            {
                DashboardUrl = dashboardUrl,
                GrafanaUrl = GetGrafanaBaseUrl(dashboardUrl),
                ElasticUrl = elasticUrl,
                Username = grafanaUsername,
                Password = grafanaPassword
            };

            var test = await _dashboardGateway.TestAsync(credential, cancellationToken);
            if (!test.Success)
            {
                // Başarısız denemede URL yeniden yazılmak zorunda kalınmasın.
                // Parola ve kullanıcı adı TempData'ya KESİNLİKLE yazılmaz.
                TempData["GrafanaAttemptUrl"] = dashboardUrl;
                TempData["GrafanaError"] = test.Message;
                return RedirectToAction(nameof(AnaSayfa));
            }

            await _credentialStore.SaveAsync(userId, credential, cancellationToken);
            ClearMonitoringCache(userId);
            TempData["GrafanaOk"] = test.Message;
            return RedirectToAction(nameof(AnaSayfa), new { yenile = true });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GrafanaUnut(CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            await _credentialStore.DeleteAsync(userId, cancellationToken);
            ClearMonitoringCache(userId);
            TempData["GrafanaOk"] = "Kişisel Grafana bağlantı bilginiz silindi.";
            return RedirectToAction(nameof(AnaSayfa));
        }

        // Yeni Razor görünümü / eski Controller DLL çakışmasını teşhis etmek için.
        // Kimlik bilgilerini veya URL'leri kesinlikle ifşa etmez.
        [HttpGet]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public IActionResult GrafanaSurum()
        {
            return Json(new { surum = "VPOS-L3-v9", kullaniciAdiSifreZorunlu = false });
        }

        [HttpGet]
        public async Task<IActionResult> GrafanaTest(CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            if (credential == null) return Json(new { basarili = false, mesaj = "Kayıtlı Grafana bağlantısı yok." });
            var test = await _dashboardGateway.TestAsync(credential, cancellationToken);
            return Json(new { basarili = test.Success, mesaj = test.Message, dashboard = test.DashboardTitle, panelSayisi = test.PanelCount });
        }

        [HttpGet]
        public async Task<IActionResult> Hatalar(
            [FromQuery] VposMonitoringFilter filter,
            bool yenile = false,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var normalized = filter.Normalized();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            var vm = new VposMonitoringPageVm
            {
                Filter = normalized,
                CredentialsSaved = credential != null,
                DashboardUrl = credential?.DashboardUrl,
                Username = credential?.Username,
                Refreshed = yenile
            };

            if (credential == null)
            {
                vm.Data.Message = "Önce VPOS Ana Sayfa'dan Grafana dashboard bağlantınızı kaydedin.";
                return View(vm);
            }

            var cacheKey = $"vpos:errors:{userId}:{normalized.CacheKey()}";
            VposMonitoringResult? data = null;
            if (!yenile)
                _cache.TryGetValue(cacheKey, out data);

            if (data == null || yenile)
            {
                data = await _dashboardGateway.QueryAsync(credential, normalized, "errors", cancellationToken);
                if (data.Success) _cache.Set(cacheKey, data, TimeSpan.FromSeconds(45));
            }

            FillPage(vm, data);
            return View(vm);
        }

        [HttpGet]
        public async Task<IActionResult> CanliHataDetay(
            string? q,
            string? traceId,
            string? customer,
            string? code,
            string? source,
            DateTime? from,
            DateTime? to,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            if (credential == null) return RedirectToAction(nameof(AnaSayfa));

            var filter = new VposMonitoringFilter
            {
                Q = q,
                TraceId = traceId,
                Customer = customer,
                Code = code,
                Source = source,
                From = from,
                To = to,
                PageSize = 250
            }.Normalized();

            VposMonitoringResult data;
            if (!string.IsNullOrWhiteSpace(filter.TraceId))
            {
                // A Trace ID is correlated only against actual returned event rows.
                // Alarm/summary-only rows cannot be converted into fake trace logs.
                if (filter.TraceId.Length > 128 || !System.Text.RegularExpressions.Regex.IsMatch(
                    filter.TraceId, @"^[a-zA-Z0-9_:\-]{4,128}$"))
                    return BadRequest("Geçersiz Trace ID.");
                var importantLogs = await _dashboardGateway.QueryAsync(credential, filter, "important-errors", cancellationToken);
                var liveLogs = await _dashboardGateway.QueryAsync(credential, filter, "errors", cancellationToken);
                var mergedRows = importantLogs.Rows.Concat(liveLogs.Rows)
                    .Where(x => !x.IsAggregate && string.Equals(x.TraceId, filter.TraceId, StringComparison.OrdinalIgnoreCase))
                    .GroupBy(x => string.Join("|", x.TraceId, x.NormalizedCode,
                        x.Timestamp?.ToString("O"), x.ApiEndpoint, x.Message),
                        StringComparer.OrdinalIgnoreCase)
                    .Select(x => x.First()).OrderByDescending(x => x.Timestamp).ToList();
                data = new VposMonitoringResult
                {
                    Success = importantLogs.Success || liveLogs.Success,
                    DashboardTitle = importantLogs.DashboardTitle ?? liveLogs.DashboardTitle,
                    DashboardUrl = credential.DashboardUrl,
                    Rows = mergedRows,
                    Companies = mergedRows.Where(x => x.Customer != "-")
                        .GroupBy(x => x.Customer).Select(x => new VposCountItem { Key = x.Key, Count = x.Count() }).ToList(),
                    Errors = mergedRows.GroupBy(x => x.NormalizedCode)
                        .Select(x => new VposCountItem { Key = x.Key, Count = x.Count() }).ToList(),
                    Sources = mergedRows.GroupBy(x => x.Source)
                        .Select(x => new VposCountItem { Key = x.Key, Count = x.Count() }).ToList(),
                    Message = $"Trace ID: {filter.TraceId}. {mergedRows.Count} gerçek log kaydı bulundu. " +
                        "Arama, Grafana panellerinin döndürdüğü satırlarla sınırlıdır; tam indeks taraması değildir. " +
                        (!importantLogs.Success ? "Önemli log paneli: " + importantLogs.Message + ". " : "") +
                        (!liveLogs.Success ? "Canlı hata paneli: " + liveLogs.Message : "")
                };
            }
            else
            {
                var purpose = VposErrorCatalog.NormalizeIso(filter.Code) == "96" ? "important-errors" : "errors";
                data = await _dashboardGateway.QueryAsync(credential, filter, purpose, cancellationToken);
            }
            var vm = new VposMonitoringPageVm
            {
                Filter = filter,
                Data = data,
                CredentialsSaved = true,
                DashboardUrl = credential.DashboardUrl,
                Username = credential.Username,
                Refreshed = true
            };
            FillPage(vm, data);
            return View(vm);
        }

        [HttpGet]
        public IActionResult TraceIncele(string traceId, string? code, DateTime? from, DateTime? to)
        {
            if (string.IsNullOrWhiteSpace(traceId) || traceId.Length > 128 ||
                !System.Text.RegularExpressions.Regex.IsMatch(traceId, @"^[a-zA-Z0-9_:\-]{4,128}$"))
                return BadRequest("Geçersiz Trace ID.");
            return RedirectToAction(nameof(CanliHataDetay), new { traceId, code, from, to });
        }

        [HttpGet]
        public async Task<IActionResult> HataRaporu(
            [FromQuery] VposMonitoringFilter filter,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            if (credential == null) return RedirectToAction(nameof(AnaSayfa));

            var data = await _dashboardGateway.QueryAsync(credential, filter.Normalized(), "errors", cancellationToken);
            if (!data.Success)
            {
                TempData["VposError"] = data.Message;
                return RedirectToAction(nameof(Hatalar));
            }

            var bytes = VposExcelExportService.BuildErrors(data.Rows);
            return File(
                bytes,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                $"VPOS_Grafana_Hata_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
        }

        [HttpGet]
        public async Task<IActionResult> Kesintiler(
            [FromQuery] VposMonitoringFilter filter,
            bool yenile = false,
            CancellationToken cancellationToken = default)
        {
            var userId = GetCurrentUserId();
            if (userId <= 0) return Forbid();
            var normalized = filter.Normalized();
            var credential = await _credentialStore.GetAsync(userId, cancellationToken);
            var vm = new VposMonitoringPageVm
            {
                Filter = normalized,
                CredentialsSaved = credential != null,
                DashboardUrl = credential?.DashboardUrl,
                Username = credential?.Username,
                Refreshed = yenile
            };

            if (credential == null)
            {
                vm.Data.Message = "Önce VPOS Ana Sayfa'dan Grafana dashboard bağlantınızı kaydedin.";
                return View(vm);
            }

            var cacheKey = $"vpos:outages:{userId}:{normalized.CacheKey()}";
            VposMonitoringResult? data = null;
            if (!yenile) _cache.TryGetValue(cacheKey, out data);
            if (yenile)
            {
                data = await _dashboardGateway.QueryAsync(credential, normalized, "outages", cancellationToken);
                if (data.Success) _cache.Set(cacheKey, data, TimeSpan.FromMinutes(15));
            }
            else if (data == null)
            {
                data = new VposMonitoringResult
                {
                    Message = "Tarih/müşteri filtrelerini seçip Verileri Güncelle butonuna basın. Kesinti verisi Grafana'daki ilgili panellerden alınır."
                };
            }

            FillPage(vm, data);
            return View(vm);
        }

        private static void FillPage(VposMonitoringPageVm vm, VposMonitoringResult data)
        {
            vm.Data = data;
            vm.TotalRows = data.Rows.Count;
            vm.CustomerOptions = data.Rows.Select(x => x.Customer).Where(x => !string.IsNullOrWhiteSpace(x) && x != "-").Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList();
            vm.SourceOptions = data.Rows.Select(x => x.Source).Where(x => !string.IsNullOrWhiteSpace(x) && x != "-").Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList();
            vm.CodeOptions = data.Rows.Select(x => x.NormalizedCode).Where(x => !string.IsNullOrWhiteSpace(x) && x != "-").Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList();
            var pageSize = Math.Clamp(vm.Filter.PageSize, 10, 250);
            vm.TotalPages = Math.Max(1, (int)Math.Ceiling(vm.TotalRows / (double)pageSize));
            vm.Filter.Page = Math.Clamp(vm.Filter.Page, 1, vm.TotalPages);
            vm.PageRows = data.Rows.Skip((vm.Filter.Page - 1) * pageSize).Take(pageSize).ToList();
        }

        private static string NormalizeRange(string? value) => value is "15m" or "30m" or "1d" or "2d" ? value : "30m";

        private static TimeSpan RangeDuration(string value) => value switch
        {
            "15m" => TimeSpan.FromMinutes(15),
            "1d" => TimeSpan.FromDays(1),
            "2d" => TimeSpan.FromDays(2),
            _ => TimeSpan.FromMinutes(30)
        };

        private void ClearMonitoringCache(int userId)
        {
            // IMemoryCache prefix silme sunmadığı için bilinen özet anahtarı temizlenir.
            // Filtre anahtarları kısa ömürlüdür ve bağlantı değişince yeni sorguda üzerine yazılır.
            foreach (var range in new[] { "15m", "30m", "1d", "2d" })
            {
                _cache.Remove($"vpos:overview:transactions:{userId}:{range}");
                _cache.Remove($"vpos:overview:errors:{userId}:{range}");
                _cache.Remove($"vpos:overview:summary:{userId}:{range}");
                _cache.Remove($"vpos:overview:performance:{userId}:{range}");
                _cache.Remove($"vpos:overview:alarms:{userId}:{range}");
            }
        }

        private static string GetGrafanaBaseUrl(string dashboardUrl)
        {
            if (!Uri.TryCreate(dashboardUrl, UriKind.Absolute, out var uri)) return string.Empty;
            var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
            var marker = Array.FindIndex(segments, x => x.Equals("d", StringComparison.OrdinalIgnoreCase) || x.Equals("d-solo", StringComparison.OrdinalIgnoreCase));
            var prefix = marker <= 0 ? string.Empty : "/" + string.Join('/', segments.Take(marker));
            return $"{uri.Scheme}://{uri.Authority}{prefix}".TrimEnd('/');
        }

        [HttpGet]
        public async Task<IActionResult> Musteriler(string? q)
        {
            var ids = GetVposMusteriIds();
            var query = _context.Musteriler
                .AsNoTracking()
                .Where(x => ids.Contains(x.MusteriID));

            if (!string.IsNullOrWhiteSpace(q))
            {
                var term = q.Trim();
                query = query.Where(x =>
                    (x.Firma != null && x.Firma.Contains(term)) ||
                    (x.SiteUrl != null && x.SiteUrl.Contains(term)) ||
                    (x.FirmaYetkilisi != null && x.FirmaYetkilisi.Contains(term)));
            }

            ViewBag.Q = q;
            return View(await query.OrderBy(x => x.Firma).ToListAsync());
        }

        [HttpGet]
        public async Task<IActionResult> YeniMusteri()
        {
            await LoadYeniMusteriViewDataAsync();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> YeniMusteri(
            string? firma,
            string? siteUrl,
            string? teknoloji,
            string? durum,
            string? firmaYetkilisi,
            string? telefon,
            string? aciklama,
            string? vkn,
            string? hariciMusteriId)
        {
            firma = (firma ?? string.Empty).Trim();
            siteUrl = string.IsNullOrWhiteSpace(siteUrl) ? null : siteUrl.Trim();
            teknoloji = string.IsNullOrWhiteSpace(teknoloji) ? null : teknoloji.Trim();
            durum = (durum ?? string.Empty).Trim();
            firmaYetkilisi = string.IsNullOrWhiteSpace(firmaYetkilisi) ? null : firmaYetkilisi.Trim();
            telefon = string.IsNullOrWhiteSpace(telefon) ? null : telefon.Trim();
            aciklama = string.IsNullOrWhiteSpace(aciklama) ? null : aciklama.Trim();
            vkn = string.IsNullOrWhiteSpace(vkn) ? null : vkn.Trim();
            hariciMusteriId = string.IsNullOrWhiteSpace(hariciMusteriId) ? null : hariciMusteriId.Trim();

            if (string.IsNullOrWhiteSpace(firma))
                ModelState.AddModelError(nameof(firma), "Firma adı zorunludur.");

            if (!string.IsNullOrWhiteSpace(vkn) && vkn.Length > 10)
                ModelState.AddModelError(nameof(vkn), "VKN 10 karakterden uzun olamaz.");

            if (!string.IsNullOrWhiteSpace(hariciMusteriId) && hariciMusteriId.Length > 100)
                ModelState.AddModelError(nameof(hariciMusteriId), "Harici müşteri ID 100 karakterden uzun olamaz.");

            var durumlar = await GetMusteriDurumlariAsync();
            if (string.IsNullOrWhiteSpace(durum))
            {
                durum = durumlar.FirstOrDefault(x => string.Equals(x, "Beklemede", StringComparison.OrdinalIgnoreCase))
                        ?? durumlar.FirstOrDefault()
                        ?? "Beklemede";
            }
            else if (durumlar.Count > 0 && !durumlar.Contains(durum, StringComparer.OrdinalIgnoreCase))
            {
                ModelState.AddModelError(nameof(durum), "Geçerli bir müşteri durumu seçiniz.");
            }

            var atama = await GetLeastLoadedOperasyonUserAsync();
            if (atama.User == null)
                ModelState.AddModelError(string.Empty, "Entegrasyon işi atanamadı. Operasyon rolünde en az bir aktif kullanıcı bulunmalıdır.");

            if (!ModelState.IsValid)
            {
                await LoadYeniMusteriViewDataAsync();
                ViewBag.Firma = firma;
                ViewBag.SiteUrl = siteUrl;
                ViewBag.Teknoloji = teknoloji;
                ViewBag.Durum = durum;
                ViewBag.FirmaYetkilisi = firmaYetkilisi;
                ViewBag.Telefon = telefon;
                ViewBag.Aciklama = aciklama;
                ViewBag.VKN = vkn;
                ViewBag.HariciMusteriId = hariciMusteriId;
                return View();
            }

            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var assignedName = GetDisplayName(atama.User!);
            var now = DateTime.Now;

            await using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var musteri = new Musteri
                {
                    Firma = firma,
                    SiteUrl = siteUrl,
                    Teknoloji = teknoloji,
                    Durum = durum,
                    DurumDegisiklikTarihi = now,
                    DokumanKontrolBaslangicTarihi = null,
                    DokumanGonderimSayisi = 0,
                    DokumanGonderildiMi = null,
                    TalepSahibi = currentUserName,
                    Telefon = telefon,
                    Aciklama = aciklama,
                    KayitTarihi = now,
                    FirmaYetkilisi = firmaYetkilisi,
                    Kekleyen = currentUserName,
                    Kaynak = "VPOS"
                };

                _context.Musteriler.Add(musteri);
                await _context.SaveChangesAsync();

                var musteriIdText = musteri.MusteriID.ToString(CultureInfo.InvariantCulture);
                _context.Parametreler.Add(new Parametre { Tur = ProductConfiguredParamType, ParAdi = musteriIdText });
                _context.Parametreler.Add(new Parametre { Tur = VposCustomerParamType, ParAdi = musteriIdText });

                SaveMusteriEkAlanlariNoSave(musteri.MusteriID, vkn, hariciMusteriId);

                var jiraId = currentUserId > 0
                    ? $"VPOS-{currentUserId}-{now:yyyyMMddHHmmssfff}"
                    : $"VPOS-{now:yyyyMMddHHmmssfff}";

                var task = new JiraTask
                {
                    MusteriID = musteri.MusteriID,
                    MusteriAdi = musteri.Firma ?? string.Empty,
                    JiraId = jiraId,
                    TalepKonusu = VposTaskPrefix + "Yeni müşteri entegrasyonu - " + (musteri.Firma ?? string.Empty),
                    TalepTuru = "Entegrasyon",
                    TalepAcan = currentUserName,
                    Durum = "Aktif",
                    TakipEden = assignedName,
                    OlusturmaTarihi = now
                };

                _context.JiraTasks.Add(task);
                await _context.SaveChangesAsync();

                var notParts = new List<string>
                {
                    "[VPOS TALEP] Yeni VPOS müşteri kaydı oluşturuldu ve entegrasyon işi otomatik açıldı.",
                    $"Operations assignee selected by workload: {assignedName}."
                };
                if (!string.IsNullOrWhiteSpace(aciklama))
                    notParts.Add("Müşteri notu: " + aciklama);

                _context.JiraYorumlar.Add(new JiraYorum
                {
                    JiraTaskId = task.Id,
                    YorumMetni = string.Join(Environment.NewLine, notParts),
                    Ekleyen = currentUserName,
                    Tarih = now
                });
                await _context.SaveChangesAsync();

                await transaction.CommitAsync();

                TempData["JiraOk"] = $"VPOS customer {musteri.Firma} was created. The integration work item was assigned to {assignedName} based on workload (previous active workload: {atama.Workload}).";
                return RedirectToAction("Vpos", "Takip", new { selectedTaskId = task.Id });
            }
            catch (Exception)
            {
                await transaction.RollbackAsync();
                ModelState.AddModelError(string.Empty, "Müşteri ve entegrasyon işi oluşturulamadı. Lütfen tekrar deneyin.");
                await LoadYeniMusteriViewDataAsync();
                ViewBag.Firma = firma;
                ViewBag.SiteUrl = siteUrl;
                ViewBag.Teknoloji = teknoloji;
                ViewBag.Durum = durum;
                ViewBag.FirmaYetkilisi = firmaYetkilisi;
                ViewBag.Telefon = telefon;
                ViewBag.Aciklama = aciklama;
                ViewBag.VKN = vkn;
                ViewBag.HariciMusteriId = hariciMusteriId;
                return View();
            }
        }

        [HttpGet]
        public async Task<IActionResult> DuzenleMusteri(int id)
        {
            if (!GetVposMusteriIds().Contains(id))
                return NotFound();

            var musteri = await _context.Musteriler
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.MusteriID == id);

            if (musteri == null)
                return NotFound();

            await LoadYeniMusteriViewDataAsync();
            var ek = GetMusteriEkAlanlari(id);
            ViewBag.VKN = ek.Vkn;
            ViewBag.HariciMusteriId = ek.HariciMusteriId;

            return View(musteri);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DuzenleMusteri(
            int musteriId,
            string? firma,
            string? siteUrl,
            string? teknoloji,
            string? durum,
            string? firmaYetkilisi,
            string? telefon,
            string? aciklama,
            string? vkn,
            string? hariciMusteriId)
        {
            if (!GetVposMusteriIds().Contains(musteriId))
                return NotFound();

            var musteri = await _context.Musteriler.FirstOrDefaultAsync(x => x.MusteriID == musteriId);
            if (musteri == null)
                return NotFound();

            firma = (firma ?? string.Empty).Trim();
            siteUrl = string.IsNullOrWhiteSpace(siteUrl) ? null : siteUrl.Trim();
            teknoloji = string.IsNullOrWhiteSpace(teknoloji) ? null : teknoloji.Trim();
            durum = (durum ?? string.Empty).Trim();
            firmaYetkilisi = string.IsNullOrWhiteSpace(firmaYetkilisi) ? null : firmaYetkilisi.Trim();
            telefon = string.IsNullOrWhiteSpace(telefon) ? null : telefon.Trim();
            aciklama = string.IsNullOrWhiteSpace(aciklama) ? null : aciklama.Trim();
            vkn = string.IsNullOrWhiteSpace(vkn) ? null : vkn.Trim();
            hariciMusteriId = string.IsNullOrWhiteSpace(hariciMusteriId) ? null : hariciMusteriId.Trim();

            if (string.IsNullOrWhiteSpace(firma))
                ModelState.AddModelError(nameof(firma), "Firma adı zorunludur.");
            if (!string.IsNullOrWhiteSpace(vkn) && vkn.Length > 10)
                ModelState.AddModelError(nameof(vkn), "VKN 10 karakterden uzun olamaz.");
            if (!string.IsNullOrWhiteSpace(hariciMusteriId) && hariciMusteriId.Length > 100)
                ModelState.AddModelError(nameof(hariciMusteriId), "Harici müşteri ID 100 karakterden uzun olamaz.");

            var durumlar = await GetMusteriDurumlariAsync();
            if (durumlar.Count > 0 && !durumlar.Contains(durum, StringComparer.OrdinalIgnoreCase))
                ModelState.AddModelError(nameof(durum), "Geçerli bir müşteri durumu seçiniz.");

            if (!ModelState.IsValid)
            {
                await LoadYeniMusteriViewDataAsync();
                ViewBag.VKN = vkn;
                ViewBag.HariciMusteriId = hariciMusteriId;

                musteri.Firma = firma;
                musteri.SiteUrl = siteUrl;
                musteri.Teknoloji = teknoloji;
                musteri.Durum = durum;
                musteri.FirmaYetkilisi = firmaYetkilisi;
                musteri.Telefon = telefon;
                musteri.Aciklama = aciklama;
                return View(musteri);
            }

            var eskiDurum = musteri.Durum ?? string.Empty;
            var durumDegisti = !string.Equals(eskiDurum.Trim(), durum, StringComparison.OrdinalIgnoreCase);

            musteri.Firma = firma;
            musteri.SiteUrl = siteUrl;
            musteri.Teknoloji = teknoloji;
            musteri.Durum = durum;
            musteri.FirmaYetkilisi = firmaYetkilisi;
            musteri.Telefon = telefon;
            musteri.Aciklama = aciklama;

            if (durumDegisti)
            {
                musteri.DurumDegisiklikTarihi = DateTime.Now;
                musteri.DokumanGonderildiMi = null;
                musteri.DokumanGonderimSayisi = 0;
                musteri.DokumanKontrolBaslangicTarihi = musteri.DurumDegisiklikTarihi;

                _context.MusteriDurumGecmisleri.Add(new MusteriDurumGecmisi
                {
                    MusteriID = musteri.MusteriID,
                    EskiDurum = eskiDurum,
                    YeniDurum = durum,
                    Aciklama = aciklama ?? "VPOS müşteri ekranından güncellendi.",
                    Tarih = DateTime.Now,
                    DegistirenKullanici = User.Identity?.Name
                });
            }

            SetMusteriEkAlanlariNoSave(musteriId, vkn, hariciMusteriId);
            await _context.SaveChangesAsync();

            TempData["VposOk"] = "Müşteri güncellendi. Değişiklik tüm müşteri ekranlarına yansıdı.";
            return RedirectToAction(nameof(Musteriler));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> VpostanCikar(int id)
        {
            var idText = id.ToString(CultureInfo.InvariantCulture);
            var vposMarkers = await _context.Parametreler
                .Where(x => x.Tur == VposCustomerParamType && x.ParAdi == idText)
                .ToListAsync();

            if (vposMarkers.Count == 0)
            {
                TempData["VposError"] = "Müşteri VPOS listesinde bulunamadı.";
                return RedirectToAction(nameof(Musteriler));
            }

            var digerUrunVar = await _context.Parametreler.AnyAsync(x =>
                x.ParAdi == idText &&
                (x.Tur == OperasyonCustomerParamType || x.Tur == MobilCustomerParamType));

            if (!digerUrunVar)
            {
                TempData["VposError"] = "Bu müşterinin tek ürünü VPOS. Önce PF/Cüzdan ürünü ekleyin veya 'Tamamen Sil' kullanın.";
                return RedirectToAction(nameof(Musteriler));
            }

            _context.Parametreler.RemoveRange(vposMarkers);
            await _context.SaveChangesAsync();

            TempData["VposOk"] = "Müşteri VPOS listesinden çıkarıldı. Ana müşteri kaydı korunuyor.";
            return RedirectToAction(nameof(Musteriler));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MusteriyiTamamenSil(int id)
        {
            if (!GetVposMusteriIds().Contains(id))
            {
                TempData["VposError"] = "Müşteri VPOS listesinde bulunamadı.";
                return RedirectToAction(nameof(Musteriler));
            }

            var result = await MusteriSilmeHelper.TamamenSilAsync(_context, id);
            TempData[result.Success ? "VposOk" : "VposError"] = result.Message;
            return RedirectToAction(nameof(Musteriler));
        }

        [HttpGet]
        public async Task<IActionResult> Yeni(string? kayitTipi = null)
        {
            await LoadYeniViewDataAsync();
            ViewBag.KayitTipi = string.Equals(kayitTipi, "HATA", StringComparison.OrdinalIgnoreCase)
                ? "HATA"
                : "IS";
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Yeni(
            string kayitTipi,
            int? musteriId,
            string? konu,
            string? aciklama,
            string? kategori)
        {
            kayitTipi = (kayitTipi ?? string.Empty).Trim().ToUpperInvariant();
            konu = (konu ?? string.Empty).Trim();
            aciklama = (aciklama ?? string.Empty).Trim();
            kategori = (kategori ?? string.Empty).Trim();

            if (kayitTipi != "IS" && kayitTipi != "HATA")
                ModelState.AddModelError(nameof(kayitTipi), "Kayıt tipi seçiniz.");

            var vposIds = GetVposMusteriIds();
            Musteri? musteri = null;

            if (!musteriId.HasValue || !vposIds.Contains(musteriId.Value))
            {
                ModelState.AddModelError(nameof(musteriId), "VPOS müşterisi seçiniz.");
            }
            else
            {
                musteri = await _context.Musteriler
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.MusteriID == musteriId.Value);

                if (musteri == null)
                    ModelState.AddModelError(nameof(musteriId), "Müşteri bulunamadı.");
            }

            if (string.IsNullOrWhiteSpace(konu))
                ModelState.AddModelError(nameof(konu), kayitTipi == "HATA" ? "Hata adı zorunludur." : "İş konusu zorunludur.");

            if (kayitTipi == "HATA" && string.IsNullOrWhiteSpace(kategori))
                ModelState.AddModelError(nameof(kategori), "Hata kategorisi zorunludur.");

            var atama = await GetLeastLoadedOperasyonUserAsync();
            var atanacak = atama.User;
            if (atanacak == null)
                ModelState.AddModelError(string.Empty, "İş yoğunluğuna göre atama yapılamadı. Operasyon rolünde en az bir kullanıcı olmalı.");

            if (!ModelState.IsValid)
            {
                await LoadYeniViewDataAsync();
                ViewBag.KayitTipi = kayitTipi;
                ViewBag.SeciliMusteriId = musteriId;
                ViewBag.Konu = konu;
                ViewBag.Aciklama = aciklama;
                ViewBag.Kategori = kategori;
                return View();
            }

            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var assignedName = GetDisplayName(atanacak!);

            if (kayitTipi == "HATA")
            {
                
                
                
                
                
                var hata = new Hata
                {
                    HataAdi = konu,
                    HataAciklama = aciklama,
                    KategoriBilgisi = kategori,
                    OlusturanUserId = atanacak!.Id,
                    OlusturanKullaniciAdi = assignedName,
                    OlusturmaTarihi = DateTime.Now,
                    Durum = "Açık",
                    SecilenHataId = currentUserId > 0 ? -currentUserId : null,
                    OperasyonCevabi = string.Empty,
                    CevaplayanKullaniciAdi = string.Empty,
                    MusteriID = musteriId
                };

                _context.Hatalar.Add(hata);
                await _context.SaveChangesAsync();

                _context.Parametreler.Add(new Parametre
                {
                    Tur = VposErrorParamType,
                    ParAdi = hata.Id.ToString(CultureInfo.InvariantCulture)
                });
                await _context.SaveChangesAsync();

                TempData["VposOk"] = $"The issue was created and assigned to {assignedName} based on workload (previous active workload: {atama.Workload}).";
                return RedirectToAction(nameof(YerelHatalar));
            }

            var jiraId = currentUserId > 0
                ? $"VPOS-{currentUserId}-{DateTime.Now:yyyyMMddHHmmssfff}"
                : $"VPOS-{DateTime.Now:yyyyMMddHHmmssfff}";

            var task = new JiraTask
            {
                MusteriID = musteriId,
                MusteriAdi = musteri?.Firma ?? string.Empty,
                JiraId = jiraId,
                TalepKonusu = VposTaskPrefix + konu,
                TalepTuru = "Entegrasyon",
                TalepAcan = currentUserName,
                Durum = "Aktif",
                TakipEden = assignedName,
                OlusturmaTarihi = DateTime.Now
            };

            _context.JiraTasks.Add(task);
            await _context.SaveChangesAsync();

            if (!string.IsNullOrWhiteSpace(aciklama))
            {
                _context.JiraYorumlar.Add(new JiraYorum
                {
                    JiraTaskId = task.Id,
                    YorumMetni = "[VPOS TALEP] " + aciklama,
                    Ekleyen = currentUserName,
                    Tarih = DateTime.Now
                });
                await _context.SaveChangesAsync();
            }

            TempData["JiraOk"] = $"The integration work item was created and assigned to {assignedName} based on workload (previous active workload: {atama.Workload}).";
            return RedirectToAction("Vpos", "Takip", new { selectedTaskId = task.Id });
        }

        [HttpGet]
        public async Task<IActionResult> Islerim(string? q, string? durum)
        {
            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var ownerPrefix = GetVposTaskOwnerPrefix(currentUserId);

            var query = _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .Where(x => x.TalepKonusu != null && x.TalepKonusu.StartsWith(VposTaskPrefix))
                .Where(x => x.TalepAcan == currentUserName ||
                            (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix)));

            if (!string.IsNullOrWhiteSpace(q))
            {
                var term = q.Trim();
                query = query.Where(x =>
                    x.TalepKonusu.Contains(term) ||
                    (x.MusteriAdi != null && x.MusteriAdi.Contains(term)) ||
                    (x.TakipEden != null && x.TakipEden.Contains(term)));
            }

            if (!string.IsNullOrWhiteSpace(durum))
                query = query.Where(x => x.Durum == durum);

            ViewBag.Q = q;
            ViewBag.Durum = durum;
            return View(await query.OrderByDescending(x => x.OlusturmaTarihi).ToListAsync());
        }

        [HttpGet]
        public async Task<IActionResult> IsDetay(int id)
        {
            if (id <= 0)
                return NotFound();

            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var ownerPrefix = GetVposTaskOwnerPrefix(currentUserId);

            var task = await _context.JiraTasks
                .AsNoTracking()
                .Include(x => x.Yorumlar)
                .FirstOrDefaultAsync(x =>
                    x.Id == id &&
                    x.TalepKonusu != null &&
                    x.TalepKonusu.StartsWith(VposTaskPrefix) &&
                    (x.TalepAcan == currentUserName ||
                     (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix))));

            if (task == null)
                return NotFound();

            return View(task);
        }

        [HttpGet]
        public async Task<IActionResult> YerelHatalar(string? q, string? durum, string? kategori)
        {
            
            var hataIds = GetVposHataIds();
            var query = _context.Hatalar
                .AsNoTracking()
                .Where(x => hataIds.Contains(x.Id));

            if (!string.IsNullOrWhiteSpace(q))
            {
                var term = q.Trim();
                query = query.Where(x =>
                    x.HataAdi.Contains(term) ||
                    x.HataAciklama.Contains(term) ||
                    x.OlusturanKullaniciAdi.Contains(term));
            }

            if (!string.IsNullOrWhiteSpace(durum))
                query = query.Where(x => x.Durum == durum);

            if (!string.IsNullOrWhiteSpace(kategori))
                query = query.Where(x => x.KategoriBilgisi == kategori);

            var data = await query
                .OrderByDescending(x => x.OlusturmaTarihi)
                .ToListAsync();

            var customerIds = data
                .Where(x => x.MusteriID.HasValue)
                .Select(x => x.MusteriID!.Value)
                .Distinct()
                .ToList();

            ViewBag.Musteriler = await _context.Musteriler
                .AsNoTracking()
                .Where(x => customerIds.Contains(x.MusteriID))
                .ToDictionaryAsync(x => x.MusteriID, x => x.Firma ?? $"Customer #{x.MusteriID}");

            ViewBag.Acanlar = await GetVposHataOpenerMapAsync(data);
            ViewBag.Q = q;
            ViewBag.Durum = durum;
            ViewBag.Kategori = kategori;
            ViewBag.Kategoriler = data
                .Select(x => x.KategoriBilgisi)
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Distinct()
                .OrderBy(x => x)
                .ToList();

            return View(data);
        }

        [HttpGet]
        public async Task<IActionResult> HataDetay(int id)
        {
            if (!GetVposHataIds().Contains(id))
                return NotFound();

            var hata = await _context.Hatalar
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == id);

            if (hata == null)
                return NotFound();

            ViewBag.MusteriAdi = hata.MusteriID.HasValue
                ? await _context.Musteriler
                    .AsNoTracking()
                    .Where(x => x.MusteriID == hata.MusteriID.Value)
                    .Select(x => x.Firma)
                    .FirstOrDefaultAsync()
                : null;

            var openerMap = await GetVposHataOpenerMapAsync(new[] { hata });
            ViewBag.AcanKullanici = openerMap.TryGetValue(hata.Id, out var name) ? name : "-";

            return View(hata);
        }

        [HttpGet]
        public async Task<IActionResult> IsRaporu()
        {
            var currentUserId = GetCurrentUserId();
            var currentUserName = GetCurrentUserDisplayName();
            var ownerPrefix = GetVposTaskOwnerPrefix(currentUserId);

            var rows = await _context.JiraTasks
                .AsNoTracking()
                .Where(x => x.TalepKonusu != null && x.TalepKonusu.StartsWith(VposTaskPrefix))
                .Where(x => x.TalepAcan == currentUserName ||
                            (ownerPrefix != null && x.JiraId.StartsWith(ownerPrefix)))
                .OrderByDescending(x => x.OlusturmaTarihi)
                .ToListAsync();

            var sb = new StringBuilder();
            sb.Append('\uFEFF');
            sb.AppendLine("İş ID;Müşteri;Konu;Talep Açan;Atanan Operasyon;Durum;Tarih");

            foreach (var x in rows)
            {
                sb.AppendLine(string.Join(';', new[]
                {
                    CsvEscape(x.JiraId),
                    CsvEscape(x.MusteriAdi),
                    CsvEscape(CleanTaskSubject(x.TalepKonusu)),
                    CsvEscape(x.TalepAcan),
                    CsvEscape(x.TakipEden),
                    CsvEscape(x.Durum),
                    CsvEscape(x.OlusturmaTarihi.ToString("dd.MM.yyyy HH:mm", CultureInfo.GetCultureInfo("tr-TR")))
                }));
            }

            return File(
                Encoding.UTF8.GetBytes(sb.ToString()),
                "text/csv; charset=utf-8",
                $"VPOS_Entegrasyon_Is_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.csv");
        }

        [HttpGet]
        public async Task<IActionResult> YerelHataRaporu()
        {
            var hataIds = GetVposHataIds();
            var rows = await _context.Hatalar
                .AsNoTracking()
                .Where(x => hataIds.Contains(x.Id))
                .OrderByDescending(x => x.OlusturmaTarihi)
                .ToListAsync();

            var customerIds = rows
                .Where(x => x.MusteriID.HasValue)
                .Select(x => x.MusteriID!.Value)
                .Distinct()
                .ToList();

            var customerMap = await _context.Musteriler
                .AsNoTracking()
                .Where(x => customerIds.Contains(x.MusteriID))
                .ToDictionaryAsync(x => x.MusteriID, x => x.Firma ?? $"Customer #{x.MusteriID}");

            var openedBy = await GetVposHataOpenerMapAsync(rows);

            var sb = new StringBuilder();
            sb.Append('\uFEFF');
            sb.AppendLine("Hata ID;Müşteri;Hata;Açıklama;Kategori;Açan VPOS Kullanıcısı;Atanan Operasyon;Durum;Tarih");

            foreach (var x in rows)
            {
                var customer = x.MusteriID.HasValue && customerMap.TryGetValue(x.MusteriID.Value, out var c)
                    ? c
                    : "-";
                var opener = openedBy.TryGetValue(x.Id, out var o) ? o : "-";

                sb.AppendLine(string.Join(';', new[]
                {
                    x.Id.ToString(CultureInfo.InvariantCulture),
                    CsvEscape(customer),
                    CsvEscape(x.HataAdi),
                    CsvEscape(x.HataAciklama),
                    CsvEscape(x.KategoriBilgisi),
                    CsvEscape(opener),
                    CsvEscape(x.OlusturanKullaniciAdi),
                    CsvEscape(x.Durum),
                    CsvEscape(x.OlusturmaTarihi.ToString("dd.MM.yyyy HH:mm", CultureInfo.GetCultureInfo("tr-TR")))
                }));
            }

            return File(
                Encoding.UTF8.GetBytes(sb.ToString()),
                "text/csv; charset=utf-8",
                $"VPOS_Hata_Raporu_{DateTime.Now:yyyyMMdd_HHmm}.csv");
        }

        private HashSet<int> GetVposHataIds()
        {
            return _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == VposErrorParamType && x.ParAdi != null)
                .Select(x => x.ParAdi!)
                .ToList()
                .Select(x => int.TryParse(x, out var id) ? id : 0)
                .Where(x => x > 0)
                .ToHashSet();
        }

        private HashSet<int> GetVposMusteriIds()
        {
            return _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == VposCustomerParamType && x.ParAdi != null)
                .Select(x => x.ParAdi!)
                .ToList()
                .Select(x => int.TryParse(x, out var id) ? id : 0)
                .Where(x => x > 0)
                .ToHashSet();
        }

        private async Task LoadYeniViewDataAsync()
        {
            var ids = GetVposMusteriIds();
            ViewBag.Musteriler = await _context.Musteriler
                .AsNoTracking()
                .Where(x => ids.Contains(x.MusteriID))
                .OrderBy(x => x.Firma)
                .ToListAsync();
        }

        private async Task LoadYeniMusteriViewDataAsync()
        {
            ViewBag.Durumlar = await GetMusteriDurumlariAsync();
            ViewBag.Teknolojiler = await _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == "Teknoloji" && x.ParAdi != null && x.ParAdi != "")
                .Select(x => x.ParAdi!)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        private async Task<List<string>> GetMusteriDurumlariAsync()
        {
            return await _context.Parametreler
                .AsNoTracking()
                .Where(x => x.Tur == "Durum" && x.ParAdi != null && x.ParAdi != "")
                .Select(x => x.ParAdi!)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        private void SaveMusteriEkAlanlariNoSave(int musteriId, string? vkn, string? hariciMusteriId)
        {
            vkn = string.IsNullOrWhiteSpace(vkn) ? null : vkn.Trim();
            hariciMusteriId = string.IsNullOrWhiteSpace(hariciMusteriId) ? null : hariciMusteriId.Trim();
            var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";

            if (vkn != null)
                _context.Parametreler.Add(new Parametre { Tur = MusteriVknParamType, ParAdi = prefix + vkn });

            if (hariciMusteriId != null)
                _context.Parametreler.Add(new Parametre { Tur = MusteriHariciIdParamType, ParAdi = prefix + hariciMusteriId });
        }

        private void SetMusteriEkAlanlariNoSave(int musteriId, string? vkn, string? hariciMusteriId)
        {
            var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";
            var existing = _context.Parametreler
                .Where(x =>
                    (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                    x.ParAdi != null &&
                    x.ParAdi.StartsWith(prefix))
                .ToList();

            if (existing.Count > 0)
                _context.Parametreler.RemoveRange(existing);

            SaveMusteriEkAlanlariNoSave(musteriId, vkn, hariciMusteriId);
        }

        private (string? Vkn, string? HariciMusteriId) GetMusteriEkAlanlari(int musteriId)
        {
            var prefix = musteriId.ToString(CultureInfo.InvariantCulture) + "|";
            var rows = _context.Parametreler
                .AsNoTracking()
                .Where(x =>
                    (x.Tur == MusteriVknParamType || x.Tur == MusteriHariciIdParamType) &&
                    x.ParAdi != null &&
                    x.ParAdi.StartsWith(prefix))
                .Select(x => new { x.Tur, x.ParAdi })
                .ToList();

            string? vkn = null;
            string? harici = null;

            foreach (var row in rows)
            {
                var value = row.ParAdi![prefix.Length..];
                if (row.Tur == MusteriVknParamType)
                    vkn = value;
                else if (row.Tur == MusteriHariciIdParamType)
                    harici = value;
            }

            return (vkn, harici);
        }

        private async Task<(User? User, int Workload)> GetLeastLoadedOperasyonUserAsync()
        {
            var users = await _context.Users
                .AsNoTracking()
                .Where(x => x.Role == AppRoles.Operasyon)
                .OrderBy(x => x.Id)
                .ToListAsync();

            
            
            if (users.Count == 0)
            {
                users = await _context.Users
                    .AsNoTracking()
                    .Where(x =>
                        x.Role == AppRoles.OperasyonSuperAdmin ||
                        x.Role == "Operasyon Süper Admin" ||
                        x.Role == "Operasyon Super Admin")
                    .OrderBy(x => x.Id)
                    .ToListAsync();
            }

            if (users.Count == 0)
                return (null, 0);

            var aktifIsAtamalari = await _context.JiraTasks
                .AsNoTracking()
                .Where(x => x.TakipEden != null && x.TakipEden != "")
                .Where(x => x.Durum != "Entegrasyon Tamamlandı" &&
                            x.Durum != "Entegrasyon Tamamlanmadı" &&
                            x.Durum != "Tamamlandı" &&
                            x.Durum != "Arşiv")
                .Select(x => x.TakipEden!)
                .ToListAsync();

            var acikHataAtamalari = await _context.Hatalar
                .AsNoTracking()
                .Where(x => x.OlusturanKullaniciAdi != null && x.OlusturanKullaniciAdi != "")
                .Where(x => x.Durum == null || x.Durum != "Kapalı")
                .Select(x => x.OlusturanKullaniciAdi)
                .ToListAsync();

            var workload = users
                .Select(user =>
                {
                    var display = GetDisplayName(user);
                    var aliases = new[] { display, user.UserName }
                        .Where(x => !string.IsNullOrWhiteSpace(x))
                        .Select(x => x.Trim())
                        .Distinct(StringComparer.OrdinalIgnoreCase)
                        .ToArray();

                    var taskCount = aktifIsAtamalari.Count(x => aliases.Contains((x ?? string.Empty).Trim(), StringComparer.OrdinalIgnoreCase));
                    var errorCount = acikHataAtamalari.Count(x => aliases.Contains((x ?? string.Empty).Trim(), StringComparer.OrdinalIgnoreCase));
                    return new { User = user, Count = taskCount + errorCount };
                })
                .OrderBy(x => x.Count)
                .ThenBy(x => x.User.Id)
                .ToList();

            var selected = workload.First();
            return (selected.User, selected.Count);
        }

        private int GetCurrentUserId()
        {
            return int.TryParse(User.FindFirst("UserId")?.Value, out var id) ? id : 0;
        }

        private string GetCurrentUserDisplayName()
        {
            var id = GetCurrentUserId();
            if (id > 0)
            {
                var user = _context.Users
                    .AsNoTracking()
                    .FirstOrDefault(x => x.Id == id);

                if (user != null)
                    return GetDisplayName(user);
            }

            return User.Identity?.Name ?? "VPOS Kullanıcısı";
        }

        private static string GetDisplayName(User user)
        {
            return !string.IsNullOrWhiteSpace(user.FullName)
                ? user.FullName!.Trim()
                : user.UserName.Trim();
        }

        private static string? GetVposTaskOwnerPrefix(int userId)
        {
            return userId > 0 ? $"VPOS-{userId}-" : null;
        }

        private async Task<Dictionary<int, string>> GetVposHataOpenerMapAsync(IEnumerable<Hata> rows)
        {
            var list = rows.ToList();

            
            
            var userIds = list
                .Where(x => x.SecilenHataId.HasValue && x.SecilenHataId.Value < 0)
                .Select(x => -x.SecilenHataId!.Value)
                .Where(x => x > 0)
                .Distinct()
                .ToList();

            var users = await _context.Users
                .AsNoTracking()
                .Where(x => userIds.Contains(x.Id))
                .ToDictionaryAsync(x => x.Id, x => !string.IsNullOrWhiteSpace(x.FullName) ? x.FullName! : x.UserName);

            var result = new Dictionary<int, string>();

            foreach (var hata in list)
            {
                if (hata.SecilenHataId.HasValue && hata.SecilenHataId.Value < 0)
                {
                    var openerId = -hata.SecilenHataId.Value;
                    result[hata.Id] = users.TryGetValue(openerId, out var name) ? name : $"User #{openerId}";
                }
            }

            return result;
        }

        private static string CleanTaskSubject(string? subject)
        {
            var value = (subject ?? string.Empty).Trim();
            return value.StartsWith(VposTaskPrefix, StringComparison.OrdinalIgnoreCase)
                ? value[VposTaskPrefix.Length..].Trim()
                : value;
        }

        private static string CsvEscape(string? value)
        {
            value ??= string.Empty;
            var quote = value.Contains(';') || value.Contains('"') || value.Contains('\n') || value.Contains('\r');
            value = value.Replace("\"", "\"\"");
            return quote ? $"\"{value}\"" : value;
        }
    }
}
