using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Net.Mail;
using System.Text.Json;

namespace BtOperasyonTakip.Controllers;

[Authorize(Roles = "Operasyon,Admin")]
public sealed class TicketMailController : Controller
{
    private readonly AppDbContext _db;
    private readonly IConfiguration _config;
    private readonly IWebHostEnvironment _environment;
    private readonly ILogger<TicketMailController> _logger;
    private static readonly SemaphoreSlim SendLock = new(1, 1);
    private readonly string _folder;
    private readonly string _attachments;
    private readonly string _settingsFile;
    private static readonly JsonSerializerOptions JsonOptions = new() { PropertyNameCaseInsensitive = true, WriteIndented = true };
    private static readonly string[] AcceptedExtensions = [".pdf", ".docx", ".xlsx", ".txt"];

    public TicketMailController(AppDbContext db, IConfiguration config, IWebHostEnvironment environment, ILogger<TicketMailController> logger)
    {
        _db = db;
        _config = config;
        _environment = environment;
        _logger = logger;
        _folder = Path.Combine(environment.ContentRootPath, "App_Data", "TicketMail");
        _attachments = Path.Combine(_folder, "Attachments");
        _settingsFile = Path.Combine(_folder, "template.json");
        Directory.CreateDirectory(_attachments);
    }

    public sealed class MailTemplate
    {
        public string Subject { get; set; } = "{FirmaAdi} - Sanal POS Entegrasyon Dokümanları";
        public string Body { get; set; } = "Merhaba {YetkiliAdi},\n\nUyum onayınız sonrasında entegrasyon dokümanlarını ekte iletiyoruz.\nTicket: {TicketNo}\n\nİyi çalışmalar,\nSanal POS Entegrasyon Ekibi";
        public List<MailAttachment> Attachments { get; set; } = [];
    }
    public sealed class MailAttachment
    {
        public string Name { get; set; } = "";
        public string SavedName { get; set; } = "";
    }
    public sealed class SendRequest { public int Id { get; set; } }

    private MailTemplate ReadTemplate()
    {
        if (!System.IO.File.Exists(_settingsFile)) return new MailTemplate();
        try { return JsonSerializer.Deserialize<MailTemplate>(System.IO.File.ReadAllText(_settingsFile), JsonOptions) ?? new MailTemplate(); }
        catch (Exception ex) { _logger.LogError(ex, "Ticket e-posta şablonu okunamadı"); throw; }
    }
    private void SaveTemplate(MailTemplate t)
    {
        Directory.CreateDirectory(_folder);
        var tmp = _settingsFile + ".tmp";
        System.IO.File.WriteAllText(tmp, JsonSerializer.Serialize(t, JsonOptions));
        System.IO.File.Move(tmp, _settingsFile, true);
    }
    private static string Render(string value, Ticket ticket) => value
        .Replace("{FirmaAdi}", ticket.FirmaAdi ?? "", StringComparison.Ordinal)
        .Replace("{YetkiliAdi}", ((ticket.YazilimciAdi ?? "") + " " + (ticket.YazilimciSoyadi ?? "")).Trim(), StringComparison.Ordinal)
        .Replace("{TicketNo}", ticket.Id.ToString(), StringComparison.Ordinal)
        .Replace("{Tarih}", DateTime.Now.ToString("dd.MM.yyyy"), StringComparison.Ordinal);

    private bool CanSend(Ticket t) => t.Durum == "Operasyon 2 Onay Bekleniyor" && t.UyumOnayTarihi.HasValue &&
        (User.IsInRole("Admin") || t.AtananOperasyonUserId == GetUserId());
    private int GetUserId() => int.TryParse(User.FindFirst("UserId")?.Value, out int id) ? id : 0;

    private string Cc => (_config["TicketMail:SupportCc"] ?? "").Trim();
    private string From => (_config["TicketMail:From"] ?? "").Trim();
    private bool Configured => !string.IsNullOrWhiteSpace(_config["TicketMail:SmtpHost"]) &&
        !string.IsNullOrWhiteSpace(From) && !string.IsNullOrWhiteSpace(Cc);
    private static bool ValidEmail(string address)
    {
        try { var a = new MailAddress(address); return a.Address.Equals(address, StringComparison.OrdinalIgnoreCase); }
        catch { return false; }
    }

    [HttpGet]
    public IActionResult Preview(int id)
    {
        var t = _db.Tickets.AsNoTracking().FirstOrDefault(t => t.Id == id);
        if (t == null) return NotFound(new { success = false, message = "Ticket bulunamadı." });
        if (!CanSend(t)) return StatusCode(403, new { success = false, message = "Uyum onayı veya atama yetkisi uygun değil." });
        var template = ReadTemplate();
        return Json(new { success = true, to = t.Mail, cc = Cc, subject = Render(template.Subject, t), body = Render(template.Body, t), attachments = template.Attachments.Select(a => a.Name).ToArray(), smtpReady = Configured });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Send([FromBody] SendRequest request)
    {
        if (request == null || request.Id <= 0) return BadRequest(new { success = false, message = "Geçersiz ticket." });
        await SendLock.WaitAsync();
        try
        {
            var t = await _db.Tickets.FirstOrDefaultAsync(t => t.Id == request.Id);
            if (t == null) return NotFound(new { success = false, message = "Ticket bulunamadı." });
            if (!CanSend(t)) return StatusCode(403, new { success = false, message = "Bu ticket için gönderim yetkisi veya Uyum onayı yok." });
            if (t.MailGonderildiMi == true) return BadRequest(new { success = false, message = "Mail zaten gönderilmiş." });
            if (!Configured) return BadRequest(new { success = false, message = "SMTP host, gönderici veya zorunlu Sanal POS Destek CC ayarı eksik. Sunucu yöneticisine bildirin." });
            if (!ValidEmail(t.Mail) || !ValidEmail(Cc) || !ValidEmail(From))
                return BadRequest(new { success = false, message = "Alıcı, gönderici veya zorunlu CC adresi geçersiz." });
            var template = ReadTemplate();
            if (template.Attachments.Count == 0)
                return BadRequest(new { success = false, message = "Admin henüz entegrasyon dokümanı eklememiş. Boş e-posta gönderilmedi." });
            if (string.IsNullOrWhiteSpace(template.Subject) || string.IsNullOrWhiteSpace(template.Body))
                return BadRequest(new { success = false, message = "Admin e-posta şablonu boş." });
            using var mail = new MailMessage { From = new MailAddress(From), Subject = Render(template.Subject, t), Body = Render(template.Body, t), IsBodyHtml = false };
            mail.To.Add(new MailAddress(t.Mail));
            mail.CC.Add(new MailAddress(Cc));
            foreach (var a in template.Attachments)
            {
                if (string.IsNullOrWhiteSpace(a.SavedName) || Path.GetFileName(a.SavedName) != a.SavedName)
                    return BadRequest(new { success = false, message = "Geçersiz ek kaydı." });
                var file = Path.Combine(_attachments, a.SavedName);
                if (!System.IO.File.Exists(file)) return BadRequest(new { success = false, message = $"Doküman bulunamadı: {a.Name}" });
                mail.Attachments.Add(new Attachment(file) { Name = a.Name });
            }
            int port = int.TryParse(_config["TicketMail:SmtpPort"], out var configuredPort) ? configuredPort : 587;
            if (port < 1 || port > 65535) return BadRequest(new { success = false, message = "SMTP portu geçersiz." });
            using var smtp = new SmtpClient(_config["TicketMail:SmtpHost"], port) { EnableSsl = true, DeliveryMethod = SmtpDeliveryMethod.Network, Timeout = 30000, UseDefaultCredentials = false };
            var username = _config["TicketMail:Username"];
            if (!string.IsNullOrWhiteSpace(username)) smtp.Credentials = new NetworkCredential(username, _config["TicketMail:Password"] ?? "");
            // SMTP acceptance is required BEFORE updating the workflow.
            await smtp.SendMailAsync(mail);
            t.MailGonderildiMi = true;
            t.MailNotu = "SMTP kabul edildi; To=" + t.Mail + "; CC=" + Cc;
            if (t.MailNotu.Length > 250) t.MailNotu = t.MailNotu[..250];
            t.Operasyon2OnayTarihi = DateTime.UtcNow;
            t.Durum = "Entegrasyon Bekleniyor";
            var jiraId = $"TICKET-{t.Id}";
            var task = await _db.JiraTasks.FirstOrDefaultAsync(x => x.JiraId == jiraId);
            if (task == null)
                _db.JiraTasks.Add(new JiraTask { JiraId = jiraId, TalepKonusu = $"Entegrasyon: {t.FirmaAdi}", TalepTuru = "Entegrasyon", TalepAcan = t.AtananOperasyonKullaniciAdi ?? User.Identity?.Name ?? "Sistem", Durum = "Beklemede", TakipEden = t.AtananOperasyonKullaniciAdi });
            else
            {
                task.TalepTuru = "Entegrasyon";
                task.Durum = "Beklemede";
                if (string.IsNullOrWhiteSpace(task.TalepKonusu)) task.TalepKonusu = $"Entegrasyon: {t.FirmaAdi}";
                if (string.IsNullOrWhiteSpace(task.TalepAcan)) task.TalepAcan = t.AtananOperasyonKullaniciAdi ?? "Sistem";
            }
            await _db.SaveChangesAsync();
            _logger.LogInformation("Ticket {TicketId}: SMTP accepted mail; To {To}; CC {Cc}; attachments {Count}", t.Id, t.Mail, Cc, template.Attachments.Count);
            return Json(new { success = true, message = "E-posta SMTP sunucusu tarafından kabul edildi. İş Entegrasyon Bekleniyor aşamasına geçirildi." });
        }
        catch (SmtpException ex)
        {
            _logger.LogError(ex, "SMTP gönderimi başarısız");
            return StatusCode(502, new { success = false, message = "SMTP sunucusu gönderimi kabul etmedi. Sunucu günlüklerini kontrol edin." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Ticket doküman gönderimi / kayıt hatası. SMTP kabulünden sonra DB başarısız olduysa tekrar gönderimden önce sunucu loglarını kontrol edin.");
            return StatusCode(500, new { success = false, message = "Gönderim veya kayıt sırasında hata oluştu. Tekrar denemeden önce sunucu loglarından gönderim durumunu doğrulayın." });
        }
        finally { SendLock.Release(); }
    }

    [HttpGet]
    [Authorize(Roles = "Admin")]
    public IActionResult Admin()
    {
        ViewBag.SupportCc = Cc;
        ViewBag.FromAddress = From;
        ViewBag.SmtpConfigured = Configured;
        return View(ReadTemplate());
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public IActionResult SaveTemplateForm(string subject, string body)
    {
        if (string.IsNullOrWhiteSpace(subject) || subject.Length > 300 || string.IsNullOrWhiteSpace(body) || body.Length > 12000)
        { TempData["MailError"] = "Konu/metin boş olamaz veya çok uzun."; return RedirectToAction(nameof(Admin)); }
        var t = ReadTemplate();
        t.Subject = subject.Trim(); t.Body = body.Trim();
        SaveTemplate(t);
        TempData["MailInfo"] = "Şablon kaydedildi.";
        return RedirectToAction(nameof(Admin));
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    [RequestSizeLimit(12_000_000)]
    public async Task<IActionResult> UploadDocument(IFormFile file)
    {
        if (file == null || file.Length == 0 || file.Length > 10_000_000 || !AcceptedExtensions.Contains(Path.GetExtension(file.FileName).ToLowerInvariant()))
        { TempData["MailError"] = "Yalnızca PDF, DOCX, XLSX veya TXT, en fazla 10 MB."; return RedirectToAction(nameof(Admin)); }
        var saved = Guid.NewGuid().ToString("N") + Path.GetExtension(file.FileName).ToLowerInvariant();
        var originalName = Path.GetFileName(file.FileName);
        if (originalName.Length > 160) originalName = originalName[^160..];
        await using (var output = System.IO.File.Create(Path.Combine(_attachments, saved))) await file.CopyToAsync(output);
        var t = ReadTemplate();
        t.Attachments.Add(new MailAttachment { Name = originalName, SavedName = saved });
        SaveTemplate(t);
        TempData["MailInfo"] = "Doküman eklendi.";
        return RedirectToAction(nameof(Admin));
    }

    [HttpPost]
    [Authorize(Roles = "Admin")]
    [ValidateAntiForgeryToken]
    public IActionResult RemoveDocument(string savedName)
    {
        var t = ReadTemplate();
        var a = t.Attachments.FirstOrDefault(x => x.SavedName == savedName);
        if (a != null)
        {
            t.Attachments.Remove(a);
            SaveTemplate(t);
            if (Path.GetFileName(a.SavedName) == a.SavedName)
                System.IO.File.Delete(Path.Combine(_attachments, a.SavedName));
        }
        return RedirectToAction(nameof(Admin));
    }
}
