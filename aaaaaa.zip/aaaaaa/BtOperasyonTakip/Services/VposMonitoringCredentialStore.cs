using System.Text.Json;
using BtOperasyonTakip.Data;
using BtOperasyonTakip.Models;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.EntityFrameworkCore;

namespace BtOperasyonTakip.Services;

public sealed class VposMonitoringCredentialStore : IVposMonitoringCredentialStore
{
    private const string TurPrefix = "VposMonitoringCredential:";

    private readonly AppDbContext _context;
    private readonly IDataProtector _protector;
    private readonly ILogger<VposMonitoringCredentialStore> _logger;

    public VposMonitoringCredentialStore(
        AppDbContext context,
        IDataProtectionProvider dataProtectionProvider,
        ILogger<VposMonitoringCredentialStore> logger)
    {
        _context = context;
        _protector = dataProtectionProvider.CreateProtector(
            "BtOperasyonTakip.VposMonitoring.Credentials.v1");
        _logger = logger;
    }

    public async Task<VposMonitoringCredential?> GetAsync(
        int userId,
        CancellationToken cancellationToken = default)
    {
        var tur = BuildTur(userId);

        var encrypted = await _context.Parametreler
            .AsNoTracking()
            .Where(x => x.Tur == tur && x.ParAdi != null)
            .OrderByDescending(x => x.Id)
            .Select(x => x.ParAdi)
            .FirstOrDefaultAsync(cancellationToken);

        if (string.IsNullOrWhiteSpace(encrypted))
            return null;

        try
        {
            var json = _protector.Unprotect(encrypted);
            return JsonSerializer.Deserialize<VposMonitoringCredential>(json);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(
                ex,
                "Kullanıcı {UserId} için kayıtlı Grafana kimlik bilgisi çözülemedi.",
                userId);
            return null;
        }
    }

    public async Task SaveAsync(
        int userId,
        VposMonitoringCredential credential,
        CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(credential);

        var tur = BuildTur(userId);
        var json = JsonSerializer.Serialize(credential);
        var encrypted = _protector.Protect(json);

        var existing = await _context.Parametreler
            .Where(x => x.Tur == tur)
            .ToListAsync(cancellationToken);

        if (existing.Count > 0)
            _context.Parametreler.RemoveRange(existing);

        _context.Parametreler.Add(new Parametre
        {
            Tur = tur,
            ParAdi = encrypted
        });

        await _context.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteAsync(
        int userId,
        CancellationToken cancellationToken = default)
    {
        var tur = BuildTur(userId);

        var existing = await _context.Parametreler
            .Where(x => x.Tur == tur)
            .ToListAsync(cancellationToken);

        if (existing.Count == 0)
            return;

        _context.Parametreler.RemoveRange(existing);
        await _context.SaveChangesAsync(cancellationToken);
    }

    private static string BuildTur(int userId) => $"{TurPrefix}{userId}";
}
