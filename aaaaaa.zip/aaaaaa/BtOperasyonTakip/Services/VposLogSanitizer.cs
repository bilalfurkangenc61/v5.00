using System.Text.RegularExpressions;

namespace BtOperasyonTakip.Services;

// UI-only redaction for Grafana log values. No database entities are changed.
public static class VposLogSanitizer
{
    private static readonly Regex CardCandidate = new(@"(?<!\d)(?:\d[ -]?){12,18}\d(?!\d)", RegexOptions.Compiled);
    private static readonly Regex SecretJson = new("""(?i)(["'](?:cvv2?|cvc2?|password|passwd|secret|access[_-]?token|authorization|api[_-]?key|pin|card[_-]?number|pan)["']\s*:\s*["'])([^"']*)(["'])""", RegexOptions.Compiled);
    private static readonly Regex SecretInline = new(@"(?i)(\b(?:cvv2?|cvc2?|password|passwd|secret|access[_ -]?token|authorization|api[_ -]?key|pin|card[_ -]?number|pan)\b\s*[:=]\s*)(\S+)", RegexOptions.Compiled);
    private static readonly string[] SecretKeys =
    [
        "password", "passwd", "secret", "cvv", "cvc", "pin", "token", "authorization",
        "apikey", "accesskey", "privatekey", "cardnumber", "cardno", "pan", "track2",
        "magstripe", "cryptogram", "securitycode", "expiry", "expiration", "cardholder"
    ];

    public static Dictionary<string, string> SafeFields(IReadOnlyDictionary<string, string> fields)
    {
        var safe = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var (key, value) in fields)
        {
            var normalized = Regex.Replace(key, @"[^a-zA-Z0-9]", "").ToLowerInvariant();
            safe[key] = SecretKeys.Any(k => normalized.Contains(k, StringComparison.Ordinal))
                ? "[GİZLENDİ]" : CleanText(value);
        }
        return safe;
    }

    public static string CleanMessage(string? value) => CleanText(value);

    public static string CleanText(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "-";
        var text = value.Length > 4096 ? value[..4096] + " …" : value;
        text = SecretJson.Replace(text, "$1[GİZLENDİ]$3");
        text = SecretInline.Replace(text, "$1[GİZLENDİ]");
        return CardCandidate.Replace(text, m =>
        {
            var digits = new string(m.Value.Where(char.IsDigit).ToArray());
            return digits.Length >= 13 && digits.Length <= 19 && IsValidLuhn(digits)
                ? "[KART GİZLENDİ]" : m.Value;
        });
    }

    private static bool IsValidLuhn(string digits)
    {
        var sum = 0;
        var doubleNext = false;
        for (var i = digits.Length - 1; i >= 0; i--)
        {
            var n = digits[i] - '0';
            if (doubleNext) { n *= 2; if (n > 9) n -= 9; }
            sum += n;
            doubleNext = !doubleNext;
        }
        return sum % 10 == 0;
    }
}
