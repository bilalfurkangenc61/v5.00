using System.Globalization;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using BtOperasyonTakip.Dtos;
using Microsoft.Extensions.Options;

namespace BtOperasyonTakip.Services;

public sealed class VposGrafanaDashboardGateway : IVposGrafanaDashboardGateway
{
    private readonly HttpClient _httpClient;
    private readonly VposGrafanaDashboardOptions _options;
    private readonly ILogger<VposGrafanaDashboardGateway> _logger;

    public VposGrafanaDashboardGateway(
        HttpClient httpClient,
        IOptions<VposGrafanaDashboardOptions> options,
        ILogger<VposGrafanaDashboardGateway> logger)
    {
        _httpClient = httpClient;
        _options = options.Value;
        _logger = logger;
    }

    public async Task<VposGrafanaConnectionInfo> TestAsync(
        VposMonitoringCredential credential,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var address = ParseDashboardAddress(credential);
            var auth = await AuthenticateAsync(address.BaseUrl, credential, cancellationToken);
            using var document = await GetDashboardAsync(address, auth, cancellationToken);
            var dashboard = GetDashboardNode(document.RootElement);
            var title = ReadString(dashboard, "title") ?? address.Uid;
            var panels = FlattenPanels(dashboard).Where(HasTargets).ToList();

            return new VposGrafanaConnectionInfo
            {
                Success = true,
                Message = $"Grafana dashboard bağlantısı başarılı. {panels.Count} sorgulanabilir panel bulundu.",
                DashboardTitle = title,
                PanelCount = panels.Count
            };
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "VPOS Grafana dashboard bağlantı testi başarısız.");
            return new VposGrafanaConnectionInfo
            {
                Success = false,
                Message = Friendly(ex)
            };
        }
    }

    public async Task<VposMonitoringResult> QueryAsync(
        VposMonitoringCredential credential,
        VposMonitoringFilter filter,
        string purpose,
        CancellationToken cancellationToken = default)
    {
        var result = new VposMonitoringResult { RetrievedAt = DateTime.Now };

        try
        {
            var normalizedFilter = filter.Normalized();
            var address = ParseDashboardAddress(credential);
            var auth = await AuthenticateAsync(address.BaseUrl, credential, cancellationToken);
            using var dashboardDocument = await GetDashboardAsync(address, auth, cancellationToken);
            var dashboard = GetDashboardNode(dashboardDocument.RootElement);

            result.DashboardTitle = ReadString(dashboard, "title") ?? address.Uid;
            result.DashboardUrl = credential.DashboardUrl;

            var allPanels = FlattenPanels(dashboard).Where(HasTargets).ToList();
            var selectedPanels = SelectPanels(allPanels, purpose).Take(Math.Max(1, _options.MaxPanelsPerRequest)).ToList();
            result.PanelCount = selectedPanels.Count;

            if (selectedPanels.Count == 0)
                throw new InvalidOperationException("Dashboard içinde sorgulanabilir panel bulunamadı.");

            var variableMap = BuildVariableMap(dashboard, normalizedFilter);
            var rows = new List<VposMonitoringRow>();
            var panelFailures = new List<string>();

            foreach (var panel in selectedPanels)
            {
                cancellationToken.ThrowIfCancellationRequested();
                try
                {
                    var panelRows = await QueryPanelAsync(
                        address,
                        auth,
                        dashboard,
                        panel,
                        variableMap,
                        normalizedFilter,
                        credential.ElasticUrl,
                        cancellationToken);
                    rows.AddRange(panelRows);
                    if (rows.Count >= _options.MaxRows)
                        break;
                }
                catch (Exception ex)
                {
                    if (ex is OperationCanceledException && cancellationToken.IsCancellationRequested)
                        throw;
                    var panelTitle = ReadString(panel, "title") ?? "Panel";
                    _logger.LogWarning(ex, "Grafana panel sorgusu başarısız: {PanelTitle}", panelTitle);
                    panelFailures.Add($"{panelTitle}: {Friendly(ex)}");
                }
            }

            // Bütün panel sorguları başarısızsa 0 kayıt = başarılı sorgu gibi gösterilmez.
            if (panelFailures.Count == selectedPanels.Count)
                throw new InvalidOperationException($"Grafana dashboard erişilebilir, ancak panel verileri okunamadı. {string.Join(" | ", panelFailures.Take(2))}");

            rows = rows.Take(Math.Max(100, _options.MaxRows)).ToList();
            rows = ApplyClientFilters(rows, normalizedFilter);

            result.Rows = rows
                .OrderByDescending(x => x.Timestamp ?? DateTime.MinValue)
                .ToList();

            result.Companies = Group(rows, x => x.Customer)
                .Where(x => x.Key != "-")
                .Take(1000)
                .ToList();
            result.Errors = Group(rows, x => x.NormalizedCode)
                .Where(x => x.Key != "-")
                .Take(1000)
                .ToList();
            result.Sources = Group(rows, x => x.Source).Take(100).ToList();
            result.Days = rows
                .Where(x => x.Timestamp.HasValue)
                .GroupBy(x => x.Timestamp!.Value.Date)
                .OrderByDescending(x => x.Key)
                .Select(x => new VposCountItem
                {
                    Key = x.Key.ToString("dd.MM.yyyy", CultureInfo.GetCultureInfo("tr-TR")),
                    Count = x.Sum(y => Math.Max(0L, y.Count))
                })
                .ToList();

            result.Success = true;
            result.Message = rows.Count == 0
                ? "Dashboard API'sine erişildi ancak sorgulardan işlenebilir kayıt gelmedi. Demo dashboard'larda VPOS hata/firma alanları bulunmayabilir."
                : $"Grafana dashboard üzerinden {rows.Count:N0} satır alındı.";
            if (panelFailures.Count > 0)
                result.Message += $" ({panelFailures.Count} panel başarısız: {string.Join(" | ", panelFailures.Take(2))})";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "VPOS Grafana dashboard verisi alınamadı.");
            result.Success = false;
            result.Message = Friendly(ex);
        }

        return result;
    }

    private async Task<List<VposMonitoringRow>> QueryPanelAsync(
        DashboardAddress address,
        GrafanaAuth auth,
        JsonElement dashboard,
        JsonElement panel,
        IReadOnlyDictionary<string, string> variableMap,
        VposMonitoringFilter filter,
        string? elasticFallbackUrl,
        CancellationToken cancellationToken)
    {
        if (!panel.TryGetProperty("targets", out var targets) || targets.ValueKind != JsonValueKind.Array)
            return new List<VposMonitoringRow>();

        var panelId = ReadInt(panel, "id");
        var panelTitle = ReadString(panel, "title") ?? $"Panel {panelId}";
        var panelDatasource = panel.TryGetProperty("datasource", out var ds) ? ds : default;
        var queryNodes = new List<JsonObject>();

        foreach (var target in targets.EnumerateArray())
        {
            if (target.ValueKind != JsonValueKind.Object) continue;
            if (target.TryGetProperty("hide", out var hidden) && hidden.ValueKind == JsonValueKind.True) continue;

            var node = JsonNode.Parse(target.GetRawText()) as JsonObject;
            if (node == null) continue;

            ReplaceVariables(node, variableMap);
            EnsureDatasource(node, panelDatasource, variableMap);

            if (node["refId"] == null)
                node["refId"] = ((char)('A' + Math.Min(queryNodes.Count, 25))).ToString();
            if (node["maxDataPoints"] == null)
                node["maxDataPoints"] = Math.Max(1000, _options.MaxRows);
            if (node["intervalMs"] == null)
                node["intervalMs"] = 1000;

            if (HasDatasourceUid(node))
                queryNodes.Add(node);
        }

        if (queryNodes.Count == 0)
            throw new InvalidOperationException("Panelde geçerli Grafana datasource UID bulunamadı; panel sorgusu oluşturulamadı.");

        var payload = new JsonObject
        {
            ["queries"] = new JsonArray(queryNodes.Select(x => (JsonNode)x).ToArray()),
            ["from"] = new DateTimeOffset(filter.EffectiveFrom).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture),
            ["to"] = new DateTimeOffset(filter.EffectiveTo).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture)
        };

        using var request = NewRequest(HttpMethod.Post, $"{address.BaseUrl}/api/ds/query", auth);
        request.Content = new StringContent(payload.ToJsonString(), Encoding.UTF8, "application/json");
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var json = await response.Content.ReadAsStringAsync(cancellationToken);

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException($"Grafana panel sorgusu HTTP {(int)response.StatusCode}: {TrimMessage(json)}");

        using var responseDoc = JsonDocument.Parse(json);
        var links = GetPanelLinks(panel);
        var grafanaPanelUrl = BuildGrafanaPanelUrl(credentialDashboardUrl: address.OriginalDashboardUrl, panelId, filter, dashboard);
        return ParseFrames(responseDoc.RootElement, panelTitle, panelId, links, grafanaPanelUrl, elasticFallbackUrl);
    }

    private List<VposMonitoringRow> ParseFrames(
        JsonElement root,
        string panelTitle,
        int? panelId,
        IReadOnlyList<string> links,
        string grafanaPanelUrl,
        string? elasticFallbackUrl)
    {
        var rows = new List<VposMonitoringRow>();
        if (!root.TryGetProperty("results", out var results) || results.ValueKind != JsonValueKind.Object)
            return rows;

        foreach (var resultProperty in results.EnumerateObject())
        {
            var result = resultProperty.Value;
            if (result.TryGetProperty("error", out var panelError) &&
                panelError.ValueKind != JsonValueKind.Null &&
                !string.IsNullOrWhiteSpace(ElementToString(panelError)))
                throw new InvalidOperationException("Grafana datasource sorgusu: " + TrimMessage(ElementToString(panelError)));
            if (!result.TryGetProperty("frames", out var frames) || frames.ValueKind != JsonValueKind.Array)
                continue;

            foreach (var frame in frames.EnumerateArray())
            {
                if (!frame.TryGetProperty("schema", out var schema) || !schema.TryGetProperty("fields", out var fields) || fields.ValueKind != JsonValueKind.Array)
                    continue;
                if (!frame.TryGetProperty("data", out var data) || !data.TryGetProperty("values", out var values) || values.ValueKind != JsonValueKind.Array)
                    continue;

                var fieldNames = fields.EnumerateArray()
                    .Select((x, i) =>
                    {
                        var name = ReadString(x, "name") ?? $"field{i}";
                        if (x.TryGetProperty("labels", out var labels) && labels.ValueKind == JsonValueKind.Object)
                        {
                            foreach (var label in labels.EnumerateObject())
                            {
                                if (label.Name.Contains("route", StringComparison.OrdinalIgnoreCase) ||
                                    label.Name.Contains("endpoint", StringComparison.OrdinalIgnoreCase) ||
                                    label.Name.Contains("method", StringComparison.OrdinalIgnoreCase))
                                    return label.Value.ToString();
                            }
                        }
                        return name;
                    }).ToList();
                var fieldLabels = fields.EnumerateArray().Select(x =>
                    x.TryGetProperty("labels", out var labels) && labels.ValueKind == JsonValueKind.Object
                        ? labels.Clone() : default).ToList();
                var valueArrays = values.EnumerateArray().ToList();
                var rowCount = valueArrays.Count == 0 ? 0 : valueArrays.Max(x => x.ValueKind == JsonValueKind.Array ? x.GetArrayLength() : 0);

                // Grafana can return a wide data frame: Time + many endpoint series.
                // Treat each route as its OWN series, not as one merged row (which
                // previously overwrote api.endpoint and lost almost all routes).
                var routeFields = fieldNames.Select((name, index) => new { name, index })
                    .Where(x => IsHttpRouteLabel(x.name)).ToList();
                if (routeFields.Count > 1 && MatchesAny(panelTitle, ["API", "SPI", "Çağrım", "Cagrim"]))
                {
                    foreach (var field in routeFields)
                    {
                        if (field.index >= valueArrays.Count || valueArrays[field.index].ValueKind != JsonValueKind.Array)
                            continue;
                        var routeMap = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
                        {
                            ["api.endpoint"] = field.name,
                            ["api.call.count"] = "0"
                        };
                        double sum = 0;
                        foreach (var value in valueArrays[field.index].EnumerateArray())
                        {
                            if (value.ValueKind == JsonValueKind.Number && value.TryGetDouble(out var numeric) && double.IsFinite(numeric) && numeric > 0)
                                sum += numeric;
                        }
                        if (sum <= 0) continue;
                        routeMap["api.call.count"] = sum.ToString(CultureInfo.InvariantCulture);
                        rows.Add(MapRow(routeMap, panelTitle, panelId, links, grafanaPanelUrl, elasticFallbackUrl));
                    }
                    continue;
                }

                for (var rowIndex = 0; rowIndex < rowCount; rowIndex++)
                {
                    var map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    for (var fieldIndex = 0; fieldIndex < fieldNames.Count && fieldIndex < valueArrays.Count; fieldIndex++)
                    {
                        var array = valueArrays[fieldIndex];
                        if (array.ValueKind != JsonValueKind.Array || rowIndex >= array.GetArrayLength()) continue;
                        map[fieldNames[fieldIndex]] = ElementToString(array[rowIndex]);
                        // Labels can contain merchant/error/message metadata not present in values.
                        if (fieldIndex < fieldLabels.Count && fieldLabels[fieldIndex].ValueKind == JsonValueKind.Object)
                        {
                            foreach (var label in fieldLabels[fieldIndex].EnumerateObject())
                            {
                                var labelValue = ElementToString(label.Value);
                                if (!string.IsNullOrWhiteSpace(labelValue))
                                    map.TryAdd("labels." + label.Name, labelValue);
                            }
                        }
                        // Grafana time-series: numeric Value is a call count; series field name is the API route.
                        if (fieldNames[fieldIndex].StartsWith("POST ", StringComparison.OrdinalIgnoreCase) ||
                            fieldNames[fieldIndex].StartsWith("GET ", StringComparison.OrdinalIgnoreCase) ||
                            fieldNames[fieldIndex].StartsWith("PUT ", StringComparison.OrdinalIgnoreCase) ||
                            fieldNames[fieldIndex].StartsWith("DELETE ", StringComparison.OrdinalIgnoreCase))
                        {
                            map["api.endpoint"] = fieldNames[fieldIndex];
                            map["api.call.count"] = ElementToString(array[rowIndex]);
                        }
                    }

                    if (map.Count == 0) continue;
                    // Grafana data frames sometimes carry the actual response message in
                    // a serialized log/JSON field rather than a separate message column.
                    ExpandStructuredLogFields(map);
                    var row = MapRow(map, panelTitle, panelId, links, grafanaPanelUrl, elasticFallbackUrl);
                    rows.Add(row);
                }
            }
        }
        return rows;
    }

    private static bool IsHttpRouteLabel(string name) =>
        Regex.IsMatch(name.Trim(), @"^(GET|POST|PUT|PATCH|DELETE|OPTIONS|HEAD)\s+", RegexOptions.IgnoreCase);

    private VposMonitoringRow MapRow(
        Dictionary<string, string> map,
        string panelTitle,
        int? panelId,
        IReadOnlyList<string> links,
        string grafanaPanelUrl,
        string? elasticFallbackUrl)
    {
        // Fields may be nested JSON. Work with extracted fields, but never expose
        // payment credentials or PAN/CVV values to Razor views / diagnostic logs.
        var customer = FindField(map, _options.CustomerFieldKeywords);
        if (string.IsNullOrWhiteSpace(customer))
            customer = FindField(map, new[] { "labels.baggage_merchantName", "baggage_merchantName", "merchantName", "merchant_id", "merchantId", "merchant", "isyeri", "işyeri", "customerName", "customer", "firma" });
        customer = string.IsNullOrWhiteSpace(customer) ? "-" : customer;
        var bank = FindField(map, new[] { "labels.bankName", "bank.name", "acquirer.name", "bankName", "acquirerBank", "bank_name", "bankCode", "bank.code", "issuerBank" });
        bank = string.IsNullOrWhiteSpace(bank) ? "-" : bank;
        var endpoint = FindField(map, new[] { "api.endpoint", "Api Çağrımı", "Api Cagrimi", "API Call", "http.route", "route", "endpoint", "url.path", "request.path", "path", "uri", "operation" });
        if (string.IsNullOrWhiteSpace(endpoint))
        {
            // Grafana'nın "En çok SPI Bazında Çağrım Sayısı" panelinde seri adı endpoint olabilir.
            endpoint = map.Values.FirstOrDefault(v => v.StartsWith("POST ", StringComparison.OrdinalIgnoreCase) || v.StartsWith("GET ", StringComparison.OrdinalIgnoreCase));
        }
        if (string.IsNullOrWhiteSpace(endpoint))
            endpoint = FindField(map, new[] { "metric", "Metric", "name", "Name", "displayName", "Display Name", "label", "Label", "SPI", "API", "routeName", "handler", "Controller/Action" });
        endpoint ??= "-";
        var sourceRaw = FindField(map, _options.SourceFieldKeywords) ?? InferSource(panelTitle);
        // Table column "Hata Mesaj" also contains 'hata'; find the code
        // column explicitly first so its text is never mistaken for the code.
        var codeRaw = FindField(map, new[] { "Hata Kodu", "Hata Kodu (Proc/Result)", "Hata Kodu (Proc/Res)", "error.code", "result.code", "response.code" })
                      ?? FindField(map, _options.ErrorCodeFieldKeywords)
                      ?? InferCode(map, panelTitle) ?? "-";
        // Keep the raw Grafana message distinct from a code-dictionary explanation.
        // An aggregate panel often returns code/count only, without any log message.
        var rawMessage = FindRealLogMessage(map);
        var message = string.IsNullOrWhiteSpace(rawMessage) ? "-" : VposLogSanitizer.CleanMessage(rawMessage);
        var def = VposErrorCatalog.Resolve(sourceRaw, codeRaw, message);
        var timestamp = ParseDate(FindField(map, _options.TimestampFieldKeywords));
        var traceId = FindField(map, new[] { "Trace ID", "TraceId", "trace_id", "trace.id", "traceId" }) ?? "-";
        var rrn = FindField(map, new[] { "RRN", "retrievalReferenceNumber", "retrieval_reference_number" }) ?? "-";
        var duration = FindField(map, new[] { "İşlem Süresi", "Islem Suresi", "processingDuration", "durationMs", "elapsed_ms" }) ?? "-";
        var transaction = traceId != "-" ? traceId : FindField(map, _options.TransactionFieldKeywords) ?? "-";
        var amount = FindField(map, _options.AmountFieldKeywords) ?? "-";
        var status = FindField(map, _options.StatusFieldKeywords) ?? "-";
        var rawCount = map.TryGetValue("api.call.count", out var apiCalls) ? apiCalls : FindField(map, _options.CountFieldKeywords);
        // Grafana API bar frames frequently contain only "Api Çağrımı" + "Count".
        // Such a row is an aggregation even when it has no time or merchant.
        // A row with a real trace/transaction identifier is a log event even
        // if its table also contains a numeric Count column.
        var hasEventIdentifier = traceId != "-" || rrn != "-";
        var isAggregate = !hasEventIdentifier && (!string.IsNullOrWhiteSpace(rawCount) ||
            MatchesAny(panelTitle, ["Dağılım", "Dagilim", "En Çok Hata", "En Cok Hata", "Top 15", "Çağrım Sayısı", "Cagrim Sayisi"]));
        var count = ParseCount(rawCount);
        var external = ResolveExternalLink(links, map, def, customer, transaction, timestamp) ?? NormalizeFallbackUrl(elasticFallbackUrl);

        return new VposMonitoringRow
        {
            Timestamp = timestamp,
            Customer = VposLogSanitizer.CleanText(customer),
            Bank = VposLogSanitizer.CleanText(bank),
            ApiEndpoint = VposLogSanitizer.CleanText(endpoint),
            Source = def.Source,
            RawCode = def.RawCode,
            NormalizedCode = def.NormalizedCode,
            Description = def.Description,
            GeneralDescription = def.GeneralDescription,
            Context = def.Context,
            TransactionId = VposLogSanitizer.CleanText(transaction),
            TraceId = VposLogSanitizer.CleanText(traceId),
            Rrn = VposLogSanitizer.CleanText(rrn),
            ProcessingDuration = VposLogSanitizer.CleanText(duration),
            Amount = VposLogSanitizer.CleanText(amount),
            Status = VposLogSanitizer.CleanText(status),
            Message = message,
            IsAggregate = isAggregate,
            HasRawLogMessage = !string.IsNullOrWhiteSpace(rawMessage),
            Count = count,
            PanelTitle = panelTitle,
            PanelId = panelId,
            GrafanaUrl = grafanaPanelUrl,
            ExternalLogUrl = external,
            Fields = VposLogSanitizer.SafeFields(map)
        };
    }

    private static List<VposMonitoringRow> ApplyClientFilters(
        IEnumerable<VposMonitoringRow> source,
        VposMonitoringFilter filter)
    {
        var query = source;
        if (!string.IsNullOrWhiteSpace(filter.TraceId))
            query = query.Where(x => string.Equals(x.TraceId, filter.TraceId, StringComparison.OrdinalIgnoreCase));
        if (!string.IsNullOrWhiteSpace(filter.Customer))
            query = query.Where(x => Contains(x.Customer, filter.Customer));
        if (!string.IsNullOrWhiteSpace(filter.Source))
            query = query.Where(x => Contains(x.Source, filter.Source));
        if (!string.IsNullOrWhiteSpace(filter.Code))
        {
            var normalized = VposErrorCatalog.NormalizeIso(filter.Code);
            query = query.Where(x =>
                string.Equals(x.NormalizedCode, normalized, StringComparison.OrdinalIgnoreCase) ||
                Contains(x.RawCode, filter.Code));
        }
        if (!string.IsNullOrWhiteSpace(filter.Q))
        {
            var q = filter.Q;
            query = query.Where(x =>
                x.Fields.Values.Any(v => Contains(v, q)) ||
                Contains(x.Description, q) || Contains(x.GeneralDescription, q));
        }
        query = query.Where(x => !x.Timestamp.HasValue || (x.Timestamp.Value >= filter.EffectiveFrom && x.Timestamp.Value <= filter.EffectiveTo));
        return query.ToList();
    }

    private static IEnumerable<VposCountItem> Group(IEnumerable<VposMonitoringRow> rows, Func<VposMonitoringRow, string> selector) =>
        rows.GroupBy(selector, StringComparer.OrdinalIgnoreCase)
            .Select(x => new VposCountItem { Key = x.Key, Count = x.Sum(y => Math.Max(0L, y.Count)) })
            .OrderByDescending(x => x.Count)
            .ThenBy(x => x.Key);

    private List<JsonElement> SelectPanels(IReadOnlyList<JsonElement> panels, string purpose)
    {
        // Target Grafana dashboard panels; avoid sending every panel query on each refresh.
        // This does not modify the existing session, Basic auth or datasource proxy flow.
        var kind = purpose.ToLowerInvariant();
        if (kind == "api-calls")
        {
            return panels.Where(p => MatchesAny(ReadString(p, "title") ?? "", new[]
                { "API Bazında Çağrım Sayısı", "API Bazinda Cagrim Sayisi", "SPI Bazında Çağrım Sayısı", "SPI Bazinda Cagrim Sayisi",
                  "API Çağrım", "API Cagrim", "API Çağrı", "API Cagri", "SPI Bazında", "SPI Bazinda", "Endpoint", "API Call Count" }))
                .OrderByDescending(p => MatchesAny(ReadString(p, "title") ?? "", new[] { "API Bazında Çağrım Sayısı", "API Bazinda Cagrim Sayisi" }))
                .Take(2).ToList();
        }
        if (kind == "important-errors")
        {
            // Read the actual Kibana-backed detail table instead of an error-code pie.
            // Without this panel we cannot truthfully supply merchant/trace/RRN.
            return panels.Where(p => MatchesAny(ReadString(p, "title") ?? "", new[]
                { "Önemli Hatalar Kibana Log", "Onemli Hatalar Kibana Log", "Önemli Hatalar", "Important Error Log" }))
                .OrderByDescending(p => MatchesAny(ReadString(p, "title") ?? "", new[] { "Birleştirilmiş", "Birlestirilmis" }))
                .ToList();
        }
        if (kind is "summary" or "performance" or "alarms")
        {
            return panels.Where(panel =>
            {
                var title = ReadString(panel, "title") ?? string.Empty;
                return kind switch
                {
                    "summary" => MatchesAny(title, ["Toplam API", "Başarılı API", "Basarili API", "Başarısız API", "Basarisiz API", "HTTP Error Rate", "Aktif Incident", "Active Incident", "Aktif Alert", "Active Alert"]),
                    "performance" => MatchesAny(title, ["Ortalama İşlem Süre", "Ortalama Islem Sure", "Ortalama Süre", "Average Duration", "Response Time"]),
                    _ => MatchesAny(title, ["Canlı Sistem Alarm", "Canli Sistem Alarm", "Sistem Alarmları", "System Alarm", "Alert List", "Active Problems"])
                };
            }).OrderByDescending(p => kind == "alarms" && MatchesAny(ReadString(p, "title") ?? "", new[] { "Detaylı Liste", "Detayli Liste", "Detailed List" }))
              .ThenBy(p => ReadString(p, "title") ?? "")
              .Take(kind == "summary" ? 8 : kind == "alarms" ? 5 : 2).ToList();
        }

        var keywords = kind switch
        {
            "errors" => _options.ErrorPanelKeywords,
            // Independent of the Top-5 client display, query raw/timeout/error
            // panels to find VS01 and VS05 without requiring either in TopErrors.
            "timeouts" => _options.ErrorPanelKeywords.Concat(_options.OutagePanelKeywords)
                .Concat(new[] { "Canlı Hata", "Canli Hata", "Log", "VS01", "VS05" }).Distinct(StringComparer.OrdinalIgnoreCase).ToArray(),
            "outages" => _options.OutagePanelKeywords,
            "transactions" => _options.TransactionPanelKeywords,
            _ => _options.TransactionPanelKeywords.Concat(_options.ErrorPanelKeywords).Distinct(StringComparer.OrdinalIgnoreCase).ToArray()
        };

        var matched = panels.Where(p =>
        {
            var title = ReadString(p, "title") ?? string.Empty;
            return keywords.Any(k => title.Contains(k, StringComparison.OrdinalIgnoreCase));
        }).ToList();

        if (purpose.Equals("transactions", StringComparison.OrdinalIgnoreCase))
        {
            var spi = panels.Where(p =>
            {
                var title = ReadString(p, "title") ?? "";
                return title.Contains("SPI", StringComparison.OrdinalIgnoreCase) ||
                       title.Contains("Çağrım Sayısı", StringComparison.OrdinalIgnoreCase) ||
                       title.Contains("Cagrim Sayisi", StringComparison.OrdinalIgnoreCase) ||
                       title.Contains("İşyeri", StringComparison.OrdinalIgnoreCase) ||
                       title.Contains("Isyeri", StringComparison.OrdinalIgnoreCase);
            }).ToList();
            foreach (var panel in spi)
                if (!matched.Contains(panel)) matched.Insert(0, panel);
        }
        if (kind == "timeouts")
        {
            // Prefer log/timeout panels over a Top-5-only aggregation so
            // uncommon timeout codes are not silently excluded from discovery.
            return matched.OrderByDescending(p =>
            {
                var title = ReadString(p, "title") ?? "";
                return MatchesAny(title, ["Canlı Hata", "Canli Hata", "Log", "Timeout", "VS01", "VS05"]) ? 1 : 0;
            }).ToList();
        }
        if (kind == "errors")
        {
            // The important-errors table and live log must not be pushed out by
            // the first 12 pie/KPI panels of a large Grafana dashboard.
            return matched.OrderByDescending(p =>
            {
                var title = ReadString(p, "title") ?? "";
                return MatchesAny(title, ["Önemli Hatalar Kibana Log", "Onemli Hatalar Kibana Log"]) ? 3 :
                       MatchesAny(title, ["Canlı Hata", "Canli Hata", "Live Error"]) ? 2 :
                       MatchesAny(title, ["Hata Kodları", "Hata Kodlari", "Error Code"]) ? 1 : 0;
            }).ToList();
        }
        if (matched.Count > 0) return matched;
        return panels.Where(IsLikelyDataPanel).ToList();
    }

    private static bool IsLikelyDataPanel(JsonElement panel)
    {
        var type = ReadString(panel, "type") ?? string.Empty;
        return !type.Equals("text", StringComparison.OrdinalIgnoreCase) &&
               !type.Equals("row", StringComparison.OrdinalIgnoreCase) &&
               !type.Equals("dashlist", StringComparison.OrdinalIgnoreCase);
    }

    private static bool HasTargets(JsonElement panel) =>
        panel.TryGetProperty("targets", out var targets) &&
        targets.ValueKind == JsonValueKind.Array &&
        targets.GetArrayLength() > 0;

    private static List<JsonElement> FlattenPanels(JsonElement dashboard)
    {
        var result = new List<JsonElement>();
        if (!dashboard.TryGetProperty("panels", out var panels) || panels.ValueKind != JsonValueKind.Array)
            return result;
        WalkPanels(panels, result);
        return result;
    }

    private static void WalkPanels(JsonElement panels, ICollection<JsonElement> result)
    {
        foreach (var panel in panels.EnumerateArray())
        {
            result.Add(panel.Clone());
            if (panel.TryGetProperty("panels", out var nested) && nested.ValueKind == JsonValueKind.Array)
                WalkPanels(nested, result);
        }
    }

    private IReadOnlyDictionary<string, string> BuildVariableMap(JsonElement dashboard, VposMonitoringFilter filter)
    {
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (!dashboard.TryGetProperty("templating", out var templating) ||
            !templating.TryGetProperty("list", out var list) ||
            list.ValueKind != JsonValueKind.Array)
            return values;

        foreach (var variable in list.EnumerateArray())
        {
            var name = ReadString(variable, "name");
            if (string.IsNullOrWhiteSpace(name)) continue;
            var label = ReadString(variable, "label") ?? name;
            var descriptor = name + " " + label;

            string? selected = null;
            if (MatchesAny(descriptor, ["traceid", "trace id", "trace_id", "trace.id"]) && !string.IsNullOrWhiteSpace(filter.TraceId))
                selected = filter.TraceId;
            else if (MatchesAny(descriptor, _options.CustomerFieldKeywords)) selected = filter.Customer ?? ".*";
            else if (MatchesAny(descriptor, _options.ErrorCodeFieldKeywords)) selected = filter.Code ?? ".*";
            else if (MatchesAny(descriptor, _options.SourceFieldKeywords)) selected = filter.Source ?? ".*";

            if (selected != null)
                values[name] = selected;
            else if (variable.TryGetProperty("current", out var current))
            {
                var currentValue = CurrentVariableValue(current);
                if (!string.IsNullOrWhiteSpace(currentValue)) values[name] = currentValue;
            }
        }
        return values;
    }

    private static string? CurrentVariableValue(JsonElement current)
    {
        if (!current.TryGetProperty("value", out var value)) return null;
        return value.ValueKind switch
        {
            JsonValueKind.String => value.GetString(),
            JsonValueKind.Array => string.Join(",", value.EnumerateArray().Select(ElementToString)),
            _ => ElementToString(value)
        };
    }

    private static void ReplaceVariables(JsonNode node, IReadOnlyDictionary<string, string> variables)
    {
        if (node is JsonObject obj)
        {
            foreach (var key in obj.Select(x => x.Key).ToList())
            {
                var child = obj[key];
                if (child is JsonValue value && value.TryGetValue<string>(out var text))
                    obj[key] = ReplaceVariableText(text, variables);
                else if (child != null)
                    ReplaceVariables(child, variables);
            }
        }
        else if (node is JsonArray arr)
        {
            for (var i = 0; i < arr.Count; i++)
            {
                var child = arr[i];
                if (child is JsonValue value && value.TryGetValue<string>(out var text))
                    arr[i] = ReplaceVariableText(text, variables);
                else if (child != null)
                    ReplaceVariables(child, variables);
            }
        }
    }

    private static string ReplaceVariableText(string text, IReadOnlyDictionary<string, string> variables)
    {
        var result = text;
        foreach (var pair in variables)
        {
            result = result.Replace("$" + pair.Key, pair.Value, StringComparison.OrdinalIgnoreCase);
            result = Regex.Replace(result, @"\$\{" + Regex.Escape(pair.Key) + @"(?::[^}]*)?\}", _ => pair.Value, RegexOptions.IgnoreCase);
            result = Regex.Replace(result, @"\[\[" + Regex.Escape(pair.Key) + @"(?::[^]]*)?\]\]", _ => pair.Value, RegexOptions.IgnoreCase);
        }
        return result;
    }

    private static void EnsureDatasource(JsonObject target, JsonElement panelDatasource, IReadOnlyDictionary<string, string> variables)
    {
        if (target["datasource"] == null && panelDatasource.ValueKind != JsonValueKind.Undefined && panelDatasource.ValueKind != JsonValueKind.Null)
        {
            var node = JsonNode.Parse(panelDatasource.GetRawText());
            if (node != null)
            {
                ReplaceVariables(node, variables);
                target["datasource"] = node;
            }
        }

        if (target["datasource"] is JsonValue value && value.TryGetValue<string>(out var uid))
            target["datasource"] = new JsonObject { ["uid"] = uid };
    }

    private static bool HasDatasourceUid(JsonObject target)
    {
        if (target["datasource"] is not JsonObject ds) return false;
        return ds["uid"] is JsonValue uid && uid.TryGetValue<string>(out var value) && !string.IsNullOrWhiteSpace(value);
    }

    private async Task<GrafanaAuth> AuthenticateAsync(string baseUrl, VposMonitoringCredential credential, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(credential.Username) && string.IsNullOrWhiteSpace(credential.Password))
            return new GrafanaAuth();

        if (string.IsNullOrWhiteSpace(credential.Username) || string.IsNullOrWhiteSpace(credential.Password))
            throw new InvalidOperationException("Grafana kullanıcı adı ve şifre birlikte girilmelidir.");

        var basic = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{credential.Username}:{credential.Password}"));
        using (var request = new HttpRequestMessage(HttpMethod.Get, $"{baseUrl}/api/user"))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", basic);
            using var response = await _httpClient.SendAsync(request, cancellationToken);
            if (response.IsSuccessStatusCode)
                return new GrafanaAuth { BasicToken = basic };
        }

        using var loginRequest = new HttpRequestMessage(HttpMethod.Post, $"{baseUrl}/login");
        loginRequest.Content = new StringContent(JsonSerializer.Serialize(new
        {
            user = credential.Username,
            password = credential.Password
        }), Encoding.UTF8, "application/json");

        using var loginResponse = await _httpClient.SendAsync(loginRequest, cancellationToken);
        var body = await loginResponse.Content.ReadAsStringAsync(cancellationToken);
        if (!loginResponse.IsSuccessStatusCode)
            throw new InvalidOperationException($"Grafana giriş başarısız. HTTP {(int)loginResponse.StatusCode}: {TrimMessage(body)}");

        if (!loginResponse.Headers.TryGetValues("Set-Cookie", out var cookies))
            throw new InvalidOperationException("Grafana giriş oturumu oluşturulamadı. Kurulum SSO/LDAP kullanıyor olabilir.");

        var cookie = string.Join("; ", cookies.Select(x => x.Split(';', 2)[0].Trim()).Where(x => x.Length > 0));
        if (string.IsNullOrWhiteSpace(cookie))
            throw new InvalidOperationException("Grafana oturum cookie'si alınamadı.");

        using var verify = NewRequest(HttpMethod.Get, $"{baseUrl}/api/user", new GrafanaAuth { CookieHeader = cookie });
        using var verifyResponse = await _httpClient.SendAsync(verify, cancellationToken);
        if (!verifyResponse.IsSuccessStatusCode)
            throw new InvalidOperationException("Grafana oturumu açıldı ancak API erişimine izin verilmedi.");

        return new GrafanaAuth { CookieHeader = cookie };
    }

    private async Task<JsonDocument> GetDashboardAsync(DashboardAddress address, GrafanaAuth auth, CancellationToken cancellationToken)
    {
        using var request = NewRequest(HttpMethod.Get, $"{address.BaseUrl}/api/dashboards/uid/{Uri.EscapeDataString(address.Uid)}", auth);
        using var response = await _httpClient.SendAsync(request, cancellationToken);
        var body = await response.Content.ReadAsStringAsync(cancellationToken);
        if (!response.IsSuccessStatusCode)
        {
            var hint = (int)response.StatusCode is 401 or 403
                ? " Public dashboard tarayıcıdan açılabilir ancak Grafana Dashboard API erişimi kapalı olabilir."
                : string.Empty;
            throw new InvalidOperationException($"Grafana dashboard API HTTP {(int)response.StatusCode}.{hint} Yanıt: {TrimMessage(body)}");
        }
        if (!body.TrimStart().StartsWith("{", StringComparison.Ordinal))
            throw new InvalidOperationException($"Grafana dashboard API JSON yerine başka içerik döndürdü (HTTP {(int)response.StatusCode}, Content-Type: {response.Content.Headers.ContentType?.MediaType ?? "bilinmiyor"}). Oturum yönlendirmesi veya yanlış API adresi olabilir.");
        try { return JsonDocument.Parse(body); }
        catch (JsonException ex)
        {
            throw new InvalidOperationException("Grafana dashboard API geçerli JSON döndürmedi: " + ex.Message, ex);
        }
    }

    private static JsonElement GetDashboardNode(JsonElement root)
    {
        if (root.TryGetProperty("dashboard", out var dashboard)) return dashboard;
        if (root.TryGetProperty("spec", out var spec)) return spec;
        throw new InvalidOperationException("Grafana dashboard JSON formatı tanınamadı.");
    }

    private static HttpRequestMessage NewRequest(HttpMethod method, string url, GrafanaAuth auth)
    {
        var request = new HttpRequestMessage(method, url);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        if (!string.IsNullOrWhiteSpace(auth.BasicToken))
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", auth.BasicToken);
        if (!string.IsNullOrWhiteSpace(auth.CookieHeader))
            request.Headers.TryAddWithoutValidation("Cookie", auth.CookieHeader);
        return request;
    }

    private DashboardAddress ParseDashboardAddress(VposMonitoringCredential credential)
    {
        var dashboardUrl = string.IsNullOrWhiteSpace(credential.DashboardUrl) ? credential.GrafanaUrl : credential.DashboardUrl;
        if (string.IsNullOrWhiteSpace(dashboardUrl))
            throw new InvalidOperationException("Grafana dashboard URL'si girilmedi.");
        if (!Uri.TryCreate(dashboardUrl, UriKind.Absolute, out var uri) || (uri.Scheme != "https" && uri.Scheme != "http"))
            throw new InvalidOperationException("Grafana dashboard URL'si geçerli değil.");
        if (!string.IsNullOrWhiteSpace(uri.UserInfo))
            throw new InvalidOperationException("Grafana URL içinde kullanıcı adı/şifre bulunmamalı.");
        if (_options.AllowedHosts.Length > 0 && !_options.AllowedHosts.Any(x => string.Equals(x, uri.Host, StringComparison.OrdinalIgnoreCase)))
            throw new InvalidOperationException("Grafana host adresi VposGrafanaDashboard:AllowedHosts listesinde değil.");

        var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        var markerIndex = Array.FindIndex(segments, x => x.Equals("d", StringComparison.OrdinalIgnoreCase) || x.Equals("d-solo", StringComparison.OrdinalIgnoreCase));
        if (markerIndex < 0 || markerIndex + 1 >= segments.Length)
            throw new InvalidOperationException("Dashboard URL içinde /d/{uid}/... yapısı bulunamadı.");

        var uid = segments[markerIndex + 1];
        var prefix = markerIndex == 0 ? string.Empty : "/" + string.Join('/', segments.Take(markerIndex));
        var baseUrl = $"{uri.Scheme}://{uri.Authority}{prefix}".TrimEnd('/');
        return new DashboardAddress(baseUrl, uid, dashboardUrl);
    }

    private static string BuildGrafanaPanelUrl(string credentialDashboardUrl, int? panelId, VposMonitoringFilter filter, JsonElement dashboard)
    {
        if (!Uri.TryCreate(credentialDashboardUrl, UriKind.Absolute, out var uri)) return credentialDashboardUrl;
        var query = ParseQuery(uri.Query);
        query["from"] = new DateTimeOffset(filter.EffectiveFrom).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        query["to"] = new DateTimeOffset(filter.EffectiveTo).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture);
        if (panelId.HasValue) query["viewPanel"] = panelId.Value.ToString(CultureInfo.InvariantCulture);

        if (dashboard.TryGetProperty("templating", out var templating) && templating.TryGetProperty("list", out var list) && list.ValueKind == JsonValueKind.Array)
        {
            foreach (var variable in list.EnumerateArray())
            {
                var name = ReadString(variable, "name");
                var label = ReadString(variable, "label") ?? name;
                if (string.IsNullOrWhiteSpace(name)) continue;
                var descriptor = name + " " + label;
                if (!string.IsNullOrWhiteSpace(filter.Customer) && MatchesAny(descriptor, ["customer", "merchant", "firma", "musteri", "müşteri", "uye"])) query[$"var-{name}"] = filter.Customer;
                else if (!string.IsNullOrWhiteSpace(filter.Source) && MatchesAny(descriptor, ["source", "provider", "processor", "kaynak", "bank"])) query[$"var-{name}"] = filter.Source;
                else if (!string.IsNullOrWhiteSpace(filter.Code) && MatchesAny(descriptor, ["error", "hata", "code", "response", "iso"])) query[$"var-{name}"] = filter.Code;
            }
        }

        var builder = new UriBuilder(uri) { Query = string.Join('&', query.Select(x => $"{Uri.EscapeDataString(x.Key)}={Uri.EscapeDataString(x.Value)}")) };
        return builder.Uri.ToString();
    }

    private static Dictionary<string, string> ParseQuery(string query)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var part in query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var pieces = part.Split('=', 2);
            result[Uri.UnescapeDataString(pieces[0])] = pieces.Length > 1 ? Uri.UnescapeDataString(pieces[1]) : string.Empty;
        }
        return result;
    }

    private static IReadOnlyList<string> GetPanelLinks(JsonElement panel)
    {
        var result = new List<string>();
        CollectUrls(panel, result);
        return result
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private static void CollectUrls(JsonElement element, ICollection<string> result)
    {
        if (element.ValueKind == JsonValueKind.Object)
        {
            foreach (var property in element.EnumerateObject())
            {
                if (property.Name.Equals("url", StringComparison.OrdinalIgnoreCase) && property.Value.ValueKind == JsonValueKind.String)
                {
                    var value = property.Value.GetString();
                    if (!string.IsNullOrWhiteSpace(value)) result.Add(value);
                }
                else if (property.Value.ValueKind is JsonValueKind.Object or JsonValueKind.Array)
                {
                    CollectUrls(property.Value, result);
                }
            }
        }
        else if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray()) CollectUrls(item, result);
        }
    }

    private static string? ResolveExternalLink(
        IReadOnlyList<string> links,
        IReadOnlyDictionary<string, string> fields,
        VposErrorDefinition error,
        string customer,
        string transaction,
        DateTime? timestamp)
    {
        var template = links.FirstOrDefault(x =>
            x.Contains("elastic", StringComparison.OrdinalIgnoreCase) ||
            x.Contains("kibana", StringComparison.OrdinalIgnoreCase) ||
            x.Contains("discover", StringComparison.OrdinalIgnoreCase) ||
            x.Contains("logs", StringComparison.OrdinalIgnoreCase));
        if (string.IsNullOrWhiteSpace(template)) return null;

        var result = template;
        result = result.Replace("${__value.text}", Uri.EscapeDataString(error.RawCode), StringComparison.OrdinalIgnoreCase)
            .Replace("${__value.raw}", Uri.EscapeDataString(error.RawCode), StringComparison.OrdinalIgnoreCase)
            .Replace("$customer", Uri.EscapeDataString(customer), StringComparison.OrdinalIgnoreCase)
            .Replace("$transaction", Uri.EscapeDataString(transaction), StringComparison.OrdinalIgnoreCase);

        foreach (var pair in fields)
        {
            var escaped = Uri.EscapeDataString(pair.Value ?? string.Empty);
            var pattern = "\\$\\{__data\\.fields\\[?[\\\"']?" + Regex.Escape(pair.Key) + "[\\\"']?\\]?\\}";
            result = Regex.Replace(result, pattern, _ => escaped, RegexOptions.IgnoreCase);
        }

        if (timestamp.HasValue)
            result = result.Replace("${__from}", new DateTimeOffset(timestamp.Value.AddMinutes(-5)).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase)
                .Replace("${__to}", new DateTimeOffset(timestamp.Value.AddMinutes(5)).ToUnixTimeMilliseconds().ToString(CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase);
        return result;
    }

    private static string? NormalizeFallbackUrl(string? url)
    {
        if (string.IsNullOrWhiteSpace(url)) return null;
        return Uri.TryCreate(url, UriKind.Absolute, out var uri) && (uri.Scheme == "https" || uri.Scheme == "http") && string.IsNullOrWhiteSpace(uri.UserInfo)
            ? uri.ToString()
            : null;
    }

    private static string? FindRealLogMessage(IReadOnlyDictionary<string, string> fields)
    {
        // First prefer explicit log-message keys; vague matches like "status" or
        // "description" can otherwise pick up unrelated panel metadata.
        string[] preferred =
        [
            "Hata Mesaj", "Hata Mesajı", "Hata Mesaji", "error.message", "exception.message", "response.message", "responseMessage",
            "errorMessage", "error_message", "log.message", "message", "msg",
            "error.reason", "response.description", "responseDescription",
            "result.message", "status.message", "reason", "detail", "log", "line"
        ];
        foreach (var key in preferred)
        {
            var value = fields.FirstOrDefault(x =>
                NormalizeName(x.Key) == NormalizeName(key) ||
                NormalizeName(x.Key).EndsWith(NormalizeName(key), StringComparison.OrdinalIgnoreCase)).Value;
            if (IsReadableMessage(value)) return value.Trim();
        }
        var fallback = FindField(fields, new[] { "message", "description", "açıklama", "aciklama" });
        return IsReadableMessage(fallback) ? fallback!.Trim() : null;
    }

    private static bool IsReadableMessage(string? value) =>
        !string.IsNullOrWhiteSpace(value) && value.Trim() != "-" &&
        !long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out _) &&
        !(value.TrimStart().StartsWith("{", StringComparison.Ordinal) ||
          value.TrimStart().StartsWith("[", StringComparison.Ordinal));

    private static void ExpandStructuredLogFields(Dictionary<string, string> map)
    {
        // Some Grafana panels return a full JSON log line or an Elasticsearch _source
        // object serialized as a string. Flatten a bounded depth without changing the
        // existing dashboard request, authentication or database model.
        foreach (var pair in map.ToList())
        {
            var key = NormalizeName(pair.Key);
            if (!(key == "log" || key == "line" || key == "raw" ||
                  key == "json" || key == "source" || key == "_source" ||
                  key == "message" || key == "data" || key == "document"))
                continue;
            var text = pair.Value?.Trim();
            if (string.IsNullOrWhiteSpace(text) || text.Length > 65536 ||
                !(text.StartsWith("{", StringComparison.Ordinal) || text.StartsWith("[", StringComparison.Ordinal)))
                continue;
            try
            {
                using var doc = JsonDocument.Parse(text);
                if (doc.RootElement.ValueKind == JsonValueKind.Object)
                    FlattenLogObject(doc.RootElement, map, "", 0);
            }
            catch (JsonException) { /* Plain text log line; keep it unchanged. */ }
        }
    }

    private static void FlattenLogObject(JsonElement obj, Dictionary<string, string> map, string prefix, int depth)
    {
        if (depth >= 5 || map.Count > 150 || obj.ValueKind != JsonValueKind.Object) return;
        foreach (var property in obj.EnumerateObject())
        {
            var name = string.IsNullOrEmpty(prefix) ? property.Name : prefix + "." + property.Name;
            if (property.Value.ValueKind == JsonValueKind.Object)
                FlattenLogObject(property.Value, map, name, depth + 1);
            else if (property.Value.ValueKind is JsonValueKind.String or JsonValueKind.Number)
            {
                var value = ElementToString(property.Value);
                if (!string.IsNullOrWhiteSpace(value) && value.Length <= 8192)
                    map.TryAdd(name, value);
            }
        }
    }

    private static string? FindField(IReadOnlyDictionary<string, string> map, IReadOnlyList<string> keywords)
    {
        foreach (var key in keywords)
        {
            var exact = map.FirstOrDefault(x => NormalizeName(x.Key) == NormalizeName(key));
            if (!string.IsNullOrWhiteSpace(exact.Key) && !string.IsNullOrWhiteSpace(exact.Value)) return exact.Value;
        }
        foreach (var item in map)
        {
            var normalized = NormalizeName(item.Key);
            if (keywords.Any(k => normalized.Contains(NormalizeName(k), StringComparison.OrdinalIgnoreCase)) && !string.IsNullOrWhiteSpace(item.Value))
                return item.Value;
        }
        return null;
    }

    private static string? InferCode(IReadOnlyDictionary<string, string> map, string panelTitle)
    {
        // A Grafana pie/bar may return { Metric: "BANKA: 51", Value: 4549 }.
        // The numeric Value is the COUNT, not the error code.
        if (!MatchesAny(panelTitle, ["hata", "error", "decline", "ret "])) return null;
        foreach (var pair in map)
        {
            if (!MatchesAny(pair.Key, ["metric", "code", "label", "name", "series", "result", "proc"])) continue;
            var code = CodeFromLabel(pair.Value);
            if (code != null) return code;
        }
        foreach (var pair in map)
        {
            if (MatchesAny(pair.Key, ["value", "count", "time", "timestamp", "date"])) continue;
            var code = CodeFromLabel(pair.Value);
            if (code != null) return code;
        }
        return null;
    }

    private static string? CodeFromLabel(string? text)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        var label = text.Trim();
        var match = Regex.Match(label,
            @"(?i)^(?:(?:BANKA|VPOS|SANALPOS|ERROR|HATA)\s*:\s*)?\*?(?<code>(?:VB|VS)\d{2}|\d{2,3})\*?(?:\s*\(.*\))?$",
            RegexOptions.CultureInvariant);
        return match.Success ? match.Groups["code"].Value.ToUpperInvariant() : null;
    }

    private static string InferSource(string panelTitle) => VposErrorCatalog.NormalizeSource(panelTitle);

    private static long ParseCount(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return 1;
        var clean = value.Replace(".", string.Empty).Replace(",", ".");
        return double.TryParse(clean, NumberStyles.Any, CultureInfo.InvariantCulture, out var d) && d > 0
            ? Math.Max(0, (long)Math.Round(d))
            : 0;
    }

    private static DateTime? ParseDate(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        if (long.TryParse(value, out var epoch))
        {
            try
            {
                return epoch > 100000000000
                    ? DateTimeOffset.FromUnixTimeMilliseconds(epoch).LocalDateTime
                    : DateTimeOffset.FromUnixTimeSeconds(epoch).LocalDateTime;
            }
            catch { }
        }
        return DateTime.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal, out var dt) ||
               DateTime.TryParse(value, CultureInfo.GetCultureInfo("tr-TR"), DateTimeStyles.AssumeLocal, out dt)
            ? dt
            : null;
    }

    private static string ElementToString(JsonElement element) => element.ValueKind switch
    {
        JsonValueKind.String => element.GetString() ?? string.Empty,
        JsonValueKind.Number => element.GetRawText(),
        JsonValueKind.True => "true",
        JsonValueKind.False => "false",
        JsonValueKind.Null => string.Empty,
        _ => element.ToString()
    };

    private static bool MatchesAny(string text, IEnumerable<string> keywords) =>
        keywords.Any(x => text.Contains(x, StringComparison.OrdinalIgnoreCase));

    private static bool Contains(string? value, string? term) =>
        !string.IsNullOrWhiteSpace(value) && !string.IsNullOrWhiteSpace(term) && value.Contains(term, StringComparison.OrdinalIgnoreCase);

    private static string NormalizeName(string value) =>
        Regex.Replace(value ?? string.Empty, @"[^a-zA-Z0-9ğüşöçıİĞÜŞÖÇ@]", string.Empty).ToLowerInvariant();

    private static string? ReadString(JsonElement element, string property) =>
        element.ValueKind == JsonValueKind.Object && element.TryGetProperty(property, out var value)
            ? value.ValueKind == JsonValueKind.String ? value.GetString() : value.ToString()
            : null;

    private static int? ReadInt(JsonElement element, string property) =>
        element.ValueKind == JsonValueKind.Object && element.TryGetProperty(property, out var value) && value.TryGetInt32(out var i) ? i : null;

    private static string TrimMessage(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "yanıt yok";
        var x = Regex.Replace(value, @"\s+", " ").Trim();
        return x.Length <= 240 ? x : x[..240] + "...";
    }

    private static string Friendly(Exception ex)
    {
        if (ex is TaskCanceledException) return "Grafana isteği zaman aşımına uğradı.";
        if (ex is HttpRequestException) return "Grafana sunucusuna ulaşılamadı: " + ex.Message;
        return ex.Message;
    }

    private sealed class GrafanaAuth
    {
        public string? BasicToken { get; init; }
        public string? CookieHeader { get; init; }
    }

    private sealed record DashboardAddress(string BaseUrl, string Uid, string OriginalDashboardUrl);
}
