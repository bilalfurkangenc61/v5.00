using System.Text.RegularExpressions;

namespace BtOperasyonTakip.Services;

public sealed record VposErrorDefinition(
    string Source,
    string RawCode,
    string NormalizedCode,
    string Description,
    string GeneralDescription,
    string Context = "GENEL");

public static class VposErrorCatalog
{
    private static readonly IReadOnlyDictionary<string, string> Iso = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
        ["01"] = "Banka Onaylamadı",
        ["04"] = "Kart Blokeli / Alıkonulmalı",
        ["05"] = "İşlem Reddedildi (Genel Ret)",
        ["12"] = "Geçersiz İşlem",
        ["13"] = "Geçersiz Tutar",
        ["14"] = "Geçersiz Kart Numarası",
        ["30"] = "Biçim/Alan Hatası",
        ["41"] = "Kart Kayıp",
        ["43"] = "Kart Çalıntı",
        ["51"] = "Yetersiz Bakiye",
        ["54"] = "Kartın Son Kullanma Tarihi Geçmiş",
        ["55"] = "Hatalı PIN",
        ["57"] = "İşlem İzni Yok (Kart)",
        ["58"] = "İşlem İzni Yok (POS/Üye İşyeri)",
        ["61"] = "Limit Aşıldı",
        ["62"] = "Kısıtlı Kart (Bölge/Tür)",
        ["65"] = "İşlem Sayısı/Limit Aşıldı",
        ["75"] = "PIN Deneme Sayısı Aşıldı",
        ["91"] = "Banka Yanıt Vermiyor",
        ["92"] = "Geçersiz Banka/İletim Yolu",
        ["94"] = "Yinelenen İşlem",
        ["96"] = "Banka Sistem Hatası"
    };

    private static readonly IReadOnlyDictionary<string, string> Banksoft = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
        ["000"] = "Onay Kodu xxxxxx",
        ["001"] = "Bankanızı Arayın",
        ["002"] = "Bankanızı Arayın",
        ["004"] = "Red-Karta El Koy",
        ["005"] = "Red-Onaylanmadı / İşlem Onaylanmadı",
        ["008"] = "Kimlik Kontrolü / Onay Kodu xx",
        ["009"] = "Lütfen İşlemi Tekrar Deneyiniz",
        ["011"] = "Onay Kodu xxxxxx / VIP-İşlem İçin Onay Verildi",
        ["012"] = "Red-Geçersiz İşlem / Geçersiz İşlem",
        ["013"] = "Red-Geçersiz Tutar / Geçersiz İşlem Tutarı",
        ["014"] = "Red-Hatalı Kart / Geçersiz Kart Numarası",
        ["015"] = "Red-Geçersiz Kart / Kart Veren Banka Tanımsız",
        ["030"] = "Bankanızı Arayın",
        ["033"] = "Red-Karta El Koy / Vade Sonu Geçmiş-Karta El Koyunuz",
        ["034"] = "Red-Karta El Koy / Sahtekârlık-Karta El Koyunuz",
        ["038"] = "Red-Karta El Koy / Hatalı Şifre-Karta El Koy",
        ["041"] = "Red-Karta El Koy / Kayıp Kart-Karta El Koy",
        ["043"] = "Red-Karta El Koy / Çalıntı Kart-Karta El Koyunuz",
        ["051"] = "Red-Yetersiz Limit",
        ["054"] = "Red-Onaylanmadı / Vade Sonu Geçmiş Kart",
        ["055"] = "Red-Şifre Tekrar / Hatalı Kart Şifresi",
        ["057"] = "Red-Onaylanmadı / İşlem Tipine Müsaade Yok",
        ["058"] = "Red-Onaylanmadı / İşlem Tipi Terminale Kapalı",
        ["062"] = "Red-Onaylanmadı",
        ["065"] = "Bankanızı Arayın / Para Çekme Adet Limiti Aşıldı",
        ["075"] = "Red-Onaylanmadı",
        ["091"] = "Bankanızı Arayın / Kartı Veren Banka Hizmet Dışı",
        ["092"] = "Red-Geçersiz Kart",
        ["096"] = "Sistem Arızası / Bankanızı Arayın",
        ["718"] = "Kart Kaynaklı Hata - Kartın Tüm Bilgileri Kontrol Edilmelidir",
        ["748"] = "Kart Kaynaklı Hata - Kartın Tüm Bilgileri Kontrol Edilmelidir"
    };

    public static VposErrorDefinition Resolve(string? source, string? rawCode, string? message = null)
    {
        var raw = CleanRaw(rawCode);
        var normalized = NormalizeIso(raw);
        var src = raw.StartsWith("VS", StringComparison.OrdinalIgnoreCase) || raw.StartsWith("VB", StringComparison.OrdinalIgnoreCase)
            ? "VPOS" : NormalizeSource(source);
        var general = Iso.TryGetValue(normalized, out var iso) ? iso :
            raw.Equals("VS01", StringComparison.OrdinalIgnoreCase) || raw.Equals("VS05", StringComparison.OrdinalIgnoreCase)
                ? "Sanal POS zaman aşımı (timeout); işlem/banka yanıtı kontrol edilmeli"
                : raw.Equals("VB18", StringComparison.OrdinalIgnoreCase)
                    ? "Orijinal işlem bulunamadı"
                    : raw.Equals("VB05", StringComparison.OrdinalIgnoreCase)
                        ? "3D kart sahibi doğrulanamadı"
                        : "Tanımlı genel ISO8583 açıklaması bulunamadı";

        if (src == "BANKSOFT")
        {
            var banksoftCode = raw.Length <= 3 && raw.All(char.IsDigit) ? raw.PadLeft(3, '0') : raw;
            var context = IsBasak(message) && banksoftCode == "096" ? "BANKKART_BASAK" : "GENEL";
            var description = context == "BANKKART_BASAK"
                ? "Bankkart Başak işlemlerinde tebliğ süresi, ek hesap numarası ve kartın limiti kontrol edilmelidir"
                : Banksoft.TryGetValue(banksoftCode, out var b) ? b : general;
            return new VposErrorDefinition(src, banksoftCode, normalized, description, general, context);
        }

        return new VposErrorDefinition(src, raw, normalized, general, general);
    }

    public static string NormalizeIso(string? rawCode)
    {
        var raw = CleanRaw(rawCode);
        if (raw.StartsWith("ISO8583-", StringComparison.OrdinalIgnoreCase))
            raw = raw[8..];
        if (raw.All(char.IsDigit) && raw.Length <= 3)
        {
            var n = raw.TrimStart('0');
            if (n.Length == 0) n = "0";
            return n.PadLeft(2, '0');
        }
        return raw;
    }

    public static string NormalizeSource(string? source)
    {
        var s = (source ?? string.Empty).Trim();
        if (s.Contains("banksoft", StringComparison.OrdinalIgnoreCase)) return "BANKSOFT";
        if (s.Contains("bankacard", StringComparison.OrdinalIgnoreCase) || s.Contains("bankkart", StringComparison.OrdinalIgnoreCase)) return "BANKACARD";
        if (s.Contains("coxec", StringComparison.OrdinalIgnoreCase) || s.Contains("codec", StringComparison.OrdinalIgnoreCase)) return "COXEC";
        if (s.Contains("iso", StringComparison.OrdinalIgnoreCase) || s.Contains("banka", StringComparison.OrdinalIgnoreCase)) return "ISO8583";
        return string.IsNullOrWhiteSpace(s) ? "BİLİNMİYOR" : s.ToUpperInvariant();
    }

    private static string CleanRaw(string? value)
    {
        var s = (value ?? string.Empty).Trim();
        // Preserve Virtual POS namespaces. Old numeric-only extraction
        // accidentally turned VS01 into 01 and VB18 into 18.
        var special = Regex.Match(s, @"(?i)(?:^|[:\s])\*?(?<code>(?:VB|VS)\d{2})\*?(?=\s|$)");
        if (special.Success) return special.Groups["code"].Value.ToUpperInvariant();
        var m = Regex.Match(s, @"(?i)(?:ISO8583[-_: ]*)?(\d{1,3})$");
        return m.Success ? m.Groups[1].Value : (string.IsNullOrWhiteSpace(s) ? "-" : s);
    }

    private static bool IsBasak(string? value) =>
        !string.IsNullOrWhiteSpace(value) &&
        (value.Contains("başak", StringComparison.OrdinalIgnoreCase) ||
         value.Contains("basak", StringComparison.OrdinalIgnoreCase));
}
