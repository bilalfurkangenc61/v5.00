namespace BtOperasyonTakip.Services;

public interface IVposMonitoringCredentialStore
{
    Task<VposMonitoringCredential?> GetAsync(int userId, CancellationToken cancellationToken = default);
    Task SaveAsync(int userId, VposMonitoringCredential credential, CancellationToken cancellationToken = default);
    Task DeleteAsync(int userId, CancellationToken cancellationToken = default);
}
