namespace BtOperasyonTakip.Services;

public sealed class VposGrafanaOptions
{
    // Grafik kaç aylık trend göstersin.
    public int LookbackMonths { get; set; } = 6;
    public string TimeZone { get; set; } = "Europe/Istanbul";

    // Boş bırakılırsa Grafana'daki Elasticsearch datasource otomatik bulunur.
    public string DataSourceUid { get; set; } = string.Empty;

    // Boş bırakılırsa datasource ayarından otomatik bulunur.
    public string Index { get; set; } = string.Empty;

    // Boş bırakılırsa Elasticsearch field_caps üzerinden otomatik bulunur.
    public string TimestampField { get; set; } = string.Empty;
    public string CompanyField { get; set; } = string.Empty;
    public string ErrorCodeField { get; set; } = string.Empty;
}
