namespace BtOperasyonTakip.Services;

public sealed class VposMonitoringCredential
{
    // Kullanıcının verdiği doğrudan Grafana dashboard adresi (/d/{uid}/...).
    public string DashboardUrl { get; set; } = string.Empty;

    // Eski kayıtlarla uyumluluk için tutulur. Yeni akış DashboardUrl'den base URL üretir.
    public string GrafanaUrl { get; set; } = string.Empty;

    // Dashboard data-link içinde Elastic/Kibana adresi yoksa opsiyonel fallback.
    public string ElasticUrl { get; set; } = string.Empty;

    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}
