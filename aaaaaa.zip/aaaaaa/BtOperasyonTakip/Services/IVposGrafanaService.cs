using BtOperasyonTakip.ViewModels;

namespace BtOperasyonTakip.Services;

public interface IVposGrafanaService
{
    Task<VposGrafanaSnapshot> GetSnapshotAsync(
        VposMonitoringCredential credential,
        CancellationToken cancellationToken = default);

    Task<VposGrafanaConnectionTest> TestConnectionAsync(
        VposMonitoringCredential credential,
        CancellationToken cancellationToken = default);
}
