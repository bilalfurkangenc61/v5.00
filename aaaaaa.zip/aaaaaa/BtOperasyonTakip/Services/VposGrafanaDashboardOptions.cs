namespace BtOperasyonTakip.Services;

public sealed class VposGrafanaDashboardOptions
{
    public int MaxPanelsPerRequest { get; set; } = 12;
    public int MaxRows { get; set; } = 50000;
    public int DefaultDays { get; set; } = 7;
    public string[] AllowedHosts { get; set; } = Array.Empty<string>();

    public string[] ErrorPanelKeywords { get; set; } =
        ["hata", "error", "decline", "ret", "response", "iso8583", "banksoft", "bankacard", "coxec", "codec"];

    public string[] TransactionPanelKeywords { get; set; } =
        ["işlem", "islem", "transaction", "merchant", "firma", "müşteri", "musteri", "üye işyeri", "uye isyeri"];

    public string[] OutagePanelKeywords { get; set; } =
        ["kesinti", "outage", "downtime", "availability", "timeout", "latency", "erişilebilirlik", "erisilebilirlik"];

    public string[] CustomerFieldKeywords { get; set; } =
        ["customer", "customername", "merchant", "merchantname", "company", "firma", "musteri", "müşteri", "uyeisyeri", "üyeişyeri", "membermerchant"];

    public string[] ErrorCodeFieldKeywords { get; set; } =
        ["errorcode", "error_code", "responsecode", "response_code", "resultcode", "result_code", "hostcode", "host_code", "hata", "hatakodu", "hata_kodu", "iso", "code"];

    public string[] SourceFieldKeywords { get; set; } =
        ["source", "provider", "processor", "switch", "channel", "kaynak", "host", "bank"];

    public string[] TransactionFieldKeywords { get; set; } =
        ["transactionid", "transaction_id", "transaction", "orderid", "order_id", "invoiceid", "invoice_id", "rrn", "stan", "trace", "islemid", "işlemid"];

    public string[] AmountFieldKeywords { get; set; } =
        ["amount", "totalamount", "total_amount", "tutar", "price"];

    public string[] StatusFieldKeywords { get; set; } =
        ["status", "result", "state", "durum"];

    public string[] MessageFieldKeywords { get; set; } =
        ["message", "description", "errormessage", "error_message", "responsemessage", "response_message", "aciklama", "açıklama"];

    public string[] CountFieldKeywords { get; set; } =
        ["count", "adet", "doc_count", "value", "total"];

    public string[] TimestampFieldKeywords { get; set; } =
        ["@timestamp", "timestamp", "time", "datetime", "date", "tarih"];
}
