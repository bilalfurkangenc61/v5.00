using System.Globalization;

namespace BtOperasyonTakip.Dtos;

public sealed class VposMonitoringFilter
{
    public string? Q { get; set; }
    public string? Customer { get; set; }
    public string? Source { get; set; }
    public string? Code { get; set; }
    public string? TraceId { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 50;

    public DateTime EffectiveFrom => From ?? DateTime.Today.AddDays(-6);
    public DateTime EffectiveTo => To ?? DateTime.Today.AddDays(1).AddTicks(-1);

    public VposMonitoringFilter Normalized()
    {
        var from = EffectiveFrom;
        var to = EffectiveTo;
        if (from > to)
            (from, to) = (to, from);

        return new VposMonitoringFilter
        {
            Q = string.IsNullOrWhiteSpace(Q) ? null : Q.Trim(),
            Customer = NormalizeAll(Customer),
            Source = NormalizeAll(Source),
            Code = NormalizeAll(Code),
            TraceId = NormalizeAll(TraceId),
            From = from,
            To = to,
            Page = Math.Max(1, Page),
            PageSize = Math.Clamp(PageSize, 10, 250)
        };
    }

    public string CacheKey()
    {
        var x = Normalized();
        return string.Join('|', x.Q, x.Customer, x.Source, x.Code, x.TraceId,
            x.EffectiveFrom.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture),
            x.EffectiveTo.ToString("yyyyMMddHHmmss", CultureInfo.InvariantCulture));
    }

    private static string? NormalizeAll(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var x = value.Trim();
        return x.Equals("Tümü", StringComparison.OrdinalIgnoreCase) ||
               x.Equals("Tum", StringComparison.OrdinalIgnoreCase) ||
               x.Equals("All", StringComparison.OrdinalIgnoreCase)
            ? null
            : x;
    }
}

public sealed class VposMonitoringRow
{
    public DateTime? Timestamp { get; set; }
    public string Customer { get; set; } = "-";
    public string Bank { get; set; } = "-";
    public string ApiEndpoint { get; set; } = "-";
    public string Source { get; set; } = "-";
    public string RawCode { get; set; } = "-";
    public string NormalizedCode { get; set; } = "-";
    public string Description { get; set; } = "-";
    public string GeneralDescription { get; set; } = "-";
    public string Context { get; set; } = "";
    public string TransactionId { get; set; } = "-";
    public string TraceId { get; set; } = "-";
    public string Rrn { get; set; } = "-";
    public string ProcessingDuration { get; set; } = "-";
    public string Amount { get; set; } = "-";
    public string Status { get; set; } = "-";
    public string Message { get; set; } = "-";
    public bool IsAggregate { get; set; }
    public bool HasRawLogMessage { get; set; }
    public long Count { get; set; } = 1;
    public string PanelTitle { get; set; } = "-";
    public int? PanelId { get; set; }
    public string? GrafanaUrl { get; set; }
    public string? ExternalLogUrl { get; set; }
    public Dictionary<string, string> Fields { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class VposCountItem
{
    public string Key { get; set; } = "-";
    public long Count { get; set; }
}

public sealed class VposMonitoringResult
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public string? DashboardTitle { get; set; }
    public string? DashboardUrl { get; set; }
    public DateTime RetrievedAt { get; set; } = DateTime.Now;
    public List<VposMonitoringRow> Rows { get; set; } = new();
    public List<VposCountItem> Companies { get; set; } = new();
    public List<VposCountItem> Errors { get; set; } = new();
    public List<VposCountItem> Sources { get; set; } = new();
    public List<VposCountItem> Days { get; set; } = new();
    public int PanelCount { get; set; }
}

public sealed class VposMonitoringPageVm
{
    public VposMonitoringFilter Filter { get; set; } = new();
    public VposMonitoringResult Data { get; set; } = new();
    public bool CredentialsSaved { get; set; }
    public bool Refreshed { get; set; }
    public string? DashboardUrl { get; set; }
    public string? Username { get; set; }
    public int TotalRows { get; set; }
    public int TotalPages { get; set; }
    public List<VposMonitoringRow> PageRows { get; set; } = new();
    public List<string> CustomerOptions { get; set; } = new();
    public List<string> SourceOptions { get; set; } = new();
    public List<string> CodeOptions { get; set; } = new();
}


public sealed class VposCompanyMonthlySeries
{
    public string Company { get; set; } = "-";
    public List<long> Values { get; set; } = new();
}

// Read-only Grafana dashboard presentation DTOs; no EF entity / migration changes.
public sealed class VposResponseTimePoint
{
    public DateTime At { get; set; }
    public double Value { get; set; }
}

public sealed class VposSystemAlarm
{
    public string TraceId { get; set; } = "-";
    public string Host { get; set; } = "-";
    public string HostGroups { get; set; } = "-";
    public string Severity { get; set; } = "-";
    public string Problem { get; set; } = "-";
    public string? GrafanaUrl { get; set; }
    public string? EventId { get; set; }
    public string? OccurredAt { get; set; }
}

// Each displayed error code retains independent real log events / Trace IDs.
// Summary counts and actual event rows are intentionally NOT merged.
public sealed class VposErrorTraceGroup
{
    public string Code { get; set; } = "-";
    public long SummaryCount { get; set; }
    public List<VposMonitoringRow> Traces { get; set; } = new();
}

public sealed class VposOverviewVm
{
    public bool CredentialsSaved { get; set; }
    public string? Username { get; set; }
    public string? DashboardUrl { get; set; }
    // KPI values are nullable to distinguish absent datasource data from a real zero.
    public long? TotalApiCalls { get; set; }
    public long? SuccessfulApiCalls { get; set; }
    public long? FailedApiCalls { get; set; }
    public double? HttpErrorRatePercent { get; set; }
    public long? ActiveIncidents { get; set; }
    public long? ActiveAlerts { get; set; }
    public List<VposCountItem> BankErrors { get; set; } = new();
    public List<VposCountItem> BankBreakdown { get; set; } = new();
    public List<VposCountItem> MerchantErrorBreakdown { get; set; } = new();
    public long? PreviousErrorCount { get; set; }
    public long? CurrentErrorCount { get; set; }
    public double? ErrorChangePercent { get; set; }
    public string? ErrorComparisonStatus { get; set; }
    public long? Vs01Count { get; set; }
    public long? Vs05Count { get; set; }
    public string? TimeoutStatus { get; set; }
    public double? P95Milliseconds { get; set; }
    public double? P99Milliseconds { get; set; }
    public string? LatencyPercentileStatus { get; set; }
    public int LiveMessageCount { get; set; }
    public int LiveMerchantCount { get; set; }
    public string? ErrorDetailStatus { get; set; }
    public List<VposCountItem> VposErrors { get; set; } = new();
    public List<VposResponseTimePoint> ResponseTimePoints { get; set; } = new();
    public List<VposSystemAlarm> SystemAlarms { get; set; } = new();
    public string? SystemAlarmsStatus { get; set; }
    public string? PerformanceStatus { get; set; }
    public string SelectedRange { get; set; } = "30m";
    public List<VposMonitoringRow> LiveErrors { get; set; } = new();
    // Dedicated Grafana important-errors panel; individual log events only.
    public List<VposMonitoringRow> ImportantErrorLogs { get; set; } = new();
    public List<VposMonitoringRow> Code96Logs { get; set; } = new();
    public long? Code96SummaryCount { get; set; }
    public string? ImportantErrorStatus { get; set; }
    public bool Connected { get; set; }
    public string? Message { get; set; }
    public string? DashboardTitle { get; set; }
    public DateTime? RetrievedAt { get; set; }
    public int TotalCompanyCount { get; set; }
    public int ThisMonthActiveCompanyCount { get; set; }
    public long TotalRowCount { get; set; }
    public long TotalErrorCount { get; set; }
    public List<VposCountItem> TopCompanies { get; set; } = new();
    public List<VposCountItem> TopEndpoints { get; set; } = new();
    public List<VposCountItem> TopErrors { get; set; } = new();
    public List<VposErrorTraceGroup> ErrorTraceGroups { get; set; } = new();
    public string? ApiCallsStatus { get; set; }
    public List<VposCountItem> Sources { get; set; } = new();
    public List<string> Months { get; set; } = new();
    public List<VposCompanyMonthlySeries> TopCompanyMonthlySeries { get; set; } = new();
}

public sealed class VposGrafanaConnectionInfo
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public string? DashboardTitle { get; set; }
    public int PanelCount { get; set; }
}
