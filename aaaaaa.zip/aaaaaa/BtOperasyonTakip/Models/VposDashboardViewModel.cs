namespace BtOperasyonTakip.ViewModels;

public sealed class VposDashboardViewModel
{
    public int ToplamMusteri { get; set; }
    public int BuAyEklenen { get; set; }
    public int LookbackMonths { get; set; } = 6;

    public bool GrafanaBilgisiKayitli { get; set; }
    public string? GrafanaKullaniciAdi { get; set; }
    public string? GrafanaUrl { get; set; }
    public string? ElasticUrl { get; set; }

    public bool GrafanaHazir { get; set; }
    public string? GrafanaMesaj { get; set; }
    public DateTime? GrafanaGuncellemeZamani { get; set; }

    public string? DatasourceAdi { get; set; }
    public string? DatasourceUid { get; set; }
    public string? Index { get; set; }
    public string? TimestampField { get; set; }
    public string? CompanyField { get; set; }
    public string? ErrorCodeField { get; set; }

    public List<string> Aylar { get; set; } = new();
    public List<VposFirmaIslemSerisiViewModel> FirmaSerileri { get; set; } = new();
    public List<VposHataKodViewModel> HataKodlari { get; set; } = new();
}

public sealed class VposFirmaIslemSerisiViewModel
{
    public string Firma { get; set; } = string.Empty;
    public List<long> Degerler { get; set; } = new();
    public long Toplam { get; set; }
}

public sealed class VposHataKodViewModel
{
    public string HataKodu { get; set; } = string.Empty;
    public long Adet { get; set; }
    public string? ElasticUrl { get; set; }
}

public sealed class VposGrafanaSnapshot
{
    public bool Basarili { get; set; }
    public string? Mesaj { get; set; }
    public DateTime AlinmaZamani { get; set; } = DateTime.Now;
    public int LookbackMonths { get; set; } = 6;

    public string? DatasourceAdi { get; set; }
    public string? DatasourceUid { get; set; }
    public string? Index { get; set; }
    public string? TimestampField { get; set; }
    public string? CompanyField { get; set; }
    public string? ErrorCodeField { get; set; }

    public List<string> Aylar { get; set; } = new();
    public List<VposFirmaIslemSerisiViewModel> FirmaSerileri { get; set; } = new();
    public List<VposHataKodViewModel> HataKodlari { get; set; } = new();
}

public sealed class VposGrafanaConnectionTest
{
    public bool Basarili { get; set; }
    public string? Mesaj { get; set; }
    public string? DatasourceAdi { get; set; }
    public string? DatasourceUid { get; set; }
    public string? Index { get; set; }
    public string? TimestampField { get; set; }
    public string? CompanyField { get; set; }
    public string? ErrorCodeField { get; set; }
}
