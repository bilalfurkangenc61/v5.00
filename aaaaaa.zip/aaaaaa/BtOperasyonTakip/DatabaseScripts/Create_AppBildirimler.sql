/*
  İSTEĞE BAĞLI MANUEL KURULUM.
  Uygulama BildirimStore ilk kullanımda bu tabloyu zaten otomatik ve idempotent şekilde oluşturur.
  Bu script EF migration değildir ve __EFMigrationsHistory tablosuna dokunmaz.
*/
IF OBJECT_ID(N'[dbo].[AppBildirimler]', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[AppBildirimler]
    (
        [Id] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_AppBildirimler] PRIMARY KEY,
        [UserId] INT NOT NULL,
        [Baslik] NVARCHAR(180) NOT NULL,
        [Mesaj] NVARCHAR(700) NOT NULL,
        [Tur] NVARCHAR(50) NOT NULL,
        [Onem] NVARCHAR(20) NOT NULL,
        [IlgiliVarlikTuru] NVARCHAR(50) NULL,
        [IlgiliVarlikId] INT NULL,
        [IslemiYapanUserId] INT NULL,
        [IslemiYapan] NVARCHAR(120) NULL,
        [OkunduMu] BIT NOT NULL CONSTRAINT [DF_AppBildirimler_OkunduMu] DEFAULT(0),
        [OlusturmaTarihi] DATETIME2 NOT NULL CONSTRAINT [DF_AppBildirimler_OlusturmaTarihi] DEFAULT(SYSDATETIME())
    );

    CREATE INDEX [IX_AppBildirimler_User_Okunmamis_Tarih]
        ON [dbo].[AppBildirimler] ([UserId], [OkunduMu], [OlusturmaTarihi] DESC);
END;
