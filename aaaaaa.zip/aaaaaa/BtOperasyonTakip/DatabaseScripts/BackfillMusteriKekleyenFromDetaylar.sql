/*
    Musteriler.Kekleyen alanı boş olan eski kayıtları,
    ilgili müşterinin Detaylar tablosundaki son dolu Kekleyen değeriyle doldurur.
*/

UPDATE m
SET m.Kekleyen = d.Kekleyen
FROM dbo.Musteriler AS m
CROSS APPLY
(
    SELECT TOP (1) LTRIM(RTRIM(detay.Kekleyen)) AS Kekleyen
    FROM dbo.Detaylar AS detay
    WHERE detay.MusteriID = m.MusteriID
      AND NULLIF(LTRIM(RTRIM(detay.Kekleyen)), '') IS NOT NULL
    ORDER BY detay.Tarih DESC, detay.DetayID DESC
) AS d
WHERE NULLIF(LTRIM(RTRIM(m.Kekleyen)), '') IS NULL
  AND NULLIF(LTRIM(RTRIM(d.Kekleyen)), '') IS NOT NULL;
