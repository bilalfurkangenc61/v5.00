﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BtOperasyonTakip.Views.Takip
{
    public class SahaIndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
