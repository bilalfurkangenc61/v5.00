﻿# Bu betik yalnızca bu paketteki projeyi derler ve başlatır.
# Eski çalışan Visual Studio / IIS Express uygulamasını önce durdurun.
$ErrorActionPreference = 'Stop'
$root = Join-Path $PSScriptRoot 'BtOperasyonTakip'
$project = Join-Path $root 'BtOperasyonTakip.csproj'
$view = Join-Path $root 'Views\Vpos\AnaSayfa.cshtml'
$controller = Join-Path $root 'Controllers\VposController.cs'

if (!(Test-Path -LiteralPath $project)) { throw "Proje bulunamadi: $project" }
if (!(Test-Path -LiteralPath $view)) { throw "VPOS view bulunamadi: $view" }
if (!(Test-Path -LiteralPath $controller)) { throw "VPOS controller bulunamadi: $controller" }
$viewText = Get-Content -LiteralPath $view -Raw -Encoding UTF8
$controllerText = Get-Content -LiteralPath $controller -Raw -Encoding UTF8
if (!$viewText.Contains('FULLZIP-v5') -or !$controllerText.Contains('FULLZIP-v5')) {
    throw 'Bu klasordeki View ve Controller ayni surumde degil (FULLZIP-v5).'
}
if ($controllerText.Contains('Dashboard URL, kullanici adi ve sifre zorunludur.') -or $controllerText.Contains('Dashboard URL, kullanıcı adı ve şifre zorunludur.')) {
    throw 'Controller icinde eski zorunluluk mesaji var.'
}
if ([regex]::IsMatch($viewText, '<input\b[^>]*name="grafanaUsername"[^>]*\brequired\b', 'IgnoreCase') -or [regex]::IsMatch($viewText, '<input\b[^>]*name="grafanaPassword"[^>]*\brequired\b', 'IgnoreCase')) {
    throw 'Grafana kullanici veya parola alaninda required var.'
}
try {
    $portUsed = Get-NetTCPConnection -LocalPort 7183 -State Listen -ErrorAction SilentlyContinue
    if ($portUsed) {
        Write-Host '7183 portu zaten kullanimda. Eski Visual Studio / IIS Express uygulamasini durdurun.' -ForegroundColor Red
        exit 2
    }
} catch { }
$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (!$dotnet) { throw '.NET 8 SDK bulunamadi. dotnet --info ile kontrol edin.' }
Write-Host "Kullanilacak proje: $project" -ForegroundColor Cyan
Write-Host 'Form/Controller FULLZIP-v5 - Grafana kullanici adi ve sifresi opsiyonel.' -ForegroundColor Green
Write-Host 'Proje derleniyor...' -ForegroundColor Cyan
& dotnet build $project -c Debug
if ($LASTEXITCODE -ne 0) { throw 'Derleme basarisiz. Yukaridaki ilk hata kaydini inceleyin.' }
Write-Host 'Proje baslatiliyor. Bu pencereyi acik tutun. Ctrl+C ile durdurun.' -ForegroundColor Cyan
Write-Host 'Giris yaptiktan sonra surum: https://localhost:7183/Vpos/GrafanaSurum' -ForegroundColor Yellow
& dotnet run --no-build --project $project --launch-profile https
if ($LASTEXITCODE -ne 0) { throw "Uygulama baslatilamadi. Cikis kodu: $LASTEXITCODE" }
